/**
 * Contracts View
 * Panel 1: list of contracts (modal-panel)
 * Panel 2: full-screen contract card editor
 *
 * Items are entered manually; product name field has predictive autocomplete from the catalog.
 * СО-статус определяется по актам проверки СО или по переключателю в карточке контракта.
 */

import { state, addContract, updateContract, deleteContract, getContractById, getProgramNames, getPrograms, calcContractDelivered, calcContractAssembled } from '../state.js';
import { calcTotalNeedForProduct, calcTotalContractedForProduct } from '../state.js';
import { attachFrozenManager, refreshFrozenTable } from './frozen-table.js';
import { saveToStorage } from '../storage.js';
import { showToast } from './toast.js';
import { getActsForContract, generateAndDownload } from './acts-registry-view.js';
import { renderLinkedContractsList } from './suppliers-view.js';


// Динамический импорт orders-view чтобы разорвать циклическую зависимость:
// contracts-view → orders-view → contracts-view
async function _openOrderCard(orderId, readonly) {
  const m = await import('./orders-view.js');
  m.openOrderCard(orderId, readonly);
}
async function _openOrdersModal() {
  const m = await import('./orders-view.js');
  m.openOrdersModal();
}

const t = (key, vals) => window.miniappI18n?.t(key, vals) ?? key;

const fmt = new Intl.NumberFormat('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtNum = v => fmt.format(Number(v) || 0);

let _currentContract = null; // set during renderItemsTable so buildRowHtml can access it

function getAdvancePct() {
  return parseFloat(document.getElementById('cFieldAdvancePct')?.value) || 0;
}

let _editingId = null; // contract id being edited, null = new

// ─── Overlay helpers ──────────────────────────────────────────────

function overlay(id) { return document.getElementById(id); }

export function openContractsModal() {
  renderContractsList();
  overlay('contractsModal')?.classList.add('open');
}

export function closeContractsModal() {
  overlay('contractsModal')?.classList.remove('open');
  updateContractsBadge();
  document.getElementById('contractsFilterBar')?.remove();
}

function openContractCard(id) {
  _editingId = id;
  renderContractCard(id);
  setContractCardReadonly(false);
  overlay('contractListPanel')?.classList.add('hidden');
  overlay('contractEditPanel')?.classList.remove('hidden');
}

export function openContractView(id) {
  _editingId = id;
  renderContractCard(id);
  setContractCardReadonly(true);
  overlay('contractListPanel')?.classList.add('hidden');
  overlay('contractEditPanel')?.classList.remove('hidden');
}

function closeContractCard() {
  overlay('contractEditPanel')?.classList.add('hidden');
  overlay('contractListPanel')?.classList.remove('hidden');
  // Close any open autocomplete
  closeAllDropdowns();
  renderContractsList();
}

/** Toggle read-only mode on the contract card */
function setContractCardReadonly(readonly) {
  const editPanel = overlay('contractEditPanel');
  if (!editPanel) return;

  // Disable all inputs, selects, textareas, buttons except back/edit
  editPanel.querySelectorAll('input, select, textarea').forEach(el => {
    el.disabled = readonly;
    el.style.opacity = readonly ? '0.7' : '';
    el.style.cursor = readonly ? 'default' : '';
  });
  // Hide save button, show edit button (or vice versa)
  const saveBtn = document.getElementById('contractCardSaveBtn');
  const editBtn = document.getElementById('contractCardEditBtn');
  if (saveBtn) saveBtn.classList.toggle('hidden', readonly);
  if (editBtn) editBtn.classList.toggle('hidden', !readonly);
  // Hide add-row / add-program buttons
  editPanel.querySelectorAll('#addItemRowBtn, #addProgBtn, .del-item-btn, .del-prog-btn').forEach(b => {
    b.classList.toggle('hidden', readonly);
  });
}

// ─── Sub-panels (orders / acts) inside contract card ─────────────

function openContractSubPanel(id) {
  document.getElementById(id)?.classList.remove('hidden');
}
function closeContractSubPanel(id) {
  document.getElementById(id)?.classList.add('hidden');
}

// ─── Badge ────────────────────────────────────────────────────────

export function updateContractsBadge() {
  const badge = document.getElementById('contractsBadge');
  if (!badge) return;
  const n = state.contracts.length;
  if (n > 0) {
    badge.textContent = n;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }
}

// ─── List panel ───────────────────────────────────────────────────

let _listSearch = '';
let _listSupplierId = '';

/** Фильтрация списка контрактов по поиску и поставщику */
function _filterContracts() {
  const q = _listSearch.trim().toLowerCase();
  const sid = _listSupplierId ? Number(_listSupplierId) : null;
  return state.contracts.filter(c => {
    if (sid !== null && c.supplierId !== sid) return false;
    if (q) {
      const supplier = state.suppliers.find(s => s.id === c.supplierId);
      const supplierName = supplier ? supplier.name.toLowerCase() : '';
      const num = (c.number || '').toLowerCase();
      const title = (c.title || '').toLowerCase();
      if (!num.includes(q) && !title.includes(q) && !supplierName.includes(q)) return false;
    }
    return true;
  });
}

/** Строит или обновляет панель фильтров над списком контрактов */
function _buildOrUpdateContractsFilterBar() {
  const modal = document.getElementById('contractsModal');
  if (!modal) return;
  const listPanel = document.getElementById('contractListPanel');
  if (!listPanel) return;

  let bar = document.getElementById('contractsFilterBar');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'contractsFilterBar';
    bar.style.cssText = 'display:flex;gap:0.5rem;align-items:center;flex-wrap:wrap;padding:0 1.25rem 0.75rem;';

    // Search input
    const searchWrap = document.createElement('div');
    searchWrap.style.cssText = 'position:relative;flex:1;min-width:180px;';
    searchWrap.innerHTML =
      '<span style="position:absolute;left:0.75rem;top:50%;transform:translateY(-50%);font-size:0.8rem;pointer-events:none;opacity:0.5;">🔍</span>' +
      '<input id="contractsSearchInp" type="search" placeholder="Поиск по №, наименованию, поставщику…"' +
      ' style="width:100%;box-sizing:border-box;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:0.75rem;padding:0.5rem 0.75rem 0.5rem 2rem;color:#fff;font-size:0.8rem;outline:none;"' +
      ' value="' + escHtml(_listSearch) + '">';
    bar.appendChild(searchWrap);

    // Supplier autocomplete input
    const supplierWrap = document.createElement('div');
    supplierWrap.style.cssText = 'position:relative;min-width:160px;max-width:240px;';
    supplierWrap.innerHTML =
      '<input id="contractsSupplierInp" type="text" autocomplete="off" placeholder="Поставщик…"' +
      ' style="width:100%;box-sizing:border-box;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:0.75rem;padding:0.5rem 0.75rem;color:#fff;font-size:0.8rem;outline:none;"' +
      ' value="">' +
      '<div id="contractsSupplierDropdown" style="display:none;position:absolute;top:calc(100% + 4px);left:0;right:0;z-index:300;background:rgb(30,41,59);border:1px solid rgba(255,255,255,0.12);border-radius:0.75rem;overflow-y:auto;max-height:180px;box-shadow:0 8px 32px rgba(0,0,0,0.5);"></div>';
    bar.appendChild(supplierWrap);

    // Reset button
    const resetBtn = document.createElement('button');
    resetBtn.id = 'contractsFilterResetBtn';
    resetBtn.textContent = '✕ Сброс';
    resetBtn.style.cssText = 'background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:0.75rem;padding:0.5rem 0.75rem;color:rgb(148,163,184);font-size:0.75rem;cursor:pointer;white-space:nowrap;';
    bar.appendChild(resetBtn);

    // Insert before contractsListContainer
    const container = document.getElementById('contractsListContainer');
    if (container) container.parentElement?.insertBefore(bar, container);

    // Wire events — search
    document.getElementById('contractsSearchInp')?.addEventListener('input', e => {
      _listSearch = e.target.value;
      renderContractsList();
    });

    // Wire events — supplier autocomplete
    const supInp = document.getElementById('contractsSupplierInp');
    const supDrop = document.getElementById('contractsSupplierDropdown');

    function _showSupplierDrop(query) {
      if (!supDrop) return;
      const q = (query || '').trim().toLowerCase();
      const matches = q
        ? state.suppliers.filter(s => s.name.toLowerCase().includes(q))
        : state.suppliers;
      if (matches.length === 0) { supDrop.style.display = 'none'; return; }
      supDrop.innerHTML = matches.map(s =>
        '<div class="sup-ac-item" data-id="' + s.id + '" data-name="' + escHtml(s.name) + '"' +
        ' style="padding:0.5rem 0.75rem;cursor:pointer;font-size:0.8rem;color:rgb(203,213,225);transition:background 0.12s;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' +
        highlightMatch(s.name, query || '') +
        '</div>'
      ).join('');
      supDrop.style.display = 'block';
      supDrop.querySelectorAll('.sup-ac-item').forEach(item => {
        item.addEventListener('mouseenter', () => { item.style.background = 'rgba(34,211,238,0.1)'; });
        item.addEventListener('mouseleave', () => { item.style.background = ''; });
        item.addEventListener('mousedown', e => {
          e.preventDefault();
          _listSupplierId = item.dataset.id;
          if (supInp) supInp.value = item.dataset.name;
          supDrop.style.display = 'none';
          renderContractsList();
        });
      });
    }

    supInp?.addEventListener('input', e => {
      _listSupplierId = '';
      _showSupplierDrop(e.target.value);
    });
    supInp?.addEventListener('focus', e => {
      _showSupplierDrop(e.target.value);
    });
    supInp?.addEventListener('blur', () => {
      setTimeout(() => { if (supDrop) supDrop.style.display = 'none'; }, 180);
    });
    supInp?.addEventListener('keydown', e => {
      if (e.key === 'Escape') { if (supDrop) supDrop.style.display = 'none'; supInp.blur(); }
      if (e.key === 'Enter') { if (supDrop) supDrop.style.display = 'none'; }
    });

    // Restore supplier name if filter was active
    if (_listSupplierId) {
      const sup = state.suppliers.find(s => String(s.id) === String(_listSupplierId));
      if (sup && supInp) supInp.value = sup.name;
    }

    resetBtn.addEventListener('click', () => {
      _listSearch = '';
      _listSupplierId = '';
      const searchInp = document.getElementById('contractsSearchInp');
      if (searchInp) searchInp.value = '';
      if (supInp) supInp.value = '';
      if (supDrop) supDrop.style.display = 'none';
      renderContractsList();
    });
  } else {
    // Restore supplier name label if filter persists
    if (_listSupplierId) {
      const supInp2 = document.getElementById('contractsSupplierInp');
      if (supInp2 && !supInp2.value) {
        const sup = state.suppliers.find(s => String(s.id) === String(_listSupplierId));
        if (sup) supInp2.value = sup.name;
      }
    }
  }
}


function renderContractsList() {
  const wrap = document.getElementById('contractsListContainer');
  if (!wrap) return;

  if (state.contracts.length === 0) {
    wrap.innerHTML =
      '<div class="flex flex-col items-center justify-center py-16 text-center">' +
      '<span class="text-5xl mb-4" aria-hidden="true">📝</span>' +
      '<p class="text-sm font-semibold text-slate-300">' + t('contracts.empty') + '</p>' +
      '<p class="text-xs text-slate-500 mt-1">' + t('contracts.emptyHint') + '</p>' +
      '</div>';
    return;
  }

  // ── Build / update filter bar ──────────────────────────────────
  _buildOrUpdateContractsFilterBar();

  const filtered = _filterContracts();

  if (filtered.length === 0) {
    wrap.innerHTML =
      '<div class="flex flex-col items-center justify-center py-12 text-center">' +
      '<span class="text-4xl mb-3" aria-hidden="true">🔍</span>' +
      '<p class="text-sm font-semibold text-slate-300">Ничего не найдено</p>' +
      '<p class="text-xs text-slate-500 mt-1">Попробуйте изменить параметры поиска</p>' +
      '</div>';
    return;
  }

  wrap.innerHTML = filtered.map(c => {
    const supplier = state.suppliers.find(s => s.id === c.supplierId);
    const supplierName = supplier ? supplier.name : t('contracts.noSupplier');
    const total = fmtNum(c.totalPrice);
    const itemCount = (c.items || []).filter(i => i.name && i.name.trim()).length;
    const numHtml = c.number ? ('№ ' + escHtml(c.number)) : t('contracts.noNumber');
    const titleHtml = c.title ? '<p class="text-xs text-slate-200 mt-0.5 truncate">' + escHtml(c.title) + '</p>' : '';
    const dateHtml = c.date ? ' · ' + escHtml(c.date) : '';
    const itemsHtml = itemCount > 0 ? ' · ' + itemCount + ' ' + t('contracts.positions') : '';
    return '<div class="group flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.04] px-4 py-3 transition hover:bg-white/[0.07] hover:border-cyan-400/20 cursor-pointer contract-card" data-id="' + c.id + '">' +
      '<div class="flex-1 min-w-0 pointer-events-none">' +
      '<p class="text-sm font-semibold text-white truncate">' + numHtml + '</p>' +
      titleHtml +
      '<p class="text-xs text-slate-400 mt-0.5 truncate">' + escHtml(supplierName) + dateHtml + '</p>' +
      '<p class="text-xs text-cyan-400 mt-0.5 tabular-nums">' + total + ' ₽' + itemsHtml + '</p>' +
      '</div>' +
      '<div class="flex gap-1 shrink-0">' +
      '<button class="edit-contract-btn rounded-xl p-2 text-slate-500 hover:bg-cyan-400/10 hover:text-cyan-400 transition" data-id="' + c.id + '" aria-label="' + t('actions.edit') + '" title="' + t('actions.edit') + '">' +
      '<svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4l5 5-9 9H2v-5L11 4z"/></svg>' +
      '</button>' +
      '<button class="del-contract-btn rounded-xl p-2 text-slate-500 hover:bg-red-500/10 hover:text-red-400 transition" data-id="' + c.id + '" aria-label="' + t('actions.delete') + '" title="' + t('actions.delete') + '">' +
      '<svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h14M8 6V4h4v2M5 6l1 12h8l1-12"/></svg>' +
      '</button>' +
      '</div></div>';
  }).join('');

  wrap.querySelectorAll('.contract-card').forEach(card => {
    card.addEventListener('click', e => {
      if (!e.target.closest('button')) openContractView(Number(card.dataset.id));
    });
  });
  wrap.querySelectorAll('.edit-contract-btn').forEach(btn => {
    btn.addEventListener('click', () => openContractCard(Number(btn.dataset.id)));
  });
  wrap.querySelectorAll('.del-contract-btn').forEach(btn => {
    btn.addEventListener('click', () => handleDeleteContract(Number(btn.dataset.id)));
  });
}

async function handleDeleteContract(id) {
  if (!confirm(t('contracts.confirmDelete'))) return;
  deleteContract(id);
  await saveToStorage();
  renderContractsList();
  updateContractsBadge();
  showToast(t('contracts.deleted'), 'success');
}

// ─── Contract card ────────────────────────────────────────────────

function renderContractCard(id) {
  let contract = id != null ? getContractById(id) : null;
  const isNew = !contract;
  if (isNew) {
    contract = addContract({
      programs: [{ name: '', price: 0 }],
      items: [{ name: '', price: 0, qty: 0, ordered: 0, delivered: 0, paidAdvance: 0, paid50: 0, paid30: 0 }],
    });
    _editingId = contract.id;
    saveToStorage();
  }

  // Ensure items array has at least one empty row
  if (!Array.isArray(contract.items)) contract.items = [];
  if (contract.items.length === 0) {
    contract.items.push({ name: '', price: 0, qty: 0, ordered: 0, delivered: 0, paidAdvance: 0, paid50: 0, paid30: 0 });
  }

  const titleEl = document.getElementById('contractCardTitle');
  if (titleEl) titleEl.textContent = contract.number
    ? (t('contracts.cardTitle') + ' № ' + contract.number)
    : t('contracts.newCard');

  renderCardHeader(contract);
  renderProgramsSection(contract);
  // Sync shipping/SO status from acts registry before rendering the table
  syncItemStatusesFromActs(contract);
  renderItemsTable(contract);
  renderProgramFinanceSummary(contract);

  // Wire sub-panel buttons
  wireContractSubPanelButtons(contract);
}

// ── Header fields ─────────────────────────────────────────────────

function renderCardHeader(contract) {
  const wrap = document.getElementById('contractHeaderFields');
  if (!wrap) return;

  const supplierOptions = state.suppliers.map(s =>
    '<option value="' + s.id + '" ' + (s.id === contract.supplierId ? 'selected' : '') + '>' + escHtml(s.name) + '</option>'
  ).join('');

  wrap.innerHTML =
    '<div class="grid grid-cols-1 sm:grid-cols-2 gap-4">' +
    '<div class="sm:col-span-2">' +
    '<label for="cFieldTitle" class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">' + t('contracts.fieldTitle') + '</label>' +
    '<input id="cFieldTitle" type="text" value="' + escHtml(contract.title || '') + '"' +
    ' class="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"' +
    ' placeholder="' + t('contracts.titlePlaceholder') + '">' +
    '</div>' +
    '<div>' +
    '<label for="cFieldNumber" class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">' + t('contracts.fieldNumber') + '</label>' +
    '<input id="cFieldNumber" type="text" value="' + escHtml(contract.number) + '"' +
    ' class="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"' +
    ' placeholder="' + t('contracts.numberPlaceholder') + '">' +
    '</div>' +
    '<div>' +
    '<label for="cFieldDate" class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">' + t('contracts.fieldDate') + '</label>' +
    '<input id="cFieldDate" type="date" value="' + escHtml(contract.date) + '"' +
    ' class="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]">' +
    '</div>' +
    '<div class="sm:col-span-2">' +
    '<label for="cFieldSupplier" class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">' + t('contracts.fieldSupplier') + '</label>' +
    '<select id="cFieldSupplier" class="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-slate-300 transition focus:border-cyan-400/50 focus:bg-white/[0.07]">' +
    '<option value="">' + t('contracts.selectSupplier') + '</option>' +
    supplierOptions +
    '</select></div>' +
    '<div>' +
    '<label for="cFieldTotalPrice" class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">' + t('contracts.fieldTotalPrice') + '</label>' +
    '<input id="cFieldTotalPrice" type="number" min="0" step="0.01" value="' + (contract.totalPrice || '') + '"' +
    ' class="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"' +
    ' placeholder="0.00">' +
    '<p id="cPriceWarning" class="mt-1.5 text-xs text-amber-400 hidden"></p>' +
    '</div>' +
    '<div>' +
    '<label for="cFieldAdvancePct" class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">' + t('contracts.fieldAdvancePct') + '</label>' +
    '<div class="relative">' +
    '<input id="cFieldAdvancePct" type="number" min="0" max="100" step="1" value="' + (contract.advancePct != null ? contract.advancePct : '') + '"' +
    ' class="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 pr-10 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"' +
    ' placeholder="0">' +
    '<span class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">%</span>' +
    '</div>' +
    '<p id="cAdvanceAmount" class="mt-1.5 text-xs text-slate-400 tabular-nums hidden"></p>' +
    '</div></div>';

  document.getElementById('cFieldTotalPrice')?.addEventListener('input', () => checkPriceBalance(contract));

  // Advance % — live calculation of advance amount
  const advancePctEl = document.getElementById('cFieldAdvancePct');
  const advanceAmountEl = document.getElementById('cAdvanceAmount');
  function updateAdvanceAmount() {
    const pct = parseFloat(advancePctEl?.value) || 0;
    const total = parseFloat(document.getElementById('cFieldTotalPrice')?.value) || 0;
    if (advanceAmountEl) {
      if (pct > 0 && total > 0) {
        advanceAmountEl.textContent = 'Сумма аванса: ' + fmtNum(total * pct / 100) + ' ₽';
        advanceAmountEl.classList.remove('hidden');
      } else {
        advanceAmountEl.classList.add('hidden');
      }
    }
  }
  advancePctEl?.addEventListener('input', updateAdvanceAmount);
  advancePctEl?.addEventListener('input', () => refreshAdvanceColumn(contract));
  document.getElementById('cFieldTotalPrice')?.addEventListener('input', updateAdvanceAmount);
  updateAdvanceAmount();

  // ── Ползунок «Согласование СО» ─────────────────────────────────
  const soToggleWrap = document.createElement('div');
  soToggleWrap.className = 'sm:col-span-2 mt-2';
  soToggleWrap.innerHTML =
    '<div class="flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3">' +
    '<div>' +
    '<p class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-0.5">Согласование сигнального образца</p>' +
    '<p class="text-xs text-slate-500">Распространяется на все товары контракта</p>' +
    '</div>' +
    '<label class="flex items-center gap-3 cursor-pointer select-none">' +
    '<span id="soToggleLabelLeft" class="text-xs font-semibold ' + (!contract.soApprovalRequired ? 'text-emerald-400' : 'text-slate-500') + '">Не предусмотрено</span>' +
    '<div class="relative inline-flex items-center">' +
    '<input type="checkbox" id="soApprovalToggle" class="sr-only" ' + (contract.soApprovalRequired !== false ? 'checked' : '') + '>' +
    '<div id="soApprovalTrack" class="w-12 h-6 rounded-full transition-all duration-200 flex items-center px-0.5 ' + (contract.soApprovalRequired !== false ? 'bg-red-500/70' : 'bg-emerald-500/70') + '">' +
    '<div id="soApprovalDot" class="w-5 h-5 rounded-full bg-white shadow-sm transition-all duration-200 ' + (contract.soApprovalRequired !== false ? 'translate-x-6' : 'translate-x-0') + '"></div>' +
    '</div>' +
    '</div>' +
    '<span id="soToggleLabelRight" class="text-xs font-semibold ' + (contract.soApprovalRequired !== false ? 'text-red-400' : 'text-slate-500') + '">Предусмотрено</span>' +
    '</label>' +
    '</div>';

  const headerGrid = wrap.querySelector('.grid');
  if (headerGrid) headerGrid.insertAdjacentElement('afterend', soToggleWrap);
  else wrap.appendChild(soToggleWrap);

  // Wire toggle
  const soToggle = document.getElementById('soApprovalToggle');
  const soTrack  = document.getElementById('soApprovalTrack');
  const soDot    = document.getElementById('soApprovalDot');
  const soLblL   = document.getElementById('soToggleLabelLeft');
  const soLblR   = document.getElementById('soToggleLabelRight');

  function updateSOToggleVisual(checked) {
    if (soTrack) {
      soTrack.classList.toggle('bg-red-500/70',     checked);
      soTrack.classList.toggle('bg-emerald-500/70', !checked);
    }
    if (soDot) {
      soDot.classList.toggle('translate-x-6', checked);
      soDot.classList.toggle('translate-x-0', !checked);
    }
    if (soLblL) { soLblL.classList.toggle('text-emerald-400', !checked); soLblL.classList.toggle('text-slate-500', checked); }
    if (soLblR) { soLblR.classList.toggle('text-red-400', checked); soLblR.classList.toggle('text-slate-500', !checked); }
  }

  soToggle?.addEventListener('change', () => {
    contract.soApprovalRequired = soToggle.checked;
    updateSOToggleVisual(soToggle.checked);
    // Немедленно перерисовываем колонку СО в таблице товаров
    syncItemStatusesFromActs(contract);
    renderItemsTable(contract);
  });
  // При переключении обновляем state немедленно, чтобы buildSOBadge видел новое значение
  // (buildSOBadge читает из state.contracts, поэтому нужно синхронизировать объект)
  // Уже обновляется через contract.soApprovalRequired выше — buildSOBadge теперь
  // использует локальный объект напрямую (см. исправление buildSOBadge ниже).

  // When contract number changes — refresh product codes in table
  document.getElementById('cFieldNumber')?.addEventListener('input', () => {
    refreshAllProductCodes(contract);
  });
}

// ── Programs section ──────────────────────────────────────────────

function renderProgramsSection(contract) {
  const wrap = document.getElementById('contractProgramsWrap');
  if (!wrap) return;

  function render() {
    const progNames = getProgramNames();
    const programs  = getPrograms(); // full objects with limit

    // Reserved in other contracts for a given program name (excluding current)
    function reservedOther(progName) {
      return state.contracts.reduce((sum, c) => {
        if (c.id === contract.id) return sum;
        const p = (c.programs || []).find(p => p.name === progName);
        return sum + (parseFloat(p?.price) || 0);
      }, 0);
    }

    // Build <option> list for a select
    function buildOptions(selectedName) {
      if (progNames.length === 0) {
        return '<option value="" disabled selected>— Нет программ (добавьте в «Финансы») —</option>';
      }
      let opts = '<option value="" disabled ' + (!selectedName ? 'selected' : '') + '>— Выберите программу —</option>';
      progNames.forEach(name => {
        const fp = programs.find(p => p.name === name);
        const limit = parseFloat(fp?.limit) || 0;
        const reserved = reservedOther(name);
        const remaining = limit - reserved;
        const hint = limit > 0 ? ' (остаток: ' + fmtNum(remaining) + ' ₽)' : '';
        opts += '<option value="' + escHtml(name) + '" ' + (selectedName === name ? 'selected' : '') + '>' + escHtml(name) + hint + '</option>';
      });
      return opts;
    }

    let rowsHtml = '';
    contract.programs.forEach((prog, idx) => {
      rowsHtml +=
        '<div class="flex gap-2 items-start" data-prog-idx="' + idx + '">' +
        '<div class="flex-1 min-w-0">' +
        '<select class="prog-name w-full rounded-xl border border-white/10 bg-slate-800 px-3 py-2 text-sm text-white transition focus:border-cyan-400/50" required data-idx="' + idx + '">' +
        buildOptions(prog.name) +
        '</select>' +
        '<p class="prog-budget-warn mt-1 text-xs text-red-400 hidden"></p>' +
        '</div>' +
        '<input type="number" min="0" step="0.01" class="prog-price w-36 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white transition focus:border-cyan-400/50"' +
        ' placeholder="0.00" value="' + (prog.price || '') + '">' +
        '<span class="text-xs text-slate-400 shrink-0 mt-2.5">₽</span>' +
        '<button class="del-prog-btn rounded-lg p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-400/10 transition mt-1" data-idx="' + idx + '" aria-label="' + t('actions.delete') + '">' +
        '<svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h14M8 6V4h4v2M5 6l1 12h8l1-12"/></svg>' +
        '</button>' +
        '</div>';
    });

    const noProgHint = progNames.length === 0
      ? '<p class="mt-2 text-xs text-amber-400/80">⚠ Сначала добавьте целевые программы в разделе «Финансы»</p>'
      : '';

    wrap.innerHTML =
      '<div class="space-y-2" id="programsList">' + rowsHtml + '</div>' +
      noProgHint +
      '<div class="flex items-center justify-between mt-3">' +
      '<button id="addProgBtn" type="button"' +
      ' class="inline-flex items-center gap-1.5 rounded-xl border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-semibold text-cyan-400 transition hover:bg-cyan-400/10 hover:border-cyan-400/30">' +
      '<span aria-hidden="true">＋</span> ' + t('contracts.addProgram') +
      '</button>' +
      '<span id="programsSum" class="text-xs text-slate-400 tabular-nums"></span>' +
      '</div>';

    updateProgramsSum(contract);

    wrap.querySelectorAll('.prog-name').forEach((sel, idx) => {
      sel.addEventListener('change', () => {
        contract.programs[idx].name = sel.value;
        checkBudgetForRow(contract, idx);
        checkPriceBalance(contract);
      });
    });
    wrap.querySelectorAll('.prog-price').forEach((inp, idx) => {
      inp.addEventListener('input', () => {
        contract.programs[idx].price = parseFloat(inp.value) || 0;
        updateProgramsSum(contract);
        checkPriceBalance(contract);
        checkBudgetForRow(contract, idx);
      });
    });
    wrap.querySelectorAll('.del-prog-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        contract.programs.splice(Number(btn.dataset.idx), 1);
        render();
        checkPriceBalance(contract);
      });
    });
    document.getElementById('addProgBtn')?.addEventListener('click', () => {
      contract.programs.push({ name: '', price: 0 });
      render();
    });

    // Run budget check on open for already-filled rows
    contract.programs.forEach((_, idx) => checkBudgetForRow(contract, idx));
  }

  render();
}

/**
 * Check if the price entered for a program row exceeds remaining budget.
 * Shows a warning inline under the select.
 */
function checkBudgetForRow(contract, idx) {
  const prog = contract.programs[idx];
  if (!prog || !prog.name) return;

  const programs = getPrograms();
  const finProg  = programs.find(p => p.name === prog.name);
  const limit    = parseFloat(finProg?.limit) || 0;

  const rowEl  = document.querySelector('#programsList [data-prog-idx="' + idx + '"]');
  const warnEl = rowEl?.querySelector('.prog-budget-warn');
  if (!warnEl) return;

  if (limit <= 0) { warnEl.classList.add('hidden'); return; }

  const reservedOther = state.contracts.reduce((sum, c) => {
    if (c.id === contract.id) return sum;
    const p = (c.programs || []).find(p => p.name === prog.name);
    return sum + (parseFloat(p?.price) || 0);
  }, 0);

  const remaining = limit - reservedOther;
  const entered   = parseFloat(prog.price) || 0;

  if (entered > remaining + 0.01) {
    const over = entered - remaining;
    warnEl.textContent = '⚠ Превышение остатка по программе «' + prog.name + '»: доступно ' + fmtNum(remaining) + ' ₽, введено ' + fmtNum(entered) + ' ₽ (превышение: ' + fmtNum(over) + ' ₽)';
    warnEl.classList.remove('hidden');
  } else {
    warnEl.classList.add('hidden');
  }
}

function updateProgramsSum(contract) {
  const sum = contract.programs.reduce((acc, p) => acc + (parseFloat(p.price) || 0), 0);
  const el = document.getElementById('programsSum');
  if (el) el.textContent = t('contracts.programsSum') + ': ' + fmtNum(sum) + ' ₽';
}

function checkPriceBalance(contract) {
  const totalEl = document.getElementById('cFieldTotalPrice');
  const warnEl = document.getElementById('cPriceWarning');
  if (!totalEl || !warnEl) return;
  const total = parseFloat(totalEl.value) || 0;
  const sum = contract.programs.reduce((acc, p) => acc + (parseFloat(p.price) || 0), 0);
  if (contract.programs.length === 0 || total === 0) { warnEl.classList.add('hidden'); return; }
  const diff = Math.abs(total - sum);
  if (diff > 0.01) {
    const sign = sum > total ? '+' : '';
    warnEl.textContent = '⚠ ' + t('contracts.priceMismatch') + ': сумма программ ' + fmtNum(sum) + ' ₽ (' + sign + fmtNum(sum - total) + ' ₽)';
    warnEl.classList.remove('hidden');
  } else {
    warnEl.classList.add('hidden');
  }
}

// ── Items table (manual rows with autocomplete) ───────────────────

// ── Sync item statuses from acts ──────────────────────────────────

function syncItemStatusesFromActs(contract) {
  const deliveryActs = (state.acts || []).filter(
    a => a.contractId === contract.id && a.mode === 'delivery'
  );

  // Если СО не предусмотрен контрактом — автоматически ставим «not-required» всем товарам
  if (contract.soApprovalRequired === false) {
    (contract.items || []).forEach(item => {
      if (!item.receiving) item.receiving = {};
      item.receiving.soResult = 'not-required';
    });
    // Статус отгрузки всё равно берём из актов поставки
    (contract.items || []).forEach(item => {
      if (!item.receiving) item.receiving = {};
      const itemCode = (item.code || '').trim();
      const itemNameNorm = (item.name || '').trim().toLowerCase();
      function matchSI(si) {
        if (si.selected === false) return false;
        if (itemCode) return (si.itemCode || '').trim() === itemCode;
        return (si.name || '').trim().toLowerCase() === itemNameNorm;
      }
      item.receiving.shippingAllowed = deliveryActs.length > 0 &&
        deliveryActs.some(act =>
          (act.selectedItems || []).some(si => matchSI(si) && si.shippingAllowed === true)
        );
      item.receiving.soResult = 'not-required'; // гарантированно
    });
    return;
  }

  const soActs = (state.acts || []).filter(
    a => a.contractId === contract.id && (!a.mode || a.mode === 'so')
  );

  (contract.items || []).forEach(item => {
    if (!item.receiving) item.receiving = {};

    const itemCode = (item.code || '').trim();
    const itemNameNorm = (item.name || '').trim().toLowerCase();

    function matchSI(si) {
      if (si.selected === false) return false;
      if (itemCode) return (si.itemCode || '').trim() === itemCode;
      return (si.name || '').trim().toLowerCase() === itemNameNorm;
    }

    item.receiving.shippingAllowed = deliveryActs.length > 0 &&
      deliveryActs.some(act =>
        (act.selectedItems || []).some(si => matchSI(si) && si.shippingAllowed === true)
      );

    const soConfirmed = soActs.length > 0 &&
      soActs.some(act =>
        (act.selectedItems || []).some(si =>
          matchSI(si) && (si.soConforms === true || si.siSoNotRequired === true)
        )
      );
    const soNotRequired = soActs.length > 0 &&
      soActs.some(act =>
        (act.selectedItems || []).some(si => matchSI(si) && si.siSoNotRequired === true)
      );
    item.receiving.soResult = soNotRequired ? 'not-required' : (soConfirmed ? 'passed' : '');
  });
}

// ── Receiving-derived status badges ──────────────────────────────

function isShippingAllowed(item, contractId) {
  const itemCode = (item.code || '').trim();
  const itemNameNorm = (item.name || '').trim().toLowerCase();
  const deliveryActs = (state.acts || []).filter(a =>
    a.contractId === contractId && a.mode === 'delivery'
  );
  if (deliveryActs.length === 0) return false;
  return deliveryActs.some(act =>
    (act.selectedItems || []).some(si =>
      si.selected !== false &&
      si.shippingAllowed === true &&
      (itemCode
        ? (si.itemCode || '').trim() === itemCode
        : (si.name || '').trim().toLowerCase() === itemNameNorm)
    )
  );
}

function buildShippingBadge(item, contractId) {
  const allowed = isShippingAllowed(item, contractId);
  return allowed
    ? '<span class="inline-block rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-green-500/15 text-green-400 whitespace-nowrap">' + t('contracts.shippingAllowed') + '</span>'
    : '<span class="inline-block rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-red-500/15 text-red-400 whitespace-nowrap">' + t('contracts.shippingForbidden') + '</span>';
}

function isSOApproved(item, contractId) {
  const itemCode = (item.code || '').trim();
  const itemNameNorm = (item.name || '').trim().toLowerCase();
  const soActs = (state.acts || []).filter(a =>
    a.contractId === contractId && (!a.mode || a.mode === 'so')
  );
  if (soActs.length === 0) return false;
  return soActs.some(act =>
    (act.selectedItems || []).some(si =>
      si.selected !== false &&
      (si.soConforms === true || si.siSoNotRequired === true) &&
      (itemCode
        ? (si.itemCode || '').trim() === itemCode
        : (si.name || '').trim().toLowerCase() === itemNameNorm)
    )
  );
}

function buildSOBadge(item, contractId) {
  // Используем _currentContract (локальный объект в памяти) — он всегда актуален
  // даже до сохранения в state. Fallback — поиск в state.contracts.
  const contract = (_currentContract && _currentContract.id === contractId)
    ? _currentContract
    : (contractId ? state.contracts.find(c => c.id === contractId) : null);
  if (contract && contract.soApprovalRequired === false) {
    return '<span class="inline-block rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 whitespace-nowrap">СО не предусмотрен</span>';
  }

  const itemCode = (item.code || '').trim();
  const itemNameNorm = (item.name || '').trim().toLowerCase();
  const soActs = (state.acts || []).filter(a =>
    a.contractId === contractId && (!a.mode || a.mode === 'so')
  );
  const soNotRequired = soActs.length > 0 && soActs.some(act =>
    (act.selectedItems || []).some(si =>
      si.selected !== false &&
      si.siSoNotRequired === true &&
      (itemCode
        ? (si.itemCode || '').trim() === itemCode
        : (si.name || '').trim().toLowerCase() === itemNameNorm)
    )
  );
  if (soNotRequired) {
    return '<span class="inline-block rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 whitespace-nowrap">СО не предусмотрен</span>';
  }
  const passed = isSOApproved(item, contractId);
  return passed
    ? '<span class="inline-block rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-green-500/15 text-green-400 whitespace-nowrap">' + t('contracts.soApproved') + '</span>'
    : '<span class="inline-block rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-red-500/15 text-red-400 whitespace-nowrap">' + t('contracts.soNotApproved') + '</span>';
}

// Derive product code: 4-digit product number + '/' + last 4 digits of contract number
function buildProductCode(productRef, contractNumber) {
  const prod = productRef != null ? state.products.find(p => p.id === productRef) : null;
  if (!prod) return '';
  const prodNum = String(prod.number).padStart(4, '0');
  const contractDigits = String(contractNumber ?? '').replace(/\D/g, '');
  const contractSuffix = contractDigits.length >= 4
    ? contractDigits.slice(-4)
    : contractDigits.padStart(4, '0');
  return prodNum + '/' + contractSuffix;
}

function refreshAllProductCodes(contract) {
  const numberVal = document.getElementById('cFieldNumber')?.value.trim() ?? contract.number ?? '';
  contract.items.forEach((item, idx) => {
    const code = buildProductCode(item.productRef, numberVal);
    item.code = code;
    const cell = document.querySelector('.product-code-cell[data-row="' + idx + '"]');
    if (cell) cell.textContent = code || '—';
  });
}

// Active autocomplete state
let _acRowIdx = null;
let _acListEl = null;

/**
 * Рассчитывает потребность и уже законтрактованное количество для строки.
 * Возвращает { need, contractedOther, available, exceeded }
 */
function calcNeedInfo(item, contractId) {
  // productRef = id каталога; если нет — пробуем найти по имени
  let productId = item.productRef ?? null;
  if (!productId && item.name) {
    const found = state.products.find(
      p => (p.name || '').trim().toLowerCase() === (item.name || '').trim().toLowerCase()
    );
    productId = found?.id ?? null;
  }

  const need = productId ? calcTotalNeedForProduct(productId) : 0;
  if (need === 0) return { need: 0, contractedOther: 0, available: 0, exceeded: false };

  const contractedOther = calcTotalContractedForProduct(productId, item.name, contractId);
  const available = Math.max(0, need - contractedOther);
  const currentQty = Number(item.qty) || 0;
  const exceeded = (contractedOther + currentQty) > need;
  return { need, contractedOther, available, exceeded, productId };
}

/**
 * Строит tooltip-текст с данными о потребности.
 */
function buildNeedTooltip(item, contractId) {
  const { need, contractedOther, available, exceeded } = calcNeedInfo(item, contractId);
  if (need === 0) return '';
  const lines = [
    'Суммарная потребность: ' + need + ' шт.',
    'В других контрактах: ' + contractedOther + ' шт.',
    'Доступно для этого контракта: ' + available + ' шт.',
  ];
  if (exceeded) lines.push('⚠ ПРЕВЫШЕНИЕ потребности!');
  return lines.join('\n');
}

function closeAllDropdowns() {
  if (_acListEl) { _acListEl.remove(); _acListEl = null; }
  _acRowIdx = null;
}

function renderItemsTable(contract) {
  const wrap = document.getElementById('contractItemsWrap');
  if (!wrap) return;

  function renderTable() {
    _currentContract = contract;
    const rows = contract.items.map((item, idx) => buildRowHtml(item, idx)).join('');

    wrap.innerHTML =
      '<div class="overflow-x-auto rounded-xl border border-white/10" id="itemsTableScroll">' +
      '<table class="text-left border-collapse" style="table-layout:fixed;width:100%" id="itemsTable">' +
      '<thead><tr class="border-b border-white/10 bg-white/[0.03]">' +
      '<th class="py-2.5 px-3 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden">#</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden">' + t('contracts.colProduct') + '</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden">' + t('contracts.colCode') + '</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden">НМЦД, ₽</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden">' + t('contracts.colPrice') + '</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden">' + t('contracts.colQty') + '</th>' +
      '<th class="py-2.5 pr-3 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden text-right">' + t('contracts.colCost') + '</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden text-center">' + t('contracts.colOrdered') + '</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden text-center">' + t('contracts.colDelivered') + '</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden text-center">Собрано</th>' +
      '<th class="py-2.5 pr-3 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden text-right">Аванс, ₽</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden text-center">' + t('contracts.colPaid50') + '</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden text-center">' + t('contracts.colPaid30') + '</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden text-center">' + t('contracts.colSO') + '</th>' +
      '<th class="py-2.5 pr-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500 overflow-hidden text-center">' + t('contracts.colShipping') + '</th>' +
      '<th class="py-2.5 overflow-hidden"></th>' +
      '</tr></thead>' +
      '<tbody id="itemsTbody">' + rows + '</tbody>' +
      '<tfoot><tr class="border-t border-white/10 bg-white/[0.03]">' +
      '<td colspan="5" class="py-2.5 px-3 text-xs font-semibold text-slate-400 uppercase tracking-wider">' + t('contracts.totalCost') + '</td>' +
      '<td class="py-2.5 pr-3 text-sm font-bold text-cyan-400 tabular-nums text-right" id="itemsTotalCost"></td>' +
      '<td colspan="2"></td>' +
      '<td class="py-2.5 pr-3 text-xs font-semibold text-slate-400 uppercase tracking-wider text-right">Аванс итого</td>' +
      '<td class="py-2.5 pr-3 text-sm font-bold text-amber-400 tabular-nums text-right" id="itemsAdvanceTotalCost"></td>' +
      '<td colspan="4"></td>' +
      '</tr></tfoot>' +
      '</table></div>' +
      '<button id="addItemRowBtn" type="button"' +
      ' class="mt-3 inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-cyan-400 transition hover:bg-cyan-400/10 hover:border-cyan-400/30 active:scale-[0.97]">' +
      '<span aria-hidden="true">＋</span> ' + t('contracts.addItem') +
      '</button>';

    bindTableEvents(contract, renderTable);
    updateItemsTotal(contract);
    const tbl = document.getElementById('itemsTable');
    if (tbl) {
      setupResizableTable(tbl);
      requestAnimationFrame(() => attachFrozenManager(tbl, 'contracts-items'));
    }
  }

  renderTable();
}

// ── Column resize ─────────────────────────────────────────────────

const COL_DEFAULTS = [32, 180, 110, 90, 100, 72, 100, 72, 72, 72, 100, 72, 72, 90, 90, 36];
const COL_MIN      = [24,  80,  70, 60,  70, 48,  70, 48, 48, 48,  70, 48, 48, 70, 70, 28];
let _colWidths = [...COL_DEFAULTS];

function applyColWidths(table) {
  const cols = table.querySelectorAll('colgroup col');
  cols.forEach((col, i) => {
    col.style.width = (_colWidths[i] ?? 60) + 'px';
  });
}

function injectColgroup(table) {
  let cg = table.querySelector('colgroup');
  if (!cg) {
    cg = document.createElement('colgroup');
    for (let i = 0; i < COL_DEFAULTS.length; i++) {
      cg.appendChild(document.createElement('col'));
    }
    table.prepend(cg);
  }
  applyColWidths(table);
}

function addResizeHandles(table) {
  const ths = table.querySelectorAll('thead th');
  ths.forEach((th, colIdx) => {
    if (colIdx >= COL_DEFAULTS.length - 1) return;

    th.style.position = 'relative';
    th.style.userSelect = 'none';
    th.style.overflow = 'visible';

    const handle = document.createElement('span');
    handle.setAttribute('aria-hidden', 'true');
    handle.style.cssText = [
      'position:absolute', 'right:-3px', 'top:0', 'bottom:0',
      'width:7px', 'cursor:col-resize', 'z-index:10',
      'display:flex', 'align-items:center', 'justify-content:center',
    ].join(';');
    const bar = document.createElement('span');
    bar.style.cssText = 'width:2px;height:60%;background:rgba(100,116,139,0.3);border-radius:1px;pointer-events:none;transition:background 0.15s';
    handle.appendChild(bar);

    handle.addEventListener('mouseenter', () => { bar.style.background = 'rgba(34,211,238,0.65)'; });
    handle.addEventListener('mouseleave', () => { bar.style.background = 'rgba(100,116,139,0.3)'; });

    handle.addEventListener('mousedown', e => {
      e.preventDefault();
      const startX = e.clientX;
      const startW = _colWidths[colIdx];
      bar.style.background = 'rgba(34,211,238,0.9)';

      const onMove = mv => {
        const delta = mv.clientX - startX;
        _colWidths[colIdx] = Math.max(COL_MIN[colIdx] ?? 40, startW + delta);
        applyColWidths(table);
      };
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        bar.style.background = 'rgba(100,116,139,0.3)';
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });

    th.appendChild(handle);
  });
}

function setupResizableTable(table) {
  injectColgroup(table);
  addResizeHandles(table);
}

/**
 * Строит ячейку количества с tooltip потребности, индикатором превышения и live-валидацией.
 */
function buildQtyCell(item, idx, contractId) {
  const { need, contractedOther, available, exceeded } = calcNeedInfo(item, contractId);
  const tooltip = buildNeedTooltip(item, contractId);

  // Цвет рамки input
  const borderColor = exceeded ? 'border-red-500/70' : 'border-white/10';

  // Подсказка под полем
  let hintHtml = '';
  if (need > 0) {
    if (exceeded) {
      const over = (contractedOther + (Number(item.qty) || 0)) - need;
      hintHtml = '<div class="qty-need-warn absolute bottom-0 left-0 right-0 text-[9px] text-red-400 whitespace-nowrap leading-tight" data-row="' + idx + '">⚠ Превышение на ' + over + ' шт.</div>';
    } else {
      hintHtml = '<div class="qty-need-info absolute bottom-0 left-0 right-0 text-[9px] text-slate-500 whitespace-nowrap leading-tight" data-row="' + idx + '">Потр.: ' + need + ' · Доступно: ' + available + '</div>';
    }
  }

  return '<td class="py-1.5 pr-2"><div class="relative pb-4" title="' + escHtml(tooltip) + '">' +
    '<input type="number" min="0" step="1" class="item-qty w-full rounded-lg border ' + borderColor + ' bg-white/5 px-2 py-2 text-sm text-white tabular-nums transition focus:border-cyan-400/50" value="' + (item.qty || '') + '" placeholder="0" data-row="' + idx + '" data-need="' + need + '" data-contracted-other="' + contractedOther + '">' +
    hintHtml +
    '</div></td>';
}

function buildRowHtml(item, idx) {
  const cost = (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0);
  const numVal = (field) => (typeof item[field] === 'boolean' ? (item[field] ? 1 : 0) : (parseFloat(item[field]) || 0));
  const contractNumber = document.getElementById('cFieldNumber')?.value.trim() ?? '';
  const productCode = buildProductCode(item.productRef, contractNumber);
  item.code = productCode;
  const advancePct = getAdvancePct();
  const advanceAmt = (parseFloat(item.price) || 0) * (parseFloat(item.ordered) || 0) * advancePct / 100;
  const contractId = _currentContract ? _currentContract.id : null;

  const delivered = contractId ? calcContractDelivered(contractId, item.name, productCode) : 0;
  const qty = parseFloat(item.qty) || 0;
  const deliveredColor = delivered >= qty && qty > 0
    ? 'text-green-400' : delivered > 0 ? 'text-amber-400' : 'text-slate-500';

  const prod = item.productRef ? state.products.find(p => p.id === item.productRef) : null;
  const needsAssembly = prod ? prod.assembly === 'required' : false;
  let assembledHtml = '<span class="text-slate-600">—</span>';
  if (needsAssembly) {
    const assembled = contractId
      ? calcContractAssembled(contractId, item.name, productCode, item.productRef)
      : 0;
    const asmColor = assembled >= qty && qty > 0
      ? 'text-green-400' : assembled > 0 ? 'text-amber-400' : 'text-slate-500';
    assembledHtml = '<span class="' + asmColor + ' tabular-nums font-semibold">' + (assembled > 0 ? assembled : '—') + '</span>';
  }

  const codeHtml = productCode
    ? escHtml(productCode)
    : '<span class="text-slate-600">—</span>';

  return '<tr class="border-b border-white/5 hover:bg-white/[0.02]" data-row="' + idx + '">' +
    '<td class="py-2 px-3 text-xs text-slate-500 tabular-nums">' + (idx + 1) + '</td>' +
    '<td class="py-1.5 pr-2 relative name-cell"><div class="relative">' +
    '<input type="text" class="item-name w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"' +
    ' value="' + escHtml(item.name || '') + '" placeholder="' + t('contracts.itemNamePlaceholder') + '"' +
    ' data-row="' + idx + '" autocomplete="off" spellcheck="false">' +
    '</div></td>' +
    '<td class="py-2 px-2"><span class="product-code-cell block rounded-lg bg-white/[0.04] border border-white/8 px-2 py-1.5 text-xs text-slate-400 tabular-nums font-mono text-center whitespace-nowrap" data-row="' + idx + '">' + codeHtml + '</span></td>' +
    '<td class="py-1.5 pr-2"><input type="number" min="0" step="0.01" class="item-nmcd w-full rounded-lg border border-white/10 bg-white/5 px-2 py-2 text-sm text-slate-300 tabular-nums transition focus:border-cyan-400/50" value="' + (item.nmcd || '') + '" placeholder="0.00" data-row="' + idx + '" aria-label="НМЦД"></td>' +
    '<td class="py-1.5 pr-2"><div class="relative pb-4"><input type="number" min="0" step="0.01" class="item-price w-full rounded-lg border border-white/10 bg-white/5 px-2 py-2 text-sm text-white tabular-nums transition focus:border-cyan-400/50" value="' + (item.price || '') + '" placeholder="0.00" data-row="' + idx + '"><div class="nmcd-warn' + ((parseFloat(item.nmcd) > 0 && parseFloat(item.price) > parseFloat(item.nmcd) ? '' : ' hidden')) + ' absolute bottom-0 left-0 right-0 text-[9px] text-red-400 whitespace-nowrap leading-tight" data-row="' + idx + '">⚠ Превышает НМЦД</div></div></td>' +
    buildQtyCell(item, idx, contractId) +
    '<td class="py-2 pr-3 text-sm text-slate-300 tabular-nums text-right cost-cell" data-row="' + idx + '">' + fmtNum(cost) + '</td>' +
    '<td class="py-1.5 pr-2"><input type="number" min="0" step="1" class="item-num w-full rounded-lg border border-white/10 bg-white/5 px-2 py-2 text-sm text-white tabular-nums text-center transition focus:border-cyan-400/50" data-row="' + idx + '" data-field="ordered" value="' + numVal('ordered') + '" placeholder="0" aria-label="' + t('contracts.colOrdered') + '"></td>' +
    '<td class="py-2 pr-2 text-center"><span class="' + deliveredColor + ' tabular-nums font-semibold text-sm">' + (delivered > 0 ? delivered : '—') + '</span></td>' +
    '<td class="py-2 pr-2 text-center">' + assembledHtml + '</td>' +
    '<td class="py-2 pr-3 text-sm text-amber-400 tabular-nums text-right advance-cell" data-row="' + idx + '">' + fmtNum(advanceAmt) + '</td>' +
    '<td class="py-1.5 pr-2"><input type="number" min="0" step="0.01" class="item-num w-full rounded-lg border border-white/10 bg-white/5 px-2 py-2 text-sm text-white tabular-nums text-center transition focus:border-cyan-400/50" data-row="' + idx + '" data-field="paid50" value="' + numVal('paid50') + '" placeholder="0" aria-label="' + t('contracts.colPaid50') + '"></td>' +
    '<td class="py-1.5 pr-2"><input type="number" min="0" step="0.01" class="item-num w-full rounded-lg border border-white/10 bg-white/5 px-2 py-2 text-sm text-white tabular-nums text-center transition focus:border-cyan-400/50" data-row="' + idx + '" data-field="paid30" value="' + numVal('paid30') + '" placeholder="0" aria-label="' + t('contracts.colPaid30') + '"></td>' +
    '<td class="py-2 text-center">' + buildSOBadge(item, contractId) + '</td>' +
    '<td class="py-2 px-1 text-center">' + buildShippingBadge(item, contractId) + '</td>' +
    '<td class="py-2 text-center"><button class="del-item-btn rounded-lg p-1.5 text-slate-600 hover:text-red-400 hover:bg-red-400/10 transition" data-row="' + idx + '" aria-label="' + t('actions.delete') + '">' +
    '<svg width="13" height="13" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h14M8 6V4h4v2M5 6l1 12h8l1-12"/></svg>' +
    '</button></td>' +
    '</tr>';
}

function bindTableEvents(contract, rerenderFn) {
  const wrap = document.getElementById('contractItemsWrap');
  if (!wrap) return;

  wrap.querySelector('#addItemRowBtn')?.addEventListener('click', () => {
    contract.items.push({ name: '', price: 0, qty: 0, ordered: 0, delivered: 0, paidAdvance: 0, paid50: 0, paid30: 0 });
    rerenderFn();
    requestAnimationFrame(() => {
      const inputs = wrap.querySelectorAll('.item-name');
      inputs[inputs.length - 1]?.focus();
    });
  });

  wrap.querySelectorAll('.del-item-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      closeAllDropdowns();
      contract.items.splice(Number(btn.dataset.row), 1);
      rerenderFn();
    });
  });

  wrap.querySelectorAll('.item-name').forEach(inp => {
    inp.addEventListener('input', () => {
      const idx = Number(inp.dataset.row);
      contract.items[idx].name = inp.value;
      showAutocomplete(inp, idx, contract, rerenderFn);
    });
    inp.addEventListener('focus', () => {
      const idx = Number(inp.dataset.row);
      showAutocomplete(inp, idx, contract, rerenderFn);
    });
    inp.addEventListener('keydown', e => {
      handleAutocompleteKeydown(e, inp, contract, rerenderFn);
    });
    inp.addEventListener('blur', () => {
      setTimeout(closeAllDropdowns, 150);
    });
  });

  wrap.querySelectorAll('.item-nmcd').forEach(inp => {
    inp.addEventListener('input', () => {
      const idx = Number(inp.dataset.row);
      contract.items[idx].nmcd = parseFloat(inp.value) || 0;
      checkNmcdForRow(contract, idx);
    });
  });

  wrap.querySelectorAll('.item-price').forEach(inp => {
    inp.addEventListener('input', () => {
      const idx = Number(inp.dataset.row);
      contract.items[idx].price = parseFloat(inp.value) || 0;
      refreshCostCell(contract, idx);
      updateItemsTotal(contract);
      checkNmcdForRow(contract, idx);
    });
  });

  wrap.querySelectorAll('.item-qty').forEach(inp => {
    inp.addEventListener('input', () => {
      const idx = Number(inp.dataset.row);
      contract.items[idx].qty = parseFloat(inp.value) || 0;
      refreshCostCell(contract, idx);
      updateItemsTotal(contract);
      checkNeedForRow(contract, idx, inp);
    });
  });

  wrap.querySelectorAll('.item-num').forEach(inp => {
    inp.addEventListener('input', () => {
      const idx = Number(inp.dataset.row);
      const field = inp.dataset.field;
      contract.items[idx][field] = parseFloat(inp.value) || 0;
      if (field === 'ordered') refreshAdvanceCell(contract, idx);
    });
  });
}

// ── Autocomplete ──────────────────────────────────────────────────

function getProductSuggestions(query) {
  const q = query.trim().toLowerCase();
  if (!q) return state.products.slice(0, 20);
  return state.products.filter(p =>
    p.name?.toLowerCase().includes(q) ||
    String(p.number).includes(q) ||
    p.category?.toLowerCase().includes(q)
  ).slice(0, 20);
}

function showAutocomplete(inp, rowIdx, contract, rerenderFn) {
  closeAllDropdowns();
  const suggestions = getProductSuggestions(inp.value);
  if (suggestions.length === 0) return;

  _acRowIdx = rowIdx;

  const list = document.createElement('div');
  list.id = 'acDropdown';
  list.className = [
    'absolute z-[200] left-0 right-0',
    'mt-1 rounded-xl border border-white/15 bg-slate-800 shadow-2xl',
    'overflow-y-auto max-h-52',
  ].join(' ');
  list.setAttribute('role', 'listbox');

  list.innerHTML = suggestions.map((p, i) =>
    '<div class="ac-item flex items-center gap-3 px-3 py-2.5 cursor-pointer hover:bg-cyan-400/10 transition" role="option" data-idx="' + i + '" data-pid="' + p.id + '">' +
    '<span class="text-xs text-slate-500 tabular-nums w-6 shrink-0">' + p.number + '</span>' +
    '<div class="flex-1 min-w-0">' +
    '<p class="text-sm text-white truncate">' + highlightMatch(p.name, inp.value) + '</p>' +
    (p.category ? '<p class="text-[10px] text-slate-500">' + escHtml(p.category) + '</p>' : '') +
    '</div></div>'
  ).join('');

  const parent = inp.parentElement;
  parent.style.position = 'relative';
  parent.appendChild(list);
  _acListEl = list;

  list.querySelectorAll('.ac-item').forEach((el, i) => {
    el.addEventListener('mousedown', e => {
      e.preventDefault();
      const prod = suggestions[i];
      applyAutocomplete(inp, rowIdx, prod, contract, rerenderFn);
    });
  });
}

function applyAutocomplete(inp, rowIdx, prod, contract, rerenderFn) {
  closeAllDropdowns();
  contract.items[rowIdx].name = prod.name;
  inp.value = prod.name;
  contract.items[rowIdx].productRef = prod.id;
  const contractNumber = document.getElementById('cFieldNumber')?.value.trim() ?? '';
  const code = buildProductCode(prod.id, contractNumber);
  contract.items[rowIdx].code = code;
  const codeCell = document.querySelector('.product-code-cell[data-row="' + rowIdx + '"]');
  if (codeCell) codeCell.textContent = code || '—';
  rerenderFn();
}

function handleAutocompleteKeydown(e, inp, contract, rerenderFn) {
  const list = _acListEl;
  if (!list) return;
  const items = list.querySelectorAll('.ac-item');
  const active = list.querySelector('.ac-item.bg-cyan-400\\/10');
  const activeIdx = active ? Number(active.dataset.idx) : -1;

  if (e.key === 'ArrowDown') {
    e.preventDefault();
    const next = Math.min(activeIdx + 1, items.length - 1);
    items.forEach(el => el.classList.remove('bg-cyan-400/10'));
    items[next]?.classList.add('bg-cyan-400/10');
    items[next]?.scrollIntoView({ block: 'nearest' });
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    const prev = Math.max(activeIdx - 1, 0);
    items.forEach(el => el.classList.remove('bg-cyan-400/10'));
    items[prev]?.classList.add('bg-cyan-400/10');
    items[prev]?.scrollIntoView({ block: 'nearest' });
  } else if (e.key === 'Enter' && activeIdx >= 0) {
    e.preventDefault();
    const row = Number(inp.dataset.row);
    const suggestions = getProductSuggestions(inp.value);
    const prod = suggestions[activeIdx];
    if (prod) applyAutocomplete(inp, row, prod, contract, rerenderFn);
  } else if (e.key === 'Escape') {
    closeAllDropdowns();
  }
}

function highlightMatch(text, query) {
  if (!query.trim()) return escHtml(text);
  const idx = text.toLowerCase().indexOf(query.toLowerCase().trim());
  if (idx === -1) return escHtml(text);
  return escHtml(text.slice(0, idx))
    + '<mark class="bg-cyan-400/20 text-cyan-300 rounded">' + escHtml(text.slice(idx, idx + query.trim().length)) + '</mark>'
    + escHtml(text.slice(idx + query.trim().length));
}

// ── NMCD validation ───────────────────────────────────────────────

function checkNmcdForRow(contract, rowIdx) {
  const item = contract.items[rowIdx];
  if (!item) return;
  const nmcd  = parseFloat(item.nmcd)  || 0;
  const price = parseFloat(item.price) || 0;
  const warnEl  = document.querySelector('.nmcd-warn[data-row="' + rowIdx + '"]');
  const priceInp = document.querySelector('.item-price[data-row="' + rowIdx + '"]');
  if (!warnEl || !priceInp) return;
  const exceeded = nmcd > 0 && price > nmcd;
  warnEl.classList.toggle('hidden', !exceeded);
  priceInp.style.borderColor = exceeded ? 'rgb(239,68,68)' : '';
}

// ── Need validation ───────────────────────────────────────────────

/**
 * Live-валидация при вводе qty: обновляет рамку и подсказку под полем.
 * Блокирует сохранение если введённое кол-во превышает потребность.
 * @param {object} contract
 * @param {number} rowIdx
 * @param {HTMLInputElement} inp — input.item-qty
 */
function checkNeedForRow(contract, rowIdx, inp) {
  const item = contract.items[rowIdx];
  if (!item) return;

  const need            = Number(inp?.dataset.need)           || 0;
  const contractedOther = Number(inp?.dataset.contractedOther) || 0;
  const currentQty      = Number(item.qty) || 0;

  if (need === 0) return; // потребность не задана — не проверяем

  const total    = contractedOther + currentQty;
  const exceeded = total > need;
  const available = Math.max(0, need - contractedOther);

  // Рамка input
  if (inp) {
    inp.style.borderColor = exceeded ? 'rgb(239,68,68)' : '';
  }

  // Hint под полем
  const warnEl = document.querySelector('.qty-need-warn[data-row="' + rowIdx + '"]');
  const infoEl = document.querySelector('.qty-need-info[data-row="' + rowIdx + '"]');

  if (exceeded) {
    const over = total - need;
    if (warnEl) {
      warnEl.textContent = '⚠ Превышение на ' + over + ' шт.';
      warnEl.classList.remove('hidden');
    } else if (infoEl) {
      // Превращаем info в warn
      infoEl.className = 'qty-need-warn absolute bottom-0 left-0 right-0 text-[9px] text-red-400 whitespace-nowrap leading-tight';
      infoEl.setAttribute('data-row', String(rowIdx));
      infoEl.textContent = '⚠ Превышение на ' + over + ' шт.';
    }
  } else {
    if (warnEl) {
      warnEl.className = 'qty-need-info absolute bottom-0 left-0 right-0 text-[9px] text-slate-500 whitespace-nowrap leading-tight';
      warnEl.setAttribute('data-row', String(rowIdx));
      warnEl.textContent = 'Потр.: ' + need + ' · Доступно: ' + (available - currentQty + currentQty) + '';
    }
    if (infoEl) {
      infoEl.textContent = 'Потр.: ' + need + ' · Доступно: ' + Math.max(0, need - contractedOther - currentQty + currentQty) + '';
    }
  }
}

/**
 * Проверяет все строки таблицы на превышение потребности перед сохранением.
 * Возвращает массив строк с превышением.
 */
function checkAllNeedsBeforeSave(contract) {
  const violations = [];
  contract.items.forEach((item, idx) => {
    if (!item.name) return;
    const { need, contractedOther, exceeded } = calcNeedInfo(item, contract.id);
    if (need > 0 && exceeded) {
      const over = (contractedOther + (Number(item.qty) || 0)) - need;
      violations.push({ name: item.name, over, need, contractedOther, qty: Number(item.qty) || 0 });
    }
  });
  return violations;
}

// ── Cost helpers ──────────────────────────────────────────────────

function refreshCostCell(contract, rowIdx) {
  const item = contract.items[rowIdx];
  if (!item) return;
  const cost = (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0);
  const cell = document.querySelector('.cost-cell[data-row="' + rowIdx + '"]');
  if (cell) cell.textContent = fmtNum(cost);
}

function updateItemsTotal(contract) {
  const total = contract.items.reduce((acc, i) =>
    acc + (parseFloat(i.price) || 0) * (parseFloat(i.qty) || 0), 0);
  const el = document.getElementById('itemsTotalCost');
  if (el) el.textContent = fmtNum(total) + ' ₽';
}

function refreshAdvanceCell(contract, rowIdx) {
  const item = contract.items[rowIdx];
  if (!item) return;
  const pct = getAdvancePct();
  const amt = (parseFloat(item.price) || 0) * (parseFloat(item.ordered) || 0) * pct / 100;
  const cell = document.querySelector('.advance-cell[data-row="' + rowIdx + '"]');
  if (cell) cell.textContent = fmtNum(amt);
  updateAdvanceTotal(contract);
}

function refreshAdvanceColumn(contract) {
  contract.items.forEach((_, idx) => refreshAdvanceCell(contract, idx));
}

function updateAdvanceTotal(contract) {
  const pct = getAdvancePct();
  const total = contract.items.reduce((acc, i) =>
    acc + (parseFloat(i.price) || 0) * (parseFloat(i.ordered) || 0) * pct / 100, 0);
  const el = document.getElementById('itemsAdvanceTotalCost');
  if (el) el.textContent = fmtNum(total) + ' ₽';
}

// ─── Save contract card ───────────────────────────────────────────

async function saveContractCard() {
  const contract = getContractById(_editingId);
  if (!contract) return;

  // ── Validate programs: all must have a name from Finance ──
  const validProgNames = new Set(getProgramNames());
  for (let i = 0; i < contract.programs.length; i++) {
    // Читаем актуальное значение из DOM <select>, а не из объекта в памяти
    const rowEl = document.querySelector('#programsList [data-prog-idx="' + i + '"]');
    const sel   = rowEl?.querySelector('.prog-name');
    const domName = sel ? sel.value : '';
    // Синхронизируем объект из DOM
    if (domName) contract.programs[i].name = domName;
    const nameToCheck = domName || contract.programs[i].name || '';
    if (!nameToCheck || !validProgNames.has(nameToCheck)) {
      showToast(t('contracts.programRequired'), 'error');
      if (sel) {
        sel.style.borderColor = 'rgb(239,68,68)';
        setTimeout(() => { sel.style.borderColor = ''; }, 2500);
        sel.focus();
      }
      return;
    }
  }

  // ── Проверка превышения потребности ──────────────────────────────
  const needViolations = checkAllNeedsBeforeSave(contract);
  if (needViolations.length > 0) {
    const lines = needViolations.map(v =>
      '• ' + v.name + ': введено ' + v.qty + ', потребность ' + v.need +
      ', в других контрактах ' + v.contractedOther + ' (превышение: ' + v.over + ' шт.)'
    );
    const proceed = confirm(
      '⚠ Количество товара превышает суммарную потребность:\n\n' + lines.join('\n') +
      '\n\nСохранить всё равно?'
    );
    if (!proceed) return;
  }

  // Sync nmcd values from DOM before saving
  document.querySelectorAll('.item-nmcd').forEach(inp => {
    const idx = Number(inp.dataset.row);
    if (contract.items[idx]) contract.items[idx].nmcd = parseFloat(inp.value) || 0;
  });

  const title = document.getElementById('cFieldTitle')?.value.trim() || '';
  const number = document.getElementById('cFieldNumber')?.value.trim() || '';
  const date = document.getElementById('cFieldDate')?.value || '';
  const supplierId = Number(document.getElementById('cFieldSupplier')?.value) || null;
  const totalPrice = parseFloat(document.getElementById('cFieldTotalPrice')?.value) || 0;
  const advancePct = parseFloat(document.getElementById('cFieldAdvancePct')?.value) ?? null;

  updateContract(contract.id, { title, number, date, supplierId, totalPrice, advancePct: isNaN(advancePct) ? null : advancePct, programs: contract.programs, items: contract.items, soApprovalRequired: contract.soApprovalRequired !== false });

  const titleEl = document.getElementById('contractCardTitle');
  if (titleEl) titleEl.textContent = number ? (t('contracts.cardTitle') + ' № ' + number) : t('contracts.newCard');

  await saveToStorage();
  showToast(t('contracts.saved'), 'success');
  updateContractsBadge();

  if (supplierId) {
    renderLinkedContractsList(supplierId);
  }
}

// ─── Program Finance Summary ──────────────────────────────────────

export function refreshContractItemsOrdered(contractId) {
  const editPanel = document.getElementById('contractEditPanel');
  if (!editPanel || editPanel.classList.contains('hidden')) return;
  if (_editingId !== contractId) return;

  const contract = getContractById(contractId);
  if (!contract) return;

  contract.items.forEach((item, idx) => {
    const input = document.querySelector(
      '.item-num[data-row="' + idx + '"][data-field="ordered"]'
    );
    if (input) {
      input.value = String(item.ordered || 0);
      input.style.transition = 'background 0.3s';
      input.style.background = 'rgba(34,211,238,0.18)';
      setTimeout(() => { input.style.background = ''; }, 900);
    }
  });

  renderProgramFinanceSummary(contract);
}

export function renderProgramFinanceSummary(contract) {
  const wrap = document.getElementById('contractFinanceSummaryWrap');
  if (!wrap) return;

  wrap.innerHTML = '';

  if (!contract.programs || contract.programs.length === 0) {
    wrap.innerHTML = '<p class="text-xs text-slate-600 italic">Целевые программы не заданы</p>';
    return;
  }

  const contractOrders = (state.orders || []).filter(o => o.contractId === contract.id);

  function orderedForProgram(progName) {
    let sum = 0;
    contractOrders.forEach(order => {
      const globalProg = (state.programs || []).find(p =>
        (p.code && p.code === order.programCode) || p.name === order.programCode
      );
      const matchByGlobalProg = globalProg ? (globalProg.name === progName) : false;
      const matchByDirectName = order.programCode === progName;
      if (!matchByGlobalProg && !matchByDirectName) return;

      if (Array.isArray(order.deliveryRows) && order.deliveryRows.length > 0) {
        order.deliveryRows.forEach(r => {
          sum += (Number(r.qty) || 0) * (Number(r.price) || 0);
        });
      } else {
        (order.items || []).forEach(it => {
          const scheds = Array.isArray(it.deliverySchedules) ? it.deliverySchedules : [];
          if (scheds.length > 0) {
            scheds.forEach(sc => {
              sum += (Number(sc.qty) || 0) * (Number(sc.price) || Number(it.price) || 0);
            });
          } else {
            sum += (Number(it.qty) || 0) * (Number(it.price) || 0);
          }
        });
      }
    });
    return sum;
  }

  // Also get global Finance limit for each program
  const finPrograms = getPrograms();

  const title = document.createElement('h3');
  title.className = 'text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3';
  title.textContent = 'Финансы по программам';
  wrap.appendChild(title);

  const tableWrap = document.createElement('div');
  tableWrap.className = 'overflow-x-auto rounded-xl border border-white/10';

  const table = document.createElement('table');
  table.className = 'w-full text-sm border-collapse';
  table.innerHTML =
    '<thead><tr class="border-b border-white/10 bg-white/[0.03]">' +
    '<th class="py-2.5 px-4 text-[10px] font-semibold uppercase tracking-wider text-slate-500 text-left">Программа</th>' +
    '<th class="py-2.5 px-4 text-[10px] font-semibold uppercase tracking-wider text-slate-500 text-right">Лимит (Финансы), ₽</th>' +
    '<th class="py-2.5 px-4 text-[10px] font-semibold uppercase tracking-wider text-slate-500 text-right">Бюджет контракта, ₽</th>' +
    '<th class="py-2.5 px-4 text-[10px] font-semibold uppercase tracking-wider text-slate-500 text-right">Сумма заказов, ₽</th>' +
    '<th class="py-2.5 px-4 text-[10px] font-semibold uppercase tracking-wider text-slate-500 text-right">Остаток по заказам, ₽</th>' +
    '</tr></thead>';

  const tbody = document.createElement('tbody');
  contract.programs.forEach(prog => {
    const budget  = parseFloat(prog.price) || 0;
    const ordered = orderedForProgram(prog.name);
    const remain  = budget - ordered;
    const remainClass = remain < 0 ? 'text-red-400' : remain === 0 ? 'text-slate-400' : 'text-emerald-400';

    // Global Finance limit and reserved
    const finProg = finPrograms.find(p => p.name === prog.name);
    const finLimit = parseFloat(finProg?.limit) || 0;
    const finReserved = state.contracts.reduce((sum, c) => {
      const p = (c.programs || []).find(p => p.name === prog.name);
      return sum + (parseFloat(p?.price) || 0);
    }, 0);
    const finRemaining = finLimit - finReserved;
    const finLimitHtml = finLimit > 0
      ? '<span class="text-cyan-400/80">' + fmtNum(finLimit) + '</span>' +
        '<span class="text-slate-600 text-[10px] ml-1">(ост. ' + fmtNum(finRemaining) + ')</span>'
      : '<span class="text-slate-600">—</span>';

    const tr = document.createElement('tr');
    tr.className = 'border-b border-white/5 hover:bg-white/[0.02]';
    tr.innerHTML =
      '<td class="py-2.5 px-4 text-sm text-white">' + escHtml(prog.name || '—') + '</td>' +
      '<td class="py-2.5 px-4 text-sm tabular-nums text-right">' + finLimitHtml + '</td>' +
      '<td class="py-2.5 px-4 text-sm text-slate-300 tabular-nums text-right">' + fmtNum(budget) + '</td>' +
      '<td class="py-2.5 px-4 text-sm text-cyan-400 tabular-nums text-right">' + fmtNum(ordered) + '</td>' +
      '<td class="py-2.5 px-4 text-sm font-semibold tabular-nums text-right ' + remainClass + '">' + fmtNum(remain) + '</td>';
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  tableWrap.appendChild(table);
  wrap.appendChild(tableWrap);
}

// ─── Contract sub-panels: Orders & Acts ──────────────────────────

function wireContractSubPanelButtons(contract) {
  const ordersBtn = document.getElementById('contractOrdersBtn');
  const actsBtn   = document.getElementById('contractActsBtn');

  if (ordersBtn) {
    const fresh = ordersBtn.cloneNode(true);
    ordersBtn.replaceWith(fresh);
    fresh.addEventListener('click', () => renderContractOrdersPanel(contract));
  }

  if (actsBtn) {
    const fresh = actsBtn.cloneNode(true);
    actsBtn.replaceWith(fresh);
    fresh.addEventListener('click', () => renderContractActsPanel(contract));
  }

  document.getElementById('contractOrdersPanelClose')?.addEventListener('click', () =>
    closeContractSubPanel('contractOrdersSubPanel'));
  document.getElementById('contractActsPanelClose')?.addEventListener('click', () =>
    closeContractSubPanel('contractActsSubPanel'));
}

function renderContractOrdersPanel(contract) {
  const panel = document.getElementById('contractOrdersSubPanel');
  if (!panel) return;

  const wrap = document.getElementById('contractOrdersPanelBody');
  if (!wrap) return;
  wrap.innerHTML = '';

  const orders = (state.orders || []).filter(o => o.contractId === contract.id);

  if (orders.length === 0) {
    wrap.innerHTML =
      '<div class="flex flex-col items-center justify-center py-12 text-center">' +
      '<span class="text-4xl mb-3" aria-hidden="true">📋</span>' +
      '<p class="text-sm font-semibold text-slate-300">Заявок по контракту нет</p>' +
      '<p class="text-xs text-slate-500 mt-1">Добавьте заявки в разделе «Заявки»</p>' +
      '</div>';
  } else {
    [...orders].reverse().forEach(order => {
      const totalCost = (order.deliveryRows || []).reduce(
        (s, r) => s + (Number(r.qty) || 0) * (Number(r.price) || 0), 0);
      const uniqueItems = new Set((order.deliveryRows || []).map(r => r.contractItemName)).size;
      const dateStr = order.createdAt
        ? new Date(order.createdAt).toLocaleDateString('ru-RU') : '';

      const card = document.createElement('div');
      card.className = 'rounded-xl border border-white/10 bg-white/5 px-4 py-3 space-y-1 cursor-pointer transition hover:bg-white/[0.08] hover:border-cyan-400/20 group';
      card.innerHTML =
        '<div class="flex items-center justify-between">' +
        '<p class="text-sm font-bold text-cyan-400">' + escHtml(order.orderNumber || ('#' + order.id)) + '</p>' +
        '<span class="text-[10px] text-cyan-400 opacity-0 group-hover:opacity-100 transition shrink-0 ml-2">Открыть →</span>' +
        '</div>' +
        (order.programCode ? '<p class="text-xs text-slate-400">Программа: ' + escHtml(order.programCode) + '</p>' : '') +
        (order.deliveryAddress ? '<p class="text-xs text-slate-400 truncate">📍 ' + escHtml(order.deliveryAddress) + '</p>' : '') +
        '<div class="flex gap-3 text-xs text-slate-500 flex-wrap">' +
        '<span>' + uniqueItems + ' поз.</span>' +
        '<span class="text-cyan-400/70 tabular-nums">' + fmtNum(totalCost) + ' ₽</span>' +
        (dateStr ? '<span>' + dateStr + '</span>' : '') +
        '</div>';

      card.addEventListener('click', () => {
        closeContractSubPanel('contractOrdersSubPanel');
        closeContractCard();
        closeContractsModal();
        _openOrdersModal();
        setTimeout(() => _openOrderCard(order.id, true), 60);
      });

      wrap.appendChild(card);
    });
  }

  openContractSubPanel('contractOrdersSubPanel');
}

function renderContractActsPanel(contract) {
  const panel = document.getElementById('contractActsSubPanel');
  if (!panel) return;

  const wrap = document.getElementById('contractActsPanelBody');
  if (!wrap) return;
  wrap.innerHTML = '';

  const acts = getActsForContract(contract.id);

  if (acts.length === 0) {
    wrap.innerHTML =
      '<div class="flex flex-col items-center justify-center py-12 text-center">' +
      '<span class="text-4xl mb-3" aria-hidden="true">🔍</span>' +
      '<p class="text-sm font-semibold text-slate-300">Проверок по контракту нет</p>' +
      '<p class="text-xs text-slate-500 mt-1">Создайте акт в разделе «Приёмка» → «Сформировать акт»</p>' +
      '</div>';
  } else {
    acts.forEach(act => {
      const actDate = act.date ? fmtDate(act.date) : '—';
      const savedAt = act.savedAt
        ? new Date(act.savedAt).toLocaleString('ru-RU', {
            day: '2-digit', month: '2-digit', year: 'numeric',
            hour: '2-digit', minute: '2-digit' }) : '';
      const itemCount = (act.selectedItems || []).filter(si => si.selected !== false).length;
      const hasNonConform = (act.selectedItems || []).some(si =>
        (si.specs || []).some(sp => sp.nonConform));

      const card = document.createElement('div');
      card.className = 'rounded-xl border border-white/10 bg-white/5 px-4 py-3 space-y-1 cursor-pointer transition hover:bg-white/[0.09] hover:border-cyan-400/20 group';
      card.innerHTML =
        '<div class="flex items-center gap-2 flex-wrap">' +
        '<p class="text-sm font-semibold text-white">Проверка от ' + escHtml(actDate) + '</p>' +
        (hasNonConform
          ? '<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-red-500/15 text-red-400">Несоответствия</span>'
          : '<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-green-500/15 text-green-400">Без замечаний</span>') +
        '<span class="ml-auto opacity-0 group-hover:opacity-100 transition text-xs text-cyan-400">Открыть →</span>' +
        '</div>' +
        (act.location ? '<p class="text-xs text-slate-400">📍 ' + escHtml(act.location) + '</p>' : '') +
        '<div class="flex gap-3 text-xs text-slate-500 flex-wrap">' +
        (itemCount > 0 ? '<span>' + itemCount + ' поз.</span>' : '') +
        (savedAt ? '<span>Сохранён: ' + escHtml(savedAt) + '</span>' : '') +
        '</div>' +
        (act.result ? '<p class="text-xs text-slate-300 mt-1 line-clamp-2">' + escHtml(act.result) + '</p>' : '') +
        '<div class="flex gap-2 pt-1">' +
        '<button class="act-open-btn inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-cyan-400/10 hover:border-cyan-400/30 hover:text-cyan-400" data-act-id="' + act.id + '" aria-label="Открыть акт">🔍 Просмотр</button>' +
        '<button class="act-dl-btn inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-cyan-400/10 hover:border-cyan-400/30 hover:text-cyan-400" data-act-id="' + act.id + '" aria-label="Скачать акт">📄 .docx</button>' +
        '</div>';

      card.querySelector('.act-open-btn')?.addEventListener('click', e => {
        e.stopPropagation();
        closeContractSubPanel('contractActsSubPanel');
        closeContractCard();
        closeContractsModal();
        import('./receiving-view.js').then(m => {
          m.openReceivingModal();
          setTimeout(() => {
            document.getElementById('receivingTabActs')?.click();
          }, 80);
        });
      });

      card.querySelector('.act-dl-btn')?.addEventListener('click', e => {
        e.stopPropagation();
        generateAndDownload(act.id);
      });

      wrap.appendChild(card);
    });
  }

  openContractSubPanel('contractActsSubPanel');
}

function fmtDate(iso) {
  if (!iso) return '';
  try { const [y, m, d] = iso.split('-'); return d + '.' + m + '.' + y; } catch { return iso; }
}

// ─── Init ──────────────────────────────────────────────────────────

export function initContractsView() {
  document.getElementById('addContractListBtn')?.addEventListener('click', () => openContractCard(null));
  document.getElementById('contractsCloseBtn')?.addEventListener('click', closeContractsModal);
  document.getElementById('contractCardBackBtn')?.addEventListener('click', closeContractCard);
  document.getElementById('contractCardSaveBtn')?.addEventListener('click', saveContractCard);
  document.getElementById('contractCardEditBtn')?.addEventListener('click', () => {
    setContractCardReadonly(false);
  });

  const modal = document.getElementById('contractsModal');
  if (modal) {
    modal.addEventListener('click', e => {
      if (e.target === modal) closeContractsModal();
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && modal.classList.contains('open')) {
        const editPanel = document.getElementById('contractEditPanel');
        if (editPanel && !editPanel.classList.contains('hidden')) {
          closeContractCard();
        } else {
          closeContractsModal();
        }
      }
    });
  }
}

// ─── Utility ──────────────────────────────────────────────────────

function escHtml(str) {
  return String(str ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
