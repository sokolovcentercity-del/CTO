/**
 * Needs Matrix View — сводная таблица потребностей.
 * Виртуализация: первые 50 строк сразу, по 50 при скролле к низу.
 * Режим «по программам» — тоже виртуализация по 50 строк.
 * Фильтр по получателям, категории, товарной группе, поиску.
 */

import { $, el, clearChildren } from './dom.js';
import { state, updateRecipientNeeds, getRecipientById } from '../state.js';
import { saveToStorage } from '../storage.js';
import { loadXLSX } from './lib-loader.js';

const t = (key, vals) => window.miniappI18n?.t(key, vals) ?? key;

// ─── State ───────────────────────────────────────────────────────
let filterText        = '';
let filterCategory    = '';
let filterGroup       = '';
let filterRecipients  = new Set(); // пустой = показать всех
let sortField         = '';
let sortDir           = 1;
let groupMode         = 'all'; // 'all' | 'program'

let _lastProducts  = [];
let _lastRecipients = [];

// ─── Ширины фиксированных столбцов ───────────────────────────────
const LEFT_COLS = [
  { key: 'number',       label: () => t('needsMatrix.colNumber'),      w: 50  },
  { key: 'name',         label: () => t('needsMatrix.colProduct'),      w: 200 },
  { key: 'category',     label: () => t('needsMatrix.colCategory'),     w: 130 },
  { key: 'productGroup', label: () => t('needsMatrix.colProductGroup'), w: 130 },
];
const TOTAL_COL_WIDTH = 90;
const CHUNK_SIZE = 50;

const _leftOffsets = (() => {
  const offsets = [];
  let off = 0;
  LEFT_COLS.forEach(lc => { offsets.push(off); off += lc.w; });
  return offsets;
})();
const _totalColLeft = LEFT_COLS.reduce((s, lc) => s + lc.w, 0);

// ─── Public API ──────────────────────────────────────────────────

export function renderNeedsMatrix(containerId = 'needsMatrixWrap') {
  const wrap = $(containerId);
  if (!wrap) return;

  // Найти или создать tableArea (после фильтр-бара)
  let tableArea = wrap.querySelector('.needs-table-area');
  if (!tableArea) {
    tableArea = document.createElement('div');
    tableArea.className = 'needs-table-area';
    tableArea.style.cssText = 'flex:1 1 0;min-height:0;overflow:hidden;display:flex;flex-direction:column;';
    wrap.appendChild(tableArea);
  }
  clearChildren(tableArea);

  const products   = state.products;
  _lastProducts    = products;
  _lastRecipients  = state.recipients;

  if (products.length === 0 && state.recipients.length === 0) {
    tableArea.appendChild(emptyState('📊', t('needsMatrix.noData'), t('needsMatrix.noDataHint')));
    return;
  }
  if (products.length === 0) {
    tableArea.appendChild(emptyState('📋', t('needsMatrix.noProducts'), t('needsMatrix.noProductsHint')));
    return;
  }
  if (state.recipients.length === 0) {
    tableArea.appendChild(emptyState('👥', t('needsMatrix.noRecipients'), t('needsMatrix.noRecipientsHint')));
    return;
  }

  const sorted = applyFilters([...products].sort((a, b) => (a.number || 0) - (b.number || 0)));
  const recipients = getFilteredRecipients();

  if (recipients.length === 0) {
    tableArea.appendChild(emptyState('👥', 'Получатели не выбраны', 'Выберите получателей в фильтре выше'));
    return;
  }

  if (groupMode === 'program') {
    renderGroupedByProgram(tableArea, sorted, recipients);
  } else {
    renderFlat(tableArea, sorted, recipients);
  }
}

export function setGroupMode(mode) { groupMode = mode; }
export function getGroupMode()     { return groupMode; }

// ─── Excel Export ─────────────────────────────────────────────────

export async function exportNeedsMatrix() {
  const btn = document.getElementById('needsExportBtn');
  const origHTML = btn ? btn.innerHTML : '';
  if (btn) { btn.disabled = true; btn.innerHTML = '<span>⏳</span><span>Экспорт…</span>'; }
  try {
    const XLSX = await loadXLSX();
    const products   = applyFilters([...state.products].sort((a, b) => (a.number || 0) - (b.number || 0)));
    const recipients = getFilteredRecipients();
    const cols       = buildRecipientColumns(recipients);
    const spans      = buildRecipientSpans(cols);

    const row1 = ['№', 'Наименование', 'Категория', 'Товарная группа', 'Итого'];
    spans.forEach(({ recipient: r, span }) => {
      row1.push(r.name);
      for (let i = 1; i < span; i++) row1.push('');
    });
    const row2 = ['', '', '', '', ''];
    cols.forEach(col => row2.push(col.address || ''));
    const row3 = ['', '', '', '', ''];
    spans.forEach(({ recipient: r, span }) => {
      row3.push((r.targetProgram || '').trim() || '');
      for (let i = 1; i < span; i++) row3.push('');
    });
    const row4 = ['', '', '', '', 'Итого'];
    cols.forEach(col => {
      let colTotal = 0;
      products.forEach(p => { colTotal += getQty(col.recipient, p.id); });
      row4.push(colTotal > 0 ? colTotal : '');
    });

    const ws_data = [row1, row2, row3, row4];
    products.forEach(product => {
      let rowTotal = 0;
      const qtyArr = [];
      cols.forEach(col => {
        const qty = getQty(col.recipient, product.id);
        rowTotal += qty;
        qtyArr.push(qty > 0 ? qty : '');
      });
      ws_data.push([
        product.number || '', product.name || '',
        product.category || '', product.productGroup || '',
        rowTotal > 0 ? rowTotal : '', ...qtyArr,
      ]);
    });

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(ws_data);
    ws['!cols'] = [
      { wch: 5 }, { wch: 35 }, { wch: 20 }, { wch: 22 }, { wch: 9 },
      ...cols.map(() => ({ wch: 12 })),
    ];
    const merges = [];
    let colIdx = 5;
    spans.forEach(({ span }) => {
      if (span > 1) {
        merges.push({ s: { r: 0, c: colIdx }, e: { r: 0, c: colIdx + span - 1 } });
        merges.push({ s: { r: 2, c: colIdx }, e: { r: 2, c: colIdx + span - 1 } });
      }
      colIdx += span;
    });
    if (merges.length) ws['!merges'] = merges;
    XLSX.utils.book_append_sheet(wb, ws, 'Потребность');
    const dateStr = new Date().toISOString().slice(0, 10);
    XLSX.writeFile(wb, `needs-matrix-${dateStr}.xlsx`);
    try { (await import('./toast.js')).showToast('✅ Файл экспортирован', 'success'); } catch { /**/ }
  } catch (err) {
    console.error('[needs-matrix] export error:', err);
    try { (await import('./toast.js')).showToast('❌ Ошибка экспорта: ' + (err?.message || err), 'error'); } catch { /**/ }
  } finally {
    if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
  }
}

// ─── Filters bar ─────────────────────────────────────────────────

export function renderFiltersBar(containerId = 'needsMatrixWrap') {
  const wrap = $(containerId);
  if (!wrap) return;

  const existing = wrap.querySelector('.needs-filter-bar');
  if (existing) {
    // обновить значения без пересоздания
    const inp = existing.querySelector('input[data-role=search]');
    if (inp) inp.value = filterText;
    _updateSelectOptions(existing);
    _updateRecipientFilter(existing, containerId);
    return;
  }

  const bar = document.createElement('div');
  bar.className = 'needs-filter-bar';
  bar.style.cssText = 'display:flex;flex-wrap:wrap;gap:0.5rem;padding:0.6rem 1rem;border-bottom:1px solid rgba(255,255,255,0.08);background:rgba(2,6,23,0.7);flex-shrink:0;align-items:center;';

  // ── Поиск по товару ──
  const searchWrap = document.createElement('div');
  searchWrap.style.cssText = 'position:relative;flex:1;min-width:160px;max-width:240px;';
  const searchIcon = document.createElement('span');
  searchIcon.textContent = '🔍';
  searchIcon.style.cssText = 'position:absolute;left:0.65rem;top:50%;transform:translateY(-50%);pointer-events:none;font-size:0.75rem;';
  const searchInput = document.createElement('input');
  searchInput.type = 'search';
  searchInput.dataset.role = 'search';
  searchInput.placeholder = 'Поиск по товару…';
  searchInput.value = filterText;
  searchInput.setAttribute('aria-label', 'Поиск по товару');
  searchInput.style.cssText = 'width:100%;box-sizing:border-box;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:0.65rem;padding:0.45rem 0.75rem 0.45rem 2rem;font-size:0.78rem;color:#fff;outline:none;';
  let _debounce = null;
  searchInput.addEventListener('input', () => {
    clearTimeout(_debounce);
    _debounce = setTimeout(() => {
      filterText = searchInput.value;
      requestAnimationFrame(() => renderNeedsMatrix(containerId));
      _updateSelectOptions(bar);
    }, 300);
  });
  searchWrap.append(searchIcon, searchInput);
  bar.appendChild(searchWrap);

  // ── Категория ──
  const catSel = _buildSelect('cat-sel', 'Все категории', getUniqueValues('category', state.products), filterCategory);
  catSel.setAttribute('aria-label', 'Фильтр по категории');
  catSel.addEventListener('change', () => {
    filterCategory = catSel.value;
    requestAnimationFrame(() => renderNeedsMatrix(containerId));
  });
  bar.appendChild(catSel);

  // ── Товарная группа ──
  const grpSel = _buildSelect('grp-sel', 'Все группы', getUniqueValues('productGroup', state.products), filterGroup);
  grpSel.setAttribute('aria-label', 'Фильтр по товарной группе');
  grpSel.addEventListener('change', () => {
    filterGroup = grpSel.value;
    requestAnimationFrame(() => renderNeedsMatrix(containerId));
  });
  bar.appendChild(grpSel);

  // ── Фильтр по получателям ──
  const recWrap = _buildRecipientFilterUI(containerId);
  bar.appendChild(recWrap);

  // ── Сброс фильтров ──
  const resetBtn = document.createElement('button');
  resetBtn.textContent = '✕ Сброс';
  resetBtn.setAttribute('aria-label', 'Сбросить фильтры');
  resetBtn.style.cssText = 'background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:0.65rem;padding:0.45rem 0.75rem;font-size:0.78rem;color:rgb(148,163,184);cursor:pointer;white-space:nowrap;flex-shrink:0;';
  resetBtn.addEventListener('click', () => {
    filterText       = '';
    filterCategory   = '';
    filterGroup      = '';
    filterRecipients = new Set();
    searchInput.value = '';
    catSel.value = '';
    grpSel.value = '';
    _updateRecipientFilter(bar, containerId);
    requestAnimationFrame(() => renderNeedsMatrix(containerId));
  });
  bar.appendChild(resetBtn);

  const tableArea = wrap.querySelector('.needs-table-area');
  wrap.insertBefore(bar, tableArea || wrap.firstChild);
}

// ── Фильтр по получателям ──────────────────────────────────────

function _buildRecipientFilterUI(containerId) {
  const wrap = document.createElement('div');
  wrap.dataset.role = 'rec-filter-wrap';
  wrap.style.cssText = 'position:relative;flex-shrink:0;';

  const btn = document.createElement('button');
  btn.dataset.role = 'rec-filter-btn';
  btn.setAttribute('aria-label', 'Фильтр по получателям');
  btn.style.cssText = 'display:flex;align-items:center;gap:0.4rem;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:0.65rem;padding:0.45rem 0.75rem;font-size:0.78rem;color:rgb(203,213,225);cursor:pointer;white-space:nowrap;';
  btn.innerHTML = '<span>👥</span><span data-role="rec-btn-label">Получатели</span>';
  wrap.appendChild(btn);

  const dropdown = document.createElement('div');
  dropdown.dataset.role = 'rec-dropdown';
  dropdown.style.cssText = 'display:none;position:absolute;top:calc(100% + 4px);left:0;z-index:200;min-width:280px;max-width:360px;background:rgb(15,23,42);border:1px solid rgba(255,255,255,0.12);border-radius:0.75rem;box-shadow:0 8px 32px rgba(0,0,0,0.5);padding:0.5rem;';

  // Поиск внутри дропдауна
  const ddSearch = document.createElement('input');
  ddSearch.type = 'search';
  ddSearch.placeholder = 'Поиск получателя…';
  ddSearch.setAttribute('aria-label', 'Поиск получателя');
  ddSearch.style.cssText = 'width:100%;box-sizing:border-box;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:0.5rem;padding:0.4rem 0.65rem;font-size:0.78rem;color:#fff;outline:none;margin-bottom:0.4rem;';
  dropdown.appendChild(ddSearch);

  // Кнопки выбрать всё / снять всё
  const ddActions = document.createElement('div');
  ddActions.style.cssText = 'display:flex;gap:0.4rem;margin-bottom:0.4rem;';
  const selAllBtn = document.createElement('button');
  selAllBtn.textContent = 'Выбрать все';
  selAllBtn.style.cssText = 'flex:1;background:rgba(34,211,238,0.1);border:1px solid rgba(34,211,238,0.2);border-radius:0.5rem;padding:0.3rem 0.5rem;font-size:0.72rem;color:rgb(34,211,238);cursor:pointer;';
  const clearAllBtn = document.createElement('button');
  clearAllBtn.textContent = 'Снять все';
  clearAllBtn.style.cssText = 'flex:1;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:0.5rem;padding:0.3rem 0.5rem;font-size:0.72rem;color:rgb(148,163,184);cursor:pointer;';
  ddActions.append(selAllBtn, clearAllBtn);
  dropdown.appendChild(ddActions);

  // Список получателей
  const list = document.createElement('div');
  list.dataset.role = 'rec-list';
  list.style.cssText = 'max-height:220px;overflow-y:auto;display:flex;flex-direction:column;gap:0.15rem;';
  dropdown.appendChild(list);

  wrap.appendChild(dropdown);

  function buildList(searchQ) {
    clearChildren(list);
    const q = (searchQ || '').toLowerCase();
    const recipients = state.recipients.filter(r =>
      !q || (r.name || '').toLowerCase().includes(q)
    );
    recipients.forEach(r => {
      const item = document.createElement('label');
      item.style.cssText = 'display:flex;align-items:center;gap:0.5rem;padding:0.35rem 0.5rem;border-radius:0.4rem;cursor:pointer;transition:background 0.1s;';
      item.addEventListener('mouseenter', () => { item.style.background = 'rgba(255,255,255,0.05)'; });
      item.addEventListener('mouseleave', () => { item.style.background = ''; });
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = filterRecipients.size === 0 ? true
        : filterRecipients.has(-1) ? false
        : filterRecipients.has(r.id);
      cb.style.cssText = 'accent-color:rgb(34,211,238);flex-shrink:0;width:14px;height:14px;cursor:pointer;';
      const nameSpan = document.createElement('span');
      nameSpan.style.cssText = 'font-size:0.78rem;color:rgb(203,213,225);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
      nameSpan.textContent = r.name || '—';
      nameSpan.title = r.name || '';
      item.append(cb, nameSpan);
      cb.addEventListener('change', () => {
        if (filterRecipients.size === 0) {
          // Был «все» — переключаемся в режим явного выбора
          state.recipients.forEach(rec => filterRecipients.add(rec.id));
        } else if (filterRecipients.has(-1)) {
          // Был «снять все» — начинаем с пустого явного выбора
          filterRecipients = new Set();
        }
        if (cb.checked) {
          filterRecipients.add(r.id);
        } else {
          filterRecipients.delete(r.id);
        }
        // Если выбраны все — вернуться к «все»
        if (filterRecipients.size >= state.recipients.length) filterRecipients = new Set();
        _updateRecipientBtnLabel(wrap);
        requestAnimationFrame(() => renderNeedsMatrix(containerId));
      });
      list.appendChild(item);
    });
    if (recipients.length === 0) {
      const empty = document.createElement('div');
      empty.style.cssText = 'font-size:0.75rem;color:rgb(100,116,139);padding:0.5rem;text-align:center;';
      empty.textContent = 'Не найдено';
      list.appendChild(empty);
    }
  }

  selAllBtn.addEventListener('click', () => {
    filterRecipients = new Set(); // пустой = все
    buildList(ddSearch.value);
    _updateRecipientBtnLabel(wrap);
    requestAnimationFrame(() => renderNeedsMatrix(containerId));
  });
  clearAllBtn.addEventListener('click', () => {
    // Снять все = filterRecipients содержит пустой Set, но getFilteredRecipients вернёт []
    // Используем специальный маркер: Set с несуществующим id
    filterRecipients = new Set([-1]); // -1 не совпадёт ни с одним recipient.id
    buildList(ddSearch.value);
    _updateRecipientBtnLabel(wrap);
    requestAnimationFrame(() => renderNeedsMatrix(containerId));
  });

  ddSearch.addEventListener('input', () => buildList(ddSearch.value));

  // Открыть/закрыть дропдаун
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    const isOpen = dropdown.style.display !== 'none';
    if (isOpen) {
      dropdown.style.display = 'none';
    } else {
      buildList('');
      ddSearch.value = '';
      dropdown.style.display = 'block';
      setTimeout(() => ddSearch.focus(), 50);
    }
  });

  // Закрыть при клике вне
  document.addEventListener('click', (e) => {
    if (!wrap.contains(e.target)) dropdown.style.display = 'none';
  });

  _updateRecipientBtnLabel(wrap);
  return wrap;
}

function _updateRecipientBtnLabel(wrap) {
  const label = wrap.querySelector('[data-role=rec-btn-label]');
  if (!label) return;
  if (filterRecipients.size === 0) {
    label.textContent = 'Получатели';
  } else if (filterRecipients.has(-1)) {
    label.textContent = 'Получатели (0)';
  } else {
    label.textContent = `Получатели (${filterRecipients.size})`;
  }
}

function _updateRecipientFilter(bar, containerId) {
  const wrap = bar.querySelector('[data-role=rec-filter-wrap]');
  if (wrap) _updateRecipientBtnLabel(wrap);
}

// ── Получатели с учётом фильтра ────────────────────────────────

function getFilteredRecipients() {
  if (filterRecipients.size === 0) return state.recipients; // пустой = все
  if (filterRecipients.has(-1)) return []; // «снять все» маркер
  return state.recipients.filter(r => filterRecipients.has(r.id));
}

// ─── Select helpers ───────────────────────────────────────────────

function _buildSelect(className, placeholder, options, value) {
  const sel = document.createElement('select');
  sel.className = className;
  sel.style.cssText = 'background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:0.65rem;padding:0.45rem 0.65rem;font-size:0.78rem;color:rgb(203,213,225);min-width:130px;outline:none;flex-shrink:0;';
  const def = document.createElement('option');
  def.value = ''; def.textContent = placeholder;
  sel.appendChild(def);
  options.forEach(o => {
    const opt = document.createElement('option');
    opt.value = o; opt.textContent = o;
    if (o === value) opt.selected = true;
    sel.appendChild(opt);
  });
  return sel;
}

function _updateSelectOptions(bar) {
  const catSel = bar.querySelector('.cat-sel');
  const grpSel = bar.querySelector('.grp-sel');
  if (catSel) {
    const prev = catSel.value;
    while (catSel.options.length > 1) catSel.remove(1);
    getUniqueValues('category', state.products).forEach(o => {
      const opt = document.createElement('option');
      opt.value = o; opt.textContent = o;
      if (o === prev) opt.selected = true;
      catSel.appendChild(opt);
    });
  }
  if (grpSel) {
    const prev = grpSel.value;
    while (grpSel.options.length > 1) grpSel.remove(1);
    getUniqueValues('productGroup', state.products).forEach(o => {
      const opt = document.createElement('option');
      opt.value = o; opt.textContent = o;
      if (o === prev) opt.selected = true;
      grpSel.appendChild(opt);
    });
  }
}

// ─── Filter helpers ───────────────────────────────────────────────

function applyFilters(products) {
  let result = products;
  const q = filterText.trim().toLowerCase();
  if (q) result = result.filter(p =>
    (p.name || '').toLowerCase().includes(q) || (p.code || '').toLowerCase().includes(q)
  );
  if (filterCategory) result = result.filter(p => (p.category || '') === filterCategory);
  if (filterGroup)    result = result.filter(p => (p.productGroup || '') === filterGroup);
  if (sortField) {
    result = [...result].sort((a, b) => {
      const va = (a[sortField] || '').toLowerCase();
      const vb = (b[sortField] || '').toLowerCase();
      return va < vb ? -sortDir : va > vb ? sortDir : 0;
    });
  }
  return result;
}

function getUniqueValues(field, products) {
  const set = new Set();
  (products || []).forEach(p => { if (p[field]) set.add(p[field]); });
  return [...set].sort((a, b) => a.localeCompare(b));
}

// ─── Helpers ─────────────────────────────────────────────────────

function emptyState(icon, title, hint) {
  return el('div', { className: 'flex flex-col items-center justify-center py-16 text-center' },
    el('span', { className: 'text-4xl mb-3' }, icon),
    el('p',    { className: 'text-sm font-semibold text-slate-300 mb-1' }, title),
    el('p',    { className: 'text-xs text-slate-500' }, hint),
  );
}

function getQty(recipient, productId) {
  const entry = recipient.needs?.[productId];
  return typeof entry === 'object' ? (entry.qty || 0) : (entry || 0);
}

function splitAddresses(addressStr) {
  if (!addressStr || !addressStr.trim()) return [''];
  const parts = addressStr.split(/[\n;]+/).map(a => a.trim()).filter(Boolean);
  return parts.length > 0 ? parts : [''];
}

function buildRecipientColumns(recipients) {
  const cols = [];
  recipients.forEach(r => {
    splitAddresses(r.address || '').forEach(addr => cols.push({ recipient: r, address: addr }));
  });
  return cols;
}

function buildRecipientSpans(cols) {
  const spans = [];
  let i = 0;
  while (i < cols.length) {
    const r = cols[i].recipient;
    const start = i;
    while (i < cols.length && cols[i].recipient.id === r.id) i++;
    spans.push({ recipient: r, span: i - start });
  }
  return spans;
}

// ─── Общий scroll-контейнер ───────────────────────────────────────
// overflow:auto по обеим осям — горизонтальная прокрутка работает

function makeScrollWrap() {
  const wrap = document.createElement('div');
  wrap.style.cssText = [
    'flex:1 1 0',
    'min-height:0',
    'overflow-x:scroll',
    'overflow-y:auto',
    'scrollbar-gutter:stable',
    '-webkit-overflow-scrolling:touch',
  ].join(';');
  wrap.scrollTop  = 0;
  wrap.scrollLeft = 0;
  return wrap;
}

// ─── Flat render с виртуализацией ────────────────────────────────

function renderFlat(tableArea, sorted, recipients) {
  // Единый контейнер — горизонтальный + вертикальный скролл
  const scrollWrap = makeScrollWrap();

  const cols  = buildRecipientColumns(recipients);
  const spans = buildRecipientSpans(cols);

  const { table, tbody } = buildTableHead(cols, spans, sorted, 'all');

  appendChunk(tbody, sorted, cols, 'all', 0, Math.min(CHUNK_SIZE, sorted.length));

  let nextIndex = Math.min(CHUNK_SIZE, sorted.length);

  const observer = new IntersectionObserver((entries) => {
    if (!entries[0].isIntersecting) return;
    if (nextIndex >= sorted.length) { observer.disconnect(); return; }
    const end = Math.min(nextIndex + CHUNK_SIZE, sorted.length);
    appendChunk(tbody, sorted, cols, 'all', nextIndex, end);
    nextIndex = end;
    if (nextIndex >= sorted.length) { observer.disconnect(); }
  }, { root: null, threshold: 0 });

  const wrapper = document.createElement('div');
  wrapper.style.cssText = 'padding:1rem 1.25rem;min-width:max-content;';
  wrapper.appendChild(table);
  scrollWrap.appendChild(wrapper);

  // Sentinel внутри wrapper — следит за вертикальным скроллом внутри scrollWrap
  const sentinel = makeSentinel();
  wrapper.appendChild(sentinel);
  observer.observe(sentinel);

  tableArea.appendChild(scrollWrap);
}

// ─── Grouped by program render ────────────────────────────────────

function renderGroupedByProgram(tableArea, sorted, recipients) {
  const programMap = new Map();
  const noProgram  = t('needsMatrix.noProgram');

  recipients.forEach(r => {
    const prog = (r.targetProgram || '').trim() || noProgram;
    if (!programMap.has(prog)) programMap.set(prog, []);
    programMap.get(prog).push(r);
  });

  const programNames = [...programMap.keys()].sort((a, b) => {
    if (a === noProgram) return 1;
    if (b === noProgram) return -1;
    return a.localeCompare(b);
  });

  // Внешний скролл-контейнер — вертикальный (список секций)
  const outerScroll = document.createElement('div');
  outerScroll.style.cssText = 'flex:1 1 0;min-height:0;overflow-y:auto;padding:1rem 1.25rem;display:flex;flex-direction:column;gap:1.5rem;scrollbar-gutter:stable;';

  programNames.forEach(progName => {
    const progRecipients = programMap.get(progName);
    const section = document.createElement('div');
    section.style.cssText = 'border-radius:1rem;border:1px solid rgba(255,255,255,0.1);overflow:hidden;flex-shrink:0;';

    // Заголовок секции
    const header = document.createElement('div');
    header.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:0.75rem 1rem;background:rgba(255,255,255,0.04);border-bottom:1px solid rgba(255,255,255,0.1);';
    const titleWrap = document.createElement('div');
    titleWrap.style.cssText = 'display:flex;align-items:center;gap:0.5rem;min-width:0;';
    titleWrap.innerHTML = `<span>🎯</span><span style="font-size:0.875rem;font-weight:700;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${progName}</span>
      <span style="flex-shrink:0;border-radius:0.5rem;background:rgba(71,85,105,0.5);padding:0.1rem 0.5rem;font-size:0.75rem;font-weight:600;color:rgb(203,213,225);">${progRecipients.length} ${recipientsWord(progRecipients.length)}</span>`;
    header.appendChild(titleWrap);

    const progTotal = calcGroupTotal(sorted, progRecipients);
    if (progTotal > 0) {
      const badge = document.createElement('span');
      badge.style.cssText = 'flex-shrink:0;border-radius:0.5rem;background:rgba(34,211,238,0.15);padding:0.25rem 0.625rem;font-size:0.75rem;font-weight:700;color:rgb(34,211,238);';
      badge.textContent = t('needsMatrix.programTotal') + ': ' + progTotal;
      header.appendChild(badge);
    }
    section.appendChild(header);

    const cols  = buildRecipientColumns(progRecipients);
    const spans = buildRecipientSpans(cols);
    const { table, tbody } = buildTableHead(cols, spans, sorted, progName);

    // Горизонтальный скролл внутри секции + виртуализация строк
    const sectionScroll = document.createElement('div');
    sectionScroll.style.cssText = [
      'overflow-x:auto',
      'overflow-y:auto',
      'max-height:60vh',
      'scrollbar-gutter:stable',
      '-webkit-overflow-scrolling:touch',
    ].join(';');

    // Рендерим первый чанк
    appendChunk(tbody, sorted, cols, progName, 0, Math.min(CHUNK_SIZE, sorted.length));

    const sentinel = makeSentinel();
    let nextIndex = Math.min(CHUNK_SIZE, sorted.length);

    const observer = new IntersectionObserver((entries) => {
      if (!entries[0].isIntersecting) return;
      if (nextIndex >= sorted.length) { observer.disconnect(); sentinel.remove(); return; }
      const end = Math.min(nextIndex + CHUNK_SIZE, sorted.length);
      appendChunk(tbody, sorted, cols, progName, nextIndex, end);
      nextIndex = end;
      if (nextIndex >= sorted.length) { observer.disconnect(); sentinel.remove(); }
    }, { root: sectionScroll, threshold: 0 });

    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'padding:0 1rem 1rem;min-width:max-content;';
    wrapper.appendChild(table);
    sectionScroll.appendChild(wrapper);
    sectionScroll.appendChild(sentinel);
    observer.observe(sentinel);

    section.appendChild(sectionScroll);
    outerScroll.appendChild(section);
  });

  if (programNames.length > 1) {
    const grandTotal = calcGroupTotal(sorted, recipients);
    if (grandTotal > 0) {
      const grandRow = document.createElement('div');
      grandRow.style.cssText = 'display:flex;align-items:center;justify-content:space-between;border-radius:1rem;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.03);padding:0.75rem 1rem;flex-shrink:0;';
      grandRow.innerHTML = `<span style="font-size:0.75rem;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;color:rgb(148,163,184);">${t('needsMatrix.grandTotal')}</span>
        <span style="border-radius:0.5rem;background:rgba(34,211,238,0.2);padding:0.25rem 0.75rem;font-size:0.875rem;font-weight:700;color:rgb(34,211,238);">${grandTotal}</span>`;
      outerScroll.appendChild(grandRow);
    }
  }

  tableArea.appendChild(outerScroll);
}

function makeSentinel() {
  const s = document.createElement('div');
  s.style.cssText = 'height:1px;width:100%;flex-shrink:0;';
  return s;
}

function calcGroupTotal(products, recipients) {
  let total = 0;
  recipients.forEach(r => { products.forEach(p => { total += getQty(r, p.id); }); });
  return total;
}

function recipientsWord(n) {
  if (n % 10 === 1 && n % 100 !== 11) return 'получатель';
  if ([2, 3, 4].includes(n % 10) && ![12, 13, 14].includes(n % 100)) return 'получателя';
  return 'получателей';
}

// ─── Добавить чанк строк в tbody ─────────────────────────────────

function appendChunk(tbody, sorted, cols, groupKey, fromIdx, toIdx) {
  const end = (toIdx !== undefined) ? toIdx : Math.min(fromIdx + CHUNK_SIZE, sorted.length);
  const fragment = document.createDocumentFragment();
  for (let i = fromIdx; i < end; i++) {
    fragment.appendChild(buildProductRow(sorted[i], cols, groupKey));
  }
  tbody.appendChild(fragment);
}

// ─── Table head builder ───────────────────────────────────────────

function buildTableHead(cols, spans, sorted, groupKey) {
  const leftOffsets  = _leftOffsets;
  const totalColLeft = _totalColLeft;
  const fixedWidth   = totalColLeft + TOTAL_COL_WIDTH;

  const table = document.createElement('table');
  table.className = 'w-full text-sm border-collapse';
  table.style.minWidth = `${fixedWidth + cols.length * 110}px`;

  const sticky = 'sticky z-10 bg-slate-900';
  const thead = document.createElement('thead');
  thead.style.cssText = 'position:sticky;top:0;z-index:18;';

  // Row 1: фиксированные заголовки (rowspan=4) + Итого + имена
  const row1 = document.createElement('tr');
  LEFT_COLS.forEach((lc, i) => {
    const th = document.createElement('th');
    th.className = `${sticky} px-3 py-2 text-left text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-white/10 align-middle`;
    th.rowSpan = 4;
    th.style.left   = leftOffsets[i] + 'px';
    th.style.zIndex = '22';
    th.textContent  = lc.label();
    row1.appendChild(th);
  });

  const totalTh = document.createElement('th');
  totalTh.className = `${sticky} px-3 py-2 text-center text-xs font-semibold text-cyan-400 uppercase tracking-wider border-b border-white/10 border-l border-r border-white/15 align-middle`;
  totalTh.rowSpan = 4;
  totalTh.style.left     = totalColLeft + 'px';
  totalTh.style.zIndex   = '22';
  totalTh.style.minWidth = TOTAL_COL_WIDTH + 'px';
  totalTh.textContent    = t('needsMatrix.colTotal');
  row1.appendChild(totalTh);

  spans.forEach(({ recipient: r, span }) => {
    const th = document.createElement('th');
    th.className = 'px-3 py-2 text-center text-xs font-semibold text-slate-300 uppercase tracking-wider border-b border-white/10 border-l border-white/5';
    th.colSpan = span;
    const nameSpan = document.createElement('span');
    nameSpan.className = 'block truncate max-w-[200px] mx-auto';
    nameSpan.title = r.name;
    nameSpan.textContent = r.name;
    th.appendChild(nameSpan);
    row1.appendChild(th);
  });
  thead.appendChild(row1);

  // Row 2: адреса
  const row2 = document.createElement('tr');
  row2.style.cssText = 'position:sticky;top:36px;z-index:17;';
  cols.forEach((col, ci) => {
    const isFirst = ci === 0 || cols[ci - 1].recipient.id !== col.recipient.id;
    const td = document.createElement('td');
    td.className = `px-2 py-1.5 text-[10px] border-b border-white/8 align-middle text-center ${isFirst ? 'border-l border-white/5' : ''} ${col.address ? 'text-slate-400' : 'text-slate-600'}`;
    td.style.background = 'rgb(11,17,34)';
    td.textContent = col.address || '—';
    if (col.address) td.title = col.address;
    row2.appendChild(td);
  });
  thead.appendChild(row2);

  // Row 3: программы
  const row3 = document.createElement('tr');
  row3.style.cssText = 'position:sticky;top:60px;z-index:17;';
  spans.forEach(({ recipient: r, span }) => {
    const td = document.createElement('td');
    td.className = 'px-2 py-1.5 text-[10px] border-b border-white/10 text-center align-middle border-l border-white/5';
    td.colSpan = span;
    td.style.background = 'rgb(9,14,28)';
    const prog = (r.targetProgram || '').trim();
    td.textContent = prog || '—';
    if (prog) { td.title = prog; td.classList.add('text-amber-400/80', 'font-medium'); }
    else td.classList.add('text-slate-600');
    row3.appendChild(td);
  });
  thead.appendChild(row3);

  // Row 4: итоги по столбцам
  const row4 = document.createElement('tr');
  row4.style.cssText = 'position:sticky;top:84px;z-index:17;';
  cols.forEach((col, ci) => {
    const r = col.recipient;
    let colTotal = 0;
    sorted.forEach(p => { colTotal += getQty(r, p.id); });
    const isFirst = ci === 0 || cols[ci - 1].recipient.id !== r.id;
    const td = document.createElement('td');
    td.className = `px-3 py-2 text-center border-b-2 border-white/20 ${isFirst ? 'border-l border-white/5' : ''}`;
    td.style.background = 'rgb(15,23,42)';
    td.dataset.totalCol = String(r.id);
    td.dataset.group    = groupKey;
    const span = document.createElement('span');
    span.className = `text-sm font-bold tabular-nums ${colTotal > 0 ? 'text-cyan-400' : 'text-slate-600'}`;
    span.textContent = colTotal > 0 ? String(colTotal) : '—';
    td.appendChild(span);
    row4.appendChild(td);
  });
  thead.appendChild(row4);

  const tbody = document.createElement('tbody');
  table.appendChild(thead);
  table.appendChild(tbody);

  return { table, tbody };
}

// ─── Single product row builder ───────────────────────────────────

function buildProductRow(product, cols, groupKey) {
  const sticky = 'sticky z-10 bg-slate-900';
  const row = document.createElement('tr');
  row.className = 'group hover:bg-white/[0.03] transition-colors';

  // №
  const numCell = document.createElement('td');
  numCell.className = `${sticky} group-hover:bg-slate-900/90 px-2 py-2.5 text-xs font-bold text-cyan-400 tabular-nums text-center transition-colors`;
  numCell.style.left = _leftOffsets[0] + 'px'; numCell.style.zIndex = '11';
  numCell.textContent = String(product.number || '');
  row.appendChild(numCell);

  // Наименование
  const nameCell = document.createElement('td');
  nameCell.className = `${sticky} group-hover:bg-slate-900/90 px-3 py-2.5 transition-colors`;
  nameCell.style.left = _leftOffsets[1] + 'px'; nameCell.style.zIndex = '11';
  nameCell.style.minWidth = '180px'; nameCell.style.maxWidth = '240px';
  const nameSpan = document.createElement('span');
  nameSpan.className = 'text-sm text-white font-medium block truncate';
  nameSpan.title = product.name || '';
  nameSpan.textContent = product.name || '—';
  nameCell.appendChild(nameSpan);
  row.appendChild(nameCell);

  // Категория
  const catCell = document.createElement('td');
  catCell.className = `${sticky} group-hover:bg-slate-900/90 px-3 py-2.5 transition-colors`;
  catCell.style.left = _leftOffsets[2] + 'px'; catCell.style.zIndex = '11';
  catCell.style.minWidth = '110px'; catCell.style.maxWidth = '150px';
  const catSpan = document.createElement('span');
  catSpan.className = 'text-xs text-slate-400 block truncate';
  catSpan.title = product.category || '';
  catSpan.textContent = product.category || '—';
  catCell.appendChild(catSpan);
  row.appendChild(catCell);

  // Товарная группа
  const pgCell = document.createElement('td');
  pgCell.className = `${sticky} group-hover:bg-slate-900/90 px-3 py-2.5 transition-colors`;
  pgCell.style.left = _leftOffsets[3] + 'px'; pgCell.style.zIndex = '11';
  pgCell.style.minWidth = '110px'; pgCell.style.maxWidth = '150px';
  if (product.productGroup) {
    const pgBadge = document.createElement('span');
    pgBadge.className = 'text-xs text-violet-300 block truncate';
    pgBadge.title = product.productGroup;
    pgBadge.textContent = product.productGroup;
    pgCell.appendChild(pgBadge);
  } else {
    pgCell.textContent = '—';
    pgCell.classList.add('text-slate-600', 'text-xs');
  }
  row.appendChild(pgCell);

  // Итого по строке
  let rowTotal = 0;
  cols.forEach(col => { rowTotal += getQty(col.recipient, product.id); });
  const totalRowTd = document.createElement('td');
  totalRowTd.className = `${sticky} group-hover:bg-slate-900/90 px-3 py-2 text-center border-l border-r border-white/15 transition-colors`;
  totalRowTd.style.left = _totalColLeft + 'px'; totalRowTd.style.zIndex = '11';
  totalRowTd.dataset.totalRow = String(product.id);
  totalRowTd.dataset.group    = groupKey;
  const totalSpan = document.createElement('span');
  totalSpan.className = `text-sm font-semibold tabular-nums ${rowTotal > 0 ? 'text-cyan-400' : 'text-slate-600'}`;
  totalSpan.textContent = rowTotal > 0 ? String(rowTotal) : '—';
  totalRowTd.appendChild(totalSpan);
  row.appendChild(totalRowTd);

  // Ячейки получателей
  cols.forEach((col, ci) => {
    const r   = col.recipient;
    const qty = getQty(r, product.id);
    const isFirst = ci === 0 || cols[ci - 1].recipient.id !== r.id;
    const td = document.createElement('td');
    td.className = `px-2 py-2 text-center ${isFirst ? 'border-l border-white/5' : ''}`;
    td.dataset.productId   = String(product.id);
    td.dataset.recipientId = String(r.id);
    td.dataset.group       = groupKey;

    const input = document.createElement('input');
    input.type        = 'number';
    input.min         = '0';
    input.value       = qty > 0 ? String(qty) : '';
    input.placeholder = '—';
    input.className   = 'w-full rounded-lg border border-transparent bg-transparent text-center text-sm text-slate-200 tabular-nums py-1.5 px-1 transition focus:border-cyan-400/60 focus:bg-white/[0.07] hover:bg-white/5 placeholder-slate-600 focus:outline-none';
    input.setAttribute('aria-label', `${product.name} — ${r.name}`);
    input.addEventListener('change', () => handleCellChange(product.id, r.id, input));
    input.addEventListener('keydown', e => { if (e.key === 'Enter') input.blur(); });

    td.appendChild(input);
    row.appendChild(td);
  });

  return row;
}

// ─── Cell change handler ─────────────────────────────────────────

async function handleCellChange(productId, recipientId, input) {
  const rawVal = input.value.trim();
  const qty    = rawVal === '' ? 0 : Math.max(0, parseInt(rawVal, 10) || 0);
  input.value  = qty > 0 ? String(qty) : '';

  const r = getRecipientById(recipientId);
  if (!r) return;

  const existing = r.needs?.[productId];
  const newNeeds = { ...r.needs };

  if (qty === 0) {
    delete newNeeds[productId];
  } else {
    newNeeds[productId] = {
      qty,
      delivered: (typeof existing === 'object' ? existing.delivered : 0) || 0,
      assembled: (typeof existing === 'object' ? existing.assembled : 0) || 0,
    };
  }

  updateRecipientNeeds(recipientId, newNeeds);
  await saveToStorage();

  updateAllRowTotals(productId);
  updateAllColTotals(recipientId);
}

// ─── Partial re-renders ──────────────────────────────────────────

function updateAllRowTotals(productId) {
  document.querySelectorAll(`[data-total-row="${productId}"]`).forEach(cell => {
    const groupKey        = cell.dataset.group || 'all';
    const groupRecipients = getGroupRecipients(groupKey);
    let rowTotal = 0;
    groupRecipients.forEach(r => { rowTotal += getQty(r, productId); });
    clearChildren(cell);
    const span = document.createElement('span');
    span.className = `text-sm font-semibold tabular-nums ${rowTotal > 0 ? 'text-cyan-400' : 'text-slate-600'}`;
    span.textContent = rowTotal > 0 ? String(rowTotal) : '—';
    cell.appendChild(span);
  });
}

function updateAllColTotals(recipientId) {
  document.querySelectorAll(`[data-total-col="${recipientId}"]`).forEach(cell => {
    const r = getRecipientById(recipientId);
    if (!r) return;
    let colTotal = 0;
    state.products.forEach(p => { colTotal += getQty(r, p.id); });
    clearChildren(cell);
    const span = document.createElement('span');
    span.className = `text-sm font-bold tabular-nums ${colTotal > 0 ? 'text-cyan-400' : 'text-slate-600'}`;
    span.textContent = colTotal > 0 ? String(colTotal) : '—';
    cell.appendChild(span);
  });
}

function getGroupRecipients(groupKey) {
  if (groupKey === 'all') return getFilteredRecipients();
  const noProgram = t('needsMatrix.noProgram');
  return getFilteredRecipients().filter(r => {
    const prog = (r.targetProgram || '').trim() || noProgram;
    return prog === groupKey;
  });
}
