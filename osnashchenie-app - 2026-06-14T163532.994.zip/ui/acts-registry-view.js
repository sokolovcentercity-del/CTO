/**
 * Acts Registry View — реестр сохранённых актов проверки.
 * Two registries: SO checks and delivery checks.
 * Поиск по номеру контракта или поставщику.
 * Кнопка редактирования — открывает act-form-view с загруженными данными.
 */

import { state, deleteAct } from '../state.js';
import { saveToStorage } from '../storage.js';
import { showToast } from './toast.js';

const t = (key, vals) => window.miniappI18n?.t(key, vals) ?? key;

// ─── Search state ─────────────────────────────────────────────────

let _soSearch       = '';
let _deliverySearch = '';

// ─── Refresh hook (called after edit/delete) ──────────────────────

let _registryOpen = false;

export function refreshRegistryIfOpen() {
  if (_registryOpen) renderRegistry();
}

// ─── Inline (Receiving tab) state ─────────────────────────────────

let _inlineListWrap = null;

export function openActsRegistryInReceiving(container) {
  _inlineListWrap = container;
  _renderInlineRegistry(container);
}

function _renderInlineRegistry(container) {
  container.innerHTML = '';

  // Tabs
  const tabBar = document.createElement('div');
  tabBar.className = 'flex gap-1 mb-4 rounded-xl bg-white/[0.04] p-1';

  let activeTab = 'so';

  const soTabBtn  = _makeTabBtn('Акты СО',       true);
  const delTabBtn = _makeTabBtn('Акты поставки',  false);
  tabBar.append(soTabBtn, delTabBtn);
  container.appendChild(tabBar);

  const listWrap = document.createElement('div');
  container.appendChild(listWrap);

  function showTab(tab) {
    activeTab = tab;
    soTabBtn.classList.toggle('bg-white/10', tab === 'so');
    soTabBtn.classList.toggle('text-white',  tab === 'so');
    soTabBtn.classList.toggle('text-slate-400', tab !== 'so');
    delTabBtn.classList.toggle('bg-white/10', tab === 'delivery');
    delTabBtn.classList.toggle('text-white',  tab === 'delivery');
    delTabBtn.classList.toggle('text-slate-400', tab !== 'delivery');
    _renderActsListWithSearch(listWrap, tab, act => _openInlineDetail(act), () => _renderInlineRegistry(container));
  }

  soTabBtn.addEventListener('click',  () => showTab('so'));
  delTabBtn.addEventListener('click', () => showTab('delivery'));
  showTab('so');
}

function _makeTabBtn(label, active, count) {
  const btn = document.createElement('button');
  let html = esc(label);
  if (count != null && count > 0) {
    html += ` <span class="ml-1 rounded-full bg-white/10 px-1.5 py-0.5 text-[10px] font-semibold">${count}</span>`;
  }
  btn.innerHTML = html;
  btn.className = `flex-1 rounded-lg px-3 py-1.5 text-sm font-medium transition
    ${active ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-slate-200'}`;
  return btn;
}

function _openInlineDetail(act) {
  const listPanel  = document.getElementById('receivingListPanel');
  const cardPanel  = document.getElementById('receivingCardPanel');
  const titleEl    = document.getElementById('receivingCardTitle');
  const bodyWrap   = document.getElementById('receivingCardWrap');
  const actSection = cardPanel?.querySelector('.rounded-2xl.border-dashed');

  if (!listPanel || !cardPanel) return;

  listPanel.classList.add('hidden');
  cardPanel.classList.remove('hidden');

  const contract = act.contractId ? state.contracts.find(c => c.id === act.contractId) : null;
  if (titleEl) titleEl.textContent = contract?.number ? `Акт по контракту № ${contract.number}` : t('actsRegistry.noContract');

  if (bodyWrap) {
    bodyWrap.innerHTML = '';
    _renderActDetailHtml(act.id, bodyWrap);
  }

  if (actSection) actSection.style.display = 'none';

  const backBtn = document.getElementById('receivingCardBackBtn');
  if (backBtn) {
    const fresh = backBtn.cloneNode(true);
    backBtn.replaceWith(fresh);
    fresh.addEventListener('click', () => {
      cardPanel.classList.add('hidden');
      listPanel.classList.remove('hidden');
      if (actSection) actSection.style.display = '';
      const restored = fresh.cloneNode(true);
      fresh.replaceWith(restored);
      restored.addEventListener('click', () => {
        cardPanel.classList.add('hidden');
        listPanel.classList.remove('hidden');
      });
    });
  }
}

// ─── Open / Close (modal mode) ────────────────────────────────────

export function openActsRegistry() {
  const overlay = document.getElementById('actsRegistryModal');
  if (!overlay) return;
  _registryOpen = true;
  overlay.classList.add('open');
  renderRegistry();
  updateActsBadge();
}

export function closeActsRegistry() {
  _registryOpen = false;
  const overlay = document.getElementById('actsRegistryModal');
  if (overlay) overlay.classList.remove('open');
  closeActDetail();
}

export function initActsRegistryView() {
  const overlay = document.getElementById('actsRegistryModal');
  if (!overlay) return;

  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeActsRegistry();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && overlay.classList.contains('open')) {
      const detail = document.getElementById('actDetailPanel');
      if (detail && !detail.classList.contains('hidden')) {
        closeActDetail();
      } else {
        closeActsRegistry();
      }
    }
  });

  document.getElementById('actsRegistryCloseBtn')?.addEventListener('click', closeActsRegistry);
  document.getElementById('actDetailBackBtn')?.addEventListener('click', closeActDetail);
}

// ─── Badge ────────────────────────────────────────────────────────

export function updateActsBadge() {
  const acts = state.acts || [];
  const soCount  = acts.filter(a => (a.mode || 'so') === 'so').length;
  const delCount = acts.filter(a => (a.mode || 'so') === 'delivery').length;
  const total = acts.length;

  _setBadge('actsBadge', total);
  _setBadge('actsBadgeSO', soCount);
  _setBadge('actsBadgeDelivery', delCount);
}

function _setBadge(id, count) {
  const el = document.getElementById(id);
  if (!el) return;
  if (count > 0) {
    el.textContent = count;
    el.classList.remove('hidden');
  } else {
    el.classList.add('hidden');
  }
}

// ─── Utility ──────────────────────────────────────────────────────

export function getActsForContract(contractId) {
  return (state.acts || [])
    .filter(a => a.contractId === contractId)
    .sort((a, b) => (b.id || 0) - (a.id || 0));
}

// ─── Search + List renderer ───────────────────────────────────────

/**
 * Renders a search box + act cards filtered by mode ('so' | 'delivery').
 */
function _renderActsListWithSearch(wrap, mode, onOpen, onDelete) {
  wrap.innerHTML = '';

  // Search box
  const searchId = `actSearch_${mode}`;
  const searchVal = mode === 'so' ? _soSearch : _deliverySearch;

  const searchWrap = document.createElement('div');
  searchWrap.className = 'relative mb-4';
  searchWrap.innerHTML = `
    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none text-sm">🔍</span>
    <input id="${searchId}" type="search"
      class="w-full rounded-xl border border-white/10 bg-white/5 pl-9 pr-4 py-2.5 text-sm text-white
        placeholder-slate-500 transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
      placeholder="Поиск по номеру контракта или поставщику…"
      value="${esc(searchVal)}">`;
  wrap.appendChild(searchWrap);

  const listEl = document.createElement('div');
  wrap.appendChild(listEl);

  function renderList(q) {
    if (mode === 'so') _soSearch = q;
    else _deliverySearch = q;
    _renderActsFiltered(listEl, mode, q, onOpen, onDelete);
  }

  const inp = document.getElementById(searchId);
  if (inp) {
    inp.addEventListener('input', () => renderList(inp.value));
  }

  renderList(searchVal);
}

/**
 * Renders filtered act cards into `listEl`.
 */
function _renderActsFiltered(listEl, mode, query, onOpen, onDelete) {
  listEl.innerHTML = '';
  const q = (query || '').trim().toLowerCase();

  // Filter by mode
  let acts = (state.acts || []).filter(a => (a.mode || 'so') === mode);

  // Filter by search query
  if (q) {
    acts = acts.filter(a => {
      const contract = a.contractId ? state.contracts.find(c => c.id === a.contractId) : null;
      const supplier = contract?.supplierId ? state.suppliers.find(s => s.id === contract.supplierId) : null;
      const haystack = [
        contract?.number || '',
        contract?.title  || '',
        supplier?.name   || '',
        a.location       || '',
      ].join(' ').toLowerCase();
      return haystack.includes(q);
    });
  }

  if (acts.length === 0) {
    const label = q ? 'Ничего не найдено' : (mode === 'so' ? 'Актов проверки СО пока нет' : 'Актов проверки поставок пока нет');
    const hint  = q ? 'Попробуйте изменить запрос' : t('actsRegistry.emptyHint');
    listEl.innerHTML = `
      <div class="flex flex-col items-center justify-center py-12 text-center">
        <span class="text-4xl mb-3" aria-hidden="true">📋</span>
        <p class="text-sm font-semibold text-slate-300">${label}</p>
        <p class="text-xs text-slate-500 mt-1">${hint}</p>
      </div>`;
    return;
  }

  const sorted = [...acts].sort((a, b) => (b.id || 0) - (a.id || 0));

  sorted.forEach(act => {
    const contract = act.contractId ? state.contracts.find(c => c.id === act.contractId) : null;
    const supplier = contract?.supplierId ? state.suppliers.find(s => s.id === contract.supplierId) : null;

    const contractLabel = contract
      ? [contract.number ? `№ ${contract.number}` : '', contract.title].filter(Boolean).join(' — ')
      : t('actsRegistry.noContract');
    const supplierName = supplier?.name || '';
    const actDate  = act.date    ? fmtDate(act.date)         : '—';
    const savedAt  = act.savedAt ? fmtDateTime(act.savedAt)  : '';
    const updatedAt = act.updatedAt ? fmtDateTime(act.updatedAt) : '';
    const itemCount = (act.selectedItems || []).filter(si => si.selected !== false).length;
    const selectedItems = (act.selectedItems || []).filter(si => si.selected !== false);

    const isDeliveryAct = (act.mode || 'so') === 'delivery';
    const hasShippingForbidden = isDeliveryAct && selectedItems.some(si => si.shippingAllowed === false);
    const allShippingAllowed   = isDeliveryAct && selectedItems.length > 0 &&
      selectedItems.every(si => si.shippingAllowed === true);

    const card = document.createElement('div');
    card.className = 'rounded-xl border border-white/10 bg-white/5 mb-3 transition hover:border-cyan-400/20 overflow-hidden';

    // ── Header row (always visible, click to toggle) ──
    const headerRow = document.createElement('div');
    headerRow.className = 'flex items-center gap-2 px-4 py-3 cursor-pointer select-none group';
    headerRow.setAttribute('role', 'button');
    headerRow.setAttribute('aria-expanded', 'false');

    // Toggle arrow
    const arrow = document.createElement('span');
    arrow.className = 'text-slate-500 text-xs transition-transform shrink-0 select-none';
    arrow.textContent = '▶';
    arrow.style.transition = 'transform 0.2s';
    headerRow.appendChild(arrow);

    // Badges + title
    const titleWrap = document.createElement('div');
    titleWrap.className = 'flex-1 min-w-0 flex items-center gap-2 flex-wrap';
    titleWrap.innerHTML = `
      ${isDeliveryAct && selectedItems.length > 0
        ? allShippingAllowed
          ? `<span class="shrink-0 rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-green-500/15 text-green-400">🚚 Разрешена</span>`
          : hasShippingForbidden
            ? `<span class="shrink-0 rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-amber-500/15 text-amber-400">⛔ Частично</span>`
            : ''
        : ''}
      <span class="shrink-0 rounded-lg px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider
        ${(act.mode || 'so') === 'so' ? 'bg-violet-500/10 text-violet-400' : 'bg-cyan-500/10 text-cyan-400'}">
        ${(act.mode || 'so') === 'so' ? 'СО' : 'Поставка'}
      </span>
      <span class="text-sm font-semibold text-white truncate">${esc(contractLabel)}</span>
      ${supplierName ? `<span class="text-xs text-slate-400 truncate hidden sm:inline">${esc(supplierName)}</span>` : ''}
      <span class="text-xs text-slate-500">📅 ${esc(actDate)}</span>
      ${itemCount > 0 ? `<span class="text-xs text-slate-500">📦 ${itemCount} ${t('contracts.positions')}</span>` : ''}`;
    headerRow.appendChild(titleWrap);

    // Action buttons (always visible in header)
    const actionsWrap = document.createElement('div');
    actionsWrap.className = 'flex items-center gap-1 shrink-0';
    actionsWrap.innerHTML = `
      <button class="act-edit-btn w-8 h-8 flex items-center justify-center rounded-lg
        text-slate-500 hover:text-cyan-400 hover:bg-cyan-400/10 transition"
        data-act-id="${act.id}" aria-label="Открыть акт" title="Открыть акт">📂</button>
      <button class="act-open-edit-btn w-8 h-8 flex items-center justify-center rounded-lg
        text-slate-500 hover:text-cyan-400 hover:bg-cyan-400/10 transition"
        data-act-id="${act.id}" aria-label="Редактировать акт" title="Редактировать акт">✏️</button>
      <button class="act-download-btn w-8 h-8 flex items-center justify-center rounded-lg
        text-slate-500 hover:text-cyan-400 hover:bg-cyan-400/10 transition"
        data-act-id="${act.id}" aria-label="${t('actsRegistry.download')}" title="${t('actsRegistry.download')}">📄</button>
      <button class="act-delete-btn w-8 h-8 flex items-center justify-center rounded-lg
        text-slate-500 hover:text-red-400 hover:bg-red-400/10 transition"
        data-act-id="${act.id}" aria-label="${t('actions.delete')}">✕</button>`;
    headerRow.appendChild(actionsWrap);
    card.appendChild(headerRow);

    // ── Collapsible body ──
    const body = document.createElement('div');
    body.className = 'hidden border-t border-white/10 px-4 py-3 text-xs text-slate-400 space-y-1';
    if (act.location) body.innerHTML += `<div>📍 ${esc(act.location)}</div>`;
    if (savedAt) body.innerHTML += `<div class="text-slate-600">Сохранён: ${esc(savedAt)}</div>`;
    if (updatedAt) body.innerHTML += `<div class="text-cyan-600/70">Изм.: ${esc(updatedAt)}</div>`;
    card.appendChild(body);

    // Toggle expand/collapse on header click
    headerRow.addEventListener('click', e => {
      if (e.target.closest('button')) return;
      const expanded = headerRow.getAttribute('aria-expanded') === 'true';
      headerRow.setAttribute('aria-expanded', String(!expanded));
      arrow.style.transform = expanded ? '' : 'rotate(90deg)';
      body.classList.toggle('hidden', expanded);
    });

    // «Открыть» — показывает детальную панель (только просмотр)
    card.querySelector('.act-edit-btn')?.addEventListener('click', e => {
      e.stopPropagation();
      onOpen(act);
    });

    // «Редактировать» — открывает форму редактирования
    card.querySelector('.act-open-edit-btn')?.addEventListener('click', async e => {
      e.stopPropagation();
      const { openActFormForEdit } = await import('./act-form-view.js');
      openActFormForEdit(act.id);
    });

    card.querySelector('.act-download-btn')?.addEventListener('click', async e => {
      e.stopPropagation();
      await generateAndDownload(act.id);
    });

    card.querySelector('.act-delete-btn')?.addEventListener('click', async e => {
      e.stopPropagation();
      if (!confirm(t('actsRegistry.confirmDelete'))) return;
      deleteAct(act.id);
      await saveToStorage();
      showToast(t('actsRegistry.deleted'), 'success');
      updateActsBadge();
      if (onDelete) onDelete();
    });

    listEl.appendChild(card);
  });
}

// ─── Modal registry list — two tabs ──────────────────────────────

let _activeRegistryTab = 'so';

function renderRegistry() {
  const listPanel = document.getElementById('actsRegistryListPanel');
  if (!listPanel) return;

  listPanel.innerHTML = '';

  // Tab bar
  const tabBar = document.createElement('div');
  tabBar.className = 'flex gap-1 mb-5 rounded-xl bg-white/[0.04] p-1';

  const soCount  = (state.acts || []).filter(a => (a.mode || 'so') === 'so').length;
  const delCount = (state.acts || []).filter(a => (a.mode || 'so') === 'delivery').length;

  const soTab  = _makeTabBtn('Акты проверки СО',      _activeRegistryTab === 'so',       soCount);
  const delTab = _makeTabBtn('Акты проверки поставок', _activeRegistryTab === 'delivery', delCount);
  tabBar.append(soTab, delTab);
  listPanel.appendChild(tabBar);

  const contentWrap = document.createElement('div');
  listPanel.appendChild(contentWrap);

  function showTab(tab) {
    _activeRegistryTab = tab;
    soTab.classList.toggle('bg-cyan-400/20',   tab === 'so');
    soTab.classList.toggle('text-white',        tab === 'so');
    soTab.classList.toggle('text-slate-400',    tab !== 'so');
    delTab.classList.toggle('bg-cyan-400/20',   tab === 'delivery');
    delTab.classList.toggle('text-white',        tab === 'delivery');
    delTab.classList.toggle('text-slate-400',    tab !== 'delivery');
    _renderActsListWithSearch(
      contentWrap,
      tab,
      act => openActDetail(act.id),
      () => renderRegistry()
    );
  }

  soTab.addEventListener('click',  () => showTab('so'));
  delTab.addEventListener('click', () => showTab('delivery'));
  showTab(_activeRegistryTab);
}

// ─── Modal detail panel ───────────────────────────────────────────

let _detailActId = null;

function openActDetail(actId) {
  _detailActId = actId;
  const listPanel   = document.getElementById('actsRegistryListPanel');
  const detailPanel = document.getElementById('actDetailPanel');
  if (listPanel)   listPanel.classList.add('hidden');
  if (detailPanel) detailPanel.classList.remove('hidden');
  renderActDetail(actId);
}

function closeActDetail() {
  _detailActId = null;
  const listPanel   = document.getElementById('actsRegistryListPanel');
  const detailPanel = document.getElementById('actDetailPanel');
  if (detailPanel) detailPanel.classList.add('hidden');
  if (listPanel)   listPanel.classList.remove('hidden');
}

function renderActDetail(actId) {
  const wrap = document.getElementById('actDetailBody');
  if (!wrap) return;
  _renderActDetailHtml(actId, wrap);

  const titleEl = document.getElementById('actDetailTitle');
  const act = (state.acts || []).find(a => a.id === actId);
  const contract = act?.contractId ? state.contracts.find(c => c.id === act.contractId) : null;
  if (titleEl) titleEl.textContent = contract?.number ? `№ ${contract.number}` : t('actsRegistry.noContract');
}

// ─── Shared act detail HTML builder ──────────────────────────────

function _renderActDetailHtml(actId, wrap) {
  const act = (state.acts || []).find(a => a.id === actId);
  if (!act) return;

  const contract = act.contractId ? state.contracts.find(c => c.id === act.contractId) : null;
  const supplier = contract?.supplierId ? state.suppliers.find(s => s.id === contract.supplierId) : null;
  const selected = (act.selectedItems || []).filter(si => si.selected !== false);
  const isDelivery = (act.mode || 'so') === 'delivery';

  // nonConform = true → «Соответствует»; nonConform = false → «Не соответствует»
  const actHasSpecNonConform = selected.some(si =>
    (si.specs || []).some(sp => sp.checkResult && sp.checkResult.trim() && sp.nonConform === false)
  );
  const actHasSOFail = !isDelivery && selected.some(si => !si.siSoNotRequired && si.soConforms === false);
  const actHasNonConform = actHasSpecNonConform || actHasSOFail;
  const actAllShipping = isDelivery && selected.length > 0 && selected.every(si => si.shippingAllowed === true);
  const actSomeShipping = isDelivery && selected.some(si => si.shippingAllowed === true);

  const commissionRows = (act.commission || []).filter(p => p.role || p.name)
    .map(p => `<tr>
      <td class="py-1 pr-4 text-sm text-slate-300 align-top">${esc(p.role)}</td>
      <td class="py-1 text-sm text-slate-200">${esc(p.name)}</td>
    </tr>`).join('') || `<tr><td colspan="2" class="py-2 text-xs text-slate-500">${t('commission.empty')}</td></tr>`;

  const supplierRepRows = (act.supplierReps || []).filter(p => p.role || p.name)
    .map(p => `<tr>
      <td class="py-1 pr-4 text-sm text-slate-300 align-top">${esc(p.role)}</td>
      <td class="py-1 text-sm text-slate-200">${esc(p.name)}</td>
    </tr>`).join('') || `<tr><td colspan="2" class="py-2 text-xs text-slate-500">—</td></tr>`;

  wrap.innerHTML = `
    <div class="space-y-6">

      <!-- Header info -->
      <div class="rounded-xl border border-white/10 bg-white/5 p-4 space-y-2">
        <div class="flex items-center justify-between gap-3 flex-wrap">
          <div class="flex flex-wrap gap-x-4 gap-y-1">
            ${contract ? `<div class="flex gap-2 flex-wrap">
              <span class="text-xs text-slate-500">Контракт:</span>
              <span class="text-sm text-white font-medium">${esc([contract.number ? `№ ${contract.number}` : '', contract.title].filter(Boolean).join(' — '))}</span>
            </div>` : ''}
            ${supplier ? `<div class="flex gap-2 flex-wrap">
              <span class="text-xs text-slate-500">Поставщик:</span>
              <span class="text-sm text-white">${esc(supplier.name)}</span>
            </div>` : ''}
            ${act.location ? `<div class="flex gap-2 flex-wrap">
              <span class="text-xs text-slate-500">Место:</span>
              <span class="text-sm text-white">${esc(act.location)}</span>
            </div>` : ''}
            ${act.date ? `<div class="flex gap-2 flex-wrap">
              <span class="text-xs text-slate-500">Дата:</span>
              <span class="text-sm text-white">${esc(fmtDate(act.date))}</span>
            </div>` : ''}
          </div>
          <div class="flex items-center gap-2 shrink-0 flex-wrap">
            ${actHasNonConform
              ? `<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-red-500/15 text-red-400">⚠ Несоответствия</span>`
              : `<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-green-500/15 text-green-400">✓ Без замечаний</span>`}
            ${isDelivery && selected.length > 0
              ? actAllShipping
                ? `<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-green-500/15 text-green-400">🚚 Отгрузка разрешена</span>`
                : actSomeShipping
                  ? `<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-amber-500/15 text-amber-400">⛔ Отгрузка частично</span>`
                  : `<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-red-500/15 text-red-400">⛔ Отгрузка запрещена</span>`
              : ''}
            <span class="rounded-lg px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider
              ${(act.mode || 'so') === 'so' ? 'bg-violet-500/15 text-violet-400' : 'bg-cyan-500/15 text-cyan-400'}">
              ${(act.mode || 'so') === 'so' ? 'Проверка СО' : 'Проверка поставки'}
            </span>
            <button class="act-detail-edit-btn inline-flex items-center gap-1.5 rounded-xl border border-cyan-400/30
              bg-cyan-400/5 px-3 py-1.5 text-xs font-semibold text-cyan-400
              hover:bg-cyan-400/15 transition"
              data-act-id="${act.id}">
              ✏️ Редактировать
            </button>
          </div>
        </div>
      </div>

      <!-- Commission -->
      <div>
        <h4 class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">${t('act.sectionCommission')}</h4>
        <div class="overflow-hidden rounded-xl border border-white/10">
          <table class="w-full text-sm">
            <thead class="bg-white/[0.04] border-b border-white/10">
              <tr>
                <th class="px-3 py-2 text-left text-xs font-semibold text-slate-400 w-1/2">${t('act.roleLabel')}</th>
                <th class="px-3 py-2 text-left text-xs font-semibold text-slate-400 w-1/2">${t('act.nameLabel')}</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-white/5 px-3">${commissionRows}</tbody>
          </table>
        </div>
      </div>

      <!-- Supplier reps -->
      <div>
        <h4 class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">${t('act.sectionSupplierReps')}</h4>
        <div class="overflow-hidden rounded-xl border border-white/10">
          <table class="w-full text-sm">
            <thead class="bg-white/[0.04] border-b border-white/10">
              <tr>
                <th class="px-3 py-2 text-left text-xs font-semibold text-slate-400 w-1/2">${t('act.roleLabel')}</th>
                <th class="px-3 py-2 text-left text-xs font-semibold text-slate-400 w-1/2">${t('act.nameLabel')}</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-white/5 px-3">${supplierRepRows}</tbody>
          </table>
        </div>
      </div>

      <!-- Items & specs -->
      ${selected.length > 0 ? `
      <div>
        <h4 class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">${t('act.sectionItems')}</h4>
        <div class="space-y-3">
          ${selected.map(si => {
            // Товар «не соответствует» если хотя бы один ползунок nonConform === false
            const siSpecFail = (si.specs || []).some(sp => sp.nonConform === false);
            const siSOFail = !isDelivery && !si.siSoNotRequired && si.soConforms === false;
            const siFail = siSpecFail || siSOFail;
            const conformBadge = si.siSoNotRequired
              ? `<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-emerald-500/15 text-emerald-400">СО не предусмотрен</span>`
              : siFail
                ? `<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-red-500/15 text-red-400">⚠ Не соответствует</span>`
                : `<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-green-500/15 text-green-400">✓ Соответствует</span>`;
            const shippingBadge = isDelivery
              ? si.shippingAllowed === true
                ? `<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-green-500/15 text-green-400">🚚 Отгрузка разрешена</span>`
                : `<span class="rounded-lg px-2 py-0.5 text-[10px] font-semibold bg-red-500/15 text-red-400">⛔ Отгрузка запрещена</span>`
              : '';
            const borderCls = siFail ? 'border-red-500/20' : (isDelivery && si.shippingAllowed === false) ? 'border-amber-500/20' : 'border-green-500/15';
            return `
            <div class="rounded-xl border ${borderCls} bg-white/5 p-3">
              <div class="flex items-center gap-2 flex-wrap mb-2">
                ${si.itemCode ? `<span class="font-mono text-xs text-cyan-400/80 bg-cyan-400/10 rounded px-1.5 py-0.5">${esc(si.itemCode)}</span>` : ''}
                <span class="text-sm font-semibold text-white">${esc(si.name)}</span>
                ${conformBadge}
                ${shippingBadge}
              </div>
              ${si.specs && si.specs.length > 0 ? `
              <div class="overflow-x-auto rounded-lg border border-white/10">
                <table class="w-full text-xs">
                  <thead class="bg-white/[0.04]">
                    <tr>
                      <th class="px-3 py-1.5 text-left text-slate-400">${t('act.colParam')}</th>
                      <th class="px-3 py-1.5 text-left text-slate-400">${t('act.colUnit')}</th>
                      <th class="px-3 py-1.5 text-left text-slate-400">${t('act.colContractValue')}</th>
                      <th class="px-3 py-1.5 text-left text-slate-400">${t('act.colCheckResult')}</th>
                      <th class="px-3 py-1.5 text-left text-slate-400">Соответствие</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-white/5">
                    ${si.specs.map(spec => {
                      // Ползунок влево (nonConform===false) = не соответствует
                      const specFail = spec.nonConform === false;
                      return `
                      <tr class="${specFail ? 'bg-red-500/5' : 'bg-green-500/5'}">
                        <td class="px-3 py-1.5 ${specFail ? 'text-red-300 font-semibold' : 'text-slate-300'}">${esc(spec.param || '—')}</td>
                        <td class="px-3 py-1.5 text-slate-400">${esc(spec.unit || '—')}</td>
                        <td class="px-3 py-1.5 text-cyan-400/80">${esc(spec.value || '—')}</td>
                        <td class="px-3 py-1.5 text-slate-200">${esc(spec.checkResult || '—')}</td>
                        <td class="px-3 py-1.5">
                          ${spec.nonConform === true
                            ? `<span class="text-green-400 text-xs font-semibold">✓ Соответствует</span>`
                            : `<span class="text-red-400 text-xs font-semibold">✗ Не соответствует</span>`}
                        </td>
                      </tr>`;
                    }).join('')}
                  </tbody>
                </table>
              </div>` : `<p class="text-xs text-slate-500">${t('act.noSpecs')}</p>`}
            </div>`;
          }).join('')}
        </div>
      </div>` : ''}

      <!-- Result / Prescription / Deadline -->
      ${act.result ? `
      <div class="rounded-xl border border-white/10 bg-white/5 p-4 space-y-3">
        <div>
          <p class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">${t('act.fieldResult')}</p>
          <p class="text-sm text-white">${esc(act.result)}</p>
        </div>
        ${act.prescription ? `<div>
          <p class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">${t('act.fieldPrescription')}</p>
          <p class="text-sm text-white">${esc(act.prescription)}</p>
        </div>` : ''}
        ${act.deadline ? `<div>
          <p class="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">${t('act.fieldDeadline')}</p>
          <p class="text-sm text-white">${esc(fmtDate(act.deadline))}</p>
        </div>` : ''}
      </div>` : ''}

      <!-- Buttons -->
      <div class="flex gap-3 justify-end flex-wrap">
        <button class="act-detail-edit-btn2 inline-flex items-center gap-2 rounded-xl border border-cyan-400/30
          bg-cyan-400/5 px-5 py-2.5 text-sm font-semibold text-cyan-400
          hover:bg-cyan-400/15 transition active:scale-[0.97]"
          data-act-id="${act.id}">
          ✏️ Редактировать
        </button>
        <button class="act-detail-dl-btn inline-flex items-center gap-2 rounded-xl bg-cyan-400 px-5 py-2.5
          text-sm font-semibold text-slate-950 transition hover:bg-cyan-300 active:scale-[0.97]">
          <span aria-hidden="true">📄</span>
          ${t('actsRegistry.download')}
        </button>
      </div>

    </div>`;

  // Wire edit buttons
  wrap.querySelectorAll('.act-detail-edit-btn, .act-detail-edit-btn2').forEach(btn => {
    btn.addEventListener('click', async () => {
      const { openActFormForEdit } = await import('./act-form-view.js');
      openActFormForEdit(act.id);
    });
  });

  wrap.querySelector('.act-detail-dl-btn')?.addEventListener('click', () => generateAndDownload(actId));
}

// ─── Re-generate Word from saved act ─────────────────────────────

export async function generateAndDownload(actId) {
  const act = (state.acts || []).find(a => a.id === actId);
  if (!act) return;

  try {
    const { buildActDocx } = await import('./act-form-view.js');
    const contract = act.contractId ? state.contracts.find(c => c.id === act.contractId) : null;
    const supplier = contract?.supplierId ? state.suppliers.find(s => s.id === contract.supplierId) : null;
    const selected = (act.selectedItems || []).filter(si => si.selected !== false);

    const blob = await buildActDocx(act, contract, supplier, selected);
    const typeLabel = (act.mode || 'so') === 'so' ? 'СО' : 'поставки';
    const fname = `Акт_проверки_${typeLabel}_${contract?.number || 'б_н'}.docx`;
    downloadBlob(blob, fname);
    showToast(t('act.generated'), 'success');
  } catch (err) {
    console.error('Re-generate error:', err);
    showToast(t('act.generateError'), 'error');
  }
}

// ─── Helpers ──────────────────────────────────────────────────────

function esc(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function fmtDate(iso) {
  if (!iso) return '';
  try {
    const [y, m, d] = iso.split('-');
    return `${d}.${m}.${y}`;
  } catch { return iso; }
}

function fmtDateTime(iso) {
  if (!iso) return '';
  try {
    const d = new Date(iso);
    return d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch { return iso; }
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
