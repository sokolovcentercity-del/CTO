/**
 * Search and filter controls.
 * Updates state.filters and triggers re-render.
 * Color filter removed — not shown in catalog.
 */

import { $, el, clearChildren } from './dom.js';
import { state, getCategories } from '../state.js';

const t = (key, vals) => window.miniappI18n?.t(key, vals) ?? key;

let onFilterChange = null;

/** Populate filter dropdowns from current data */
export function updateFilterOptions() {
  const categorySelect = $('filterCategory');

  if (categorySelect) {
    const currentVal = categorySelect.value;
    clearChildren(categorySelect);
    categorySelect.appendChild(el('option', { value: '' }, t('filters.all')));
    getCategories().forEach(cat => {
      categorySelect.appendChild(el('option', { value: cat }, cat));
    });
    categorySelect.value = currentVal;
  }
}

/** Update product count display */
export function updateProductCount(visibleCount, totalCount) {
  const counter = $('productCount');
  if (!counter) return;

  if (totalCount === 0) {
    counter.textContent = '';
  } else if (visibleCount === totalCount) {
    counter.textContent = `${totalCount}`;
  } else {
    counter.textContent = `${visibleCount} / ${totalCount}`;
  }
}

/** Initialize filter event listeners */
export function initFilters(callback) {
  onFilterChange = callback;

  const searchInput = $('filterSearch');
  const categorySelect = $('filterCategory');

  if (searchInput) {
    let debounceTimer = null;
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        state.filters.search = searchInput.value;
        if (onFilterChange) onFilterChange();
      }, 200);
    });
  }

  if (categorySelect) {
    categorySelect.addEventListener('change', () => {
      state.filters.category = categorySelect.value;
      if (onFilterChange) onFilterChange();
    });
  }
}
