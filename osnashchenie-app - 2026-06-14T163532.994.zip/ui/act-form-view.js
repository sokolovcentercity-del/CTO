/**
 * Act Form View — карточка формирования акта проверки.
 * Открывается из модуля «Приёмка» → «Сформировать акт».
 * Генерирует .docx: два вида — проверка СО и проверка поставленного товара.
 */

import { state, saveAct, updateAct } from '../state.js';
import { saveToStorage } from '../storage.js';
import { showToast } from './toast.js';

const t = (key, vals) => window.miniappI18n?.t(key, vals) ?? key;

// ─── Module state ─────────────────────────────────────────────────

let _contractId = null;   // pre-selected from receiving view (may be null)
// mode: 'so'       = проверка сигнальных образцов (без кол-ва)
//       'delivery' = проверка поставленного товара (с кол-вом + отгрузка)
let _mode = 'so';
let _data = newData();
let _editActId = null;    // null = новый акт, number = редактирование существующего

function newData() {
  return {
    contractId: null,
    recipientId: null,
    location: '',
    date: new Date().toISOString().slice(0, 10),
    commission: [{ role: '', name: '' }],
    supplierReps: [{ role: '', name: '' }],
    // selectedItems: [{ itemIdx, name, selected, qty, siSoNotRequired, specs:[{param,unit,value,checkResult,nonConform}] }]
    selectedItems: [],
    result: '',
    prescription: '',
    deadline: '',
  };
}

/**
 * Resolve item code for a contract item.
 * Priority:
 *   1) item.code — already computed and persisted by contracts-view
 *   2) Recompute from productRef + contract.number (handles cases where
 *      the contract card was never opened after last save)
 */
function resolveItemCode(item, contract) {
  // 1) Already stored
  if (item.code && item.code.trim()) return item.code.trim();

  // 2) Recompute from productRef
  if (item.productRef == null) return '';
  const prod = state.products.find(p => p.id === item.productRef);
  if (!prod) return '';
  const prodNum = String(prod.number).padStart(4, '0');
  const contractNumber = contract?.number ?? '';
  const contractDigits = String(contractNumber).replace(/\D/g, '');
  const contractSuffix = contractDigits.length >= 4
    ? contractDigits.slice(-4)
    : contractDigits.padStart(4, '0');
  const computed = `${prodNum}/${contractSuffix}`;
  // Persist it back so subsequent calls are fast
  item.code = computed;
  return computed;
}

// ─── Open / Close ─────────────────────────────────────────────────

export function openActForm(contractId, mode) {
  _editActId = null;
  _data = newData();
  _data.contractId = contractId || null;
  _contractId = contractId || null;
  _mode = mode || 'so';

  const overlay = document.getElementById('actFormModal');
  if (!overlay) return;

  // Update header title based on mode
  const titleEl = document.getElementById('actFormTitle');
  if (titleEl) {
    titleEl.textContent = _mode === 'delivery'
      ? 'Акт проверки поставленного товара'
      : 'Акт проверки сигнальных образцов';
  }

  overlay.querySelector('.catalog-panel')?.classList.remove('hidden');
  overlay.classList.add('open');
  renderAll();
}

/**
 * Open act form pre-filled with saved act data for editing.
 * @param {number} actId — id of the act in state.acts
 */
export function openActFormForEdit(actId) {
  const act = (state.acts || []).find(a => a.id === actId);
  if (!act) return;

  _editActId = actId;
  _mode = act.mode || 'so';
  _contractId = act.contractId || null;

  // Deep-clone act data into _data
  _data = {
    contractId: act.contractId || null,
    location:   act.location   || '',
    date:       act.date       || new Date().toISOString().slice(0, 10),
    commission:   (act.commission   || []).map(p => ({ ...p })),
    supplierReps: (act.supplierReps || []).map(p => ({ ...p })),
    selectedItems: (act.selectedItems || []).map(si => ({
      ...si,
      specs: (si.specs || []).map(sp => ({ ...sp })),
    })),
    result:       act.result       || '',
    prescription: act.prescription || '',
    deadline:     act.deadline     || '',
    mode:         _mode,
  };

  const overlay = document.getElementById('actFormModal');
  if (!overlay) return;

  const titleEl = document.getElementById('actFormTitle');
  if (titleEl) {
    titleEl.textContent = _mode === 'delivery'
      ? 'Редактирование акта проверки поставки'
      : 'Редактирование акта проверки СО';
  }

  // Switch save button label to «Сохранить изменения»
  const saveBtn = document.getElementById('actFormSaveBtn');
  if (saveBtn) saveBtn.textContent = 'Сохранить изменения';

  overlay.querySelector('.catalog-panel')?.classList.remove('hidden');
  overlay.classList.add('open');
  renderAll();
}

export function closeActForm() {
  _editActId = null;
  // Reset save button label
  const saveBtn = document.getElementById('actFormSaveBtn');
  if (saveBtn) saveBtn.textContent = t('actsRegistry.saveBtn');
  const overlay = document.getElementById('actFormModal');
  if (overlay) {
    overlay.classList.remove('open');
    overlay.querySelector('.catalog-panel')?.classList.add('hidden');
  }
}

export function initActFormView() {
  const overlay = document.getElementById('actFormModal');
  if (!overlay) return;

  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeActForm();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && overlay.classList.contains('open')) closeActForm();
  });
  document.getElementById('actFormCloseBtn')?.addEventListener('click', closeActForm);
  document.getElementById('actFormGenerateBtn')?.addEventListener('click', onGenerate);
  document.getElementById('actFormSaveBtn')?.addEventListener('click', onSave);
}

// ─── Render: full form ────────────────────────────────────────────

function renderAll() {
  renderContractField();
  renderBasicFields();
  renderCommission();
  renderSupplierReps();
  renderItems();
  renderResultFields();
}

// ─── Contract selector ────────────────────────────────────────────

function renderContractField() {
  const wrap = document.getElementById('actContractWrap');
  if (!wrap) return;

  const contracts = state.contracts || [];

  wrap.innerHTML = `
    <label class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400"
      for="actContractInput">${t('act.fieldContract')}</label>
    <div class="relative">
      <input id="actContractInput" type="text" autocomplete="off"
        class="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
        placeholder="${t('act.contractSearchPlaceholder')}"
        value="${esc(contractLabel(_data.contractId))}">
      <div id="actContractDrop"
        class="hidden absolute z-50 left-0 right-0 mt-1 rounded-xl border border-white/15 bg-slate-800 shadow-2xl overflow-y-auto max-h-52">
      </div>
    </div>`;

  const input = document.getElementById('actContractInput');
  const drop  = document.getElementById('actContractDrop');

  function buildDrop(q) {
    const filtered = q
      ? contracts.filter(c => contractLabel(c.id).toLowerCase().includes(q.toLowerCase()))
      : contracts;
    drop.innerHTML = filtered.length === 0
      ? `<p class="px-4 py-3 text-xs text-slate-500">Ничего не найдено</p>`
      : filtered.map(c => `
          <div class="contract-opt px-4 py-2.5 text-sm text-white cursor-pointer hover:bg-cyan-400/10 transition"
            data-id="${c.id}">${esc(contractLabel(c.id))}</div>`).join('');

    drop.querySelectorAll('.contract-opt').forEach(div => {
      div.addEventListener('mousedown', e => {
        e.preventDefault();
        const id = Number(div.dataset.id);
        _data.contractId = id;
        input.value = contractLabel(id);
        drop.classList.add('hidden');
        updateSOWarning(id);
        renderItems();
        renderSupplierReps();
      });
    });
  }

  input.addEventListener('focus', () => { buildDrop(''); drop.classList.remove('hidden'); });
  input.addEventListener('input', () => { buildDrop(input.value); drop.classList.remove('hidden'); });
  input.addEventListener('blur',  () => { setTimeout(() => drop.classList.add('hidden'), 200); });

  // ── Предупреждение если СО не предусмотрен контрактом ──────────
  drop.addEventListener('mousedown', () => {}); // keep focus
  buildDrop('');

  // Show/hide SO warning banner after contract selection
  function updateSOWarning(contractId) {
    let banner = wrap.querySelector('#actSONotRequiredBanner');
    const contract = contractId ? state.contracts.find(c => c.id === contractId) : null;
    const soNotRequired = contract && contract.soApprovalRequired === false;
    if (!banner) {
      banner = document.createElement('div');
      banner.id = 'actSONotRequiredBanner';
      banner.className = 'mt-3 rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 flex items-start gap-2';
      banner.innerHTML = '<span class="text-amber-400 text-base shrink-0 mt-0.5">⚠</span>' +
        '<div><p class="text-sm font-semibold text-amber-400">Контрактом не предусмотрена проверка СО</p>' +
        '<p class="text-xs text-slate-400 mt-0.5">Результаты проверки не будут транслироваться в модуль «Контракты» и не повлияют на возможность направления заявок. Формирование и сохранение акта допускается.</p></div>';
      wrap.appendChild(banner);
    }
    banner.classList.toggle('hidden', !soNotRequired);
  }

  if (_data.contractId) updateSOWarning(_data.contractId);
}

function contractLabel(id) {
  if (!id) return '';
  const c = state.contracts.find(ct => ct.id === id);
  if (!c) return '';
  const num = c.number ? `№ ${c.number}` : t('contracts.noNumber');
  return c.title ? `${num} — ${c.title}` : num;
}

// ─── Basic fields ─────────────────────────────────────────────────

function renderBasicFields() {
  const wrap = document.getElementById('actBasicFieldsWrap');
  if (!wrap) return;

  wrap.innerHTML = `
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
      <div class="sm:col-span-2">
        <label for="actLocation"
          class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">${t('act.fieldLocation')}</label>
        <input id="actLocation" type="text"
          class="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
          placeholder="${t('act.locationPlaceholder')}"
          value="${esc(_data.location)}">
      </div>
      <div>
        <label for="actDate"
          class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">${t('act.fieldDate')}</label>
        <input id="actDate" type="date"
          class="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
          value="${esc(_data.date)}">
      </div>
      ${recipientSelectHtml}
    </div>`;

  document.getElementById('actLocation')?.addEventListener('input', e => { _data.location = e.target.value; });
  document.getElementById('actDate')?.addEventListener('input', e => { _data.date = e.target.value; });

  // Wire recipient selector — when changed, re-render items to update _deliveredToRecipient
  document.getElementById('actRecipientSel')?.addEventListener('change', e => {
    _data.recipientId = Number(e.target.value) || null;
    renderItems(); // Refresh items with new delivered counts
  });
}

// ─── Person list (commission / supplier reps) — table layout ──────

function renderCommission() {
  const wrap = document.getElementById('actCommissionWrap');
  if (wrap) renderPersonList(wrap, _data.commission, 'comm', renderCommission);
}

function renderSupplierReps() {
  const wrap = document.getElementById('actSupplierRepsWrap');
  if (!wrap) return;

  const contract = _data.contractId ? state.contracts.find(c => c.id === _data.contractId) : null;
  const supplier = contract?.supplierId ? state.suppliers.find(s => s.id === contract.supplierId) : null;

  renderPersonList(wrap, _data.supplierReps, 'srep', renderSupplierReps, supplier?.name);
}

function renderPersonList(wrap, list, prefix, rerender, sectionLabel) {
  const inputCls = 'w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]';

  // For commission rows — build datalist from state.commission
  const isComm = prefix === 'comm';
  const commMembers = isComm ? (state.commission || []) : [];
  const datalistId = isComm ? 'actCommRoleDatalist' : '';
  const datalistHtml = isComm && commMembers.length > 0
    ? `<datalist id="${datalistId}">${commMembers.map(m => `<option value="${esc(m.role)}" data-name="${esc(m.name)}">`).join('')}</datalist>`
    : '';

  // Quick-fill buttons from state.commission (only for commission section)
  const quickFillHtml = isComm && commMembers.length > 0
    ? `<div class="mb-2 flex flex-wrap gap-1.5">
        <span class="text-xs text-slate-500 self-center">${t('commission.quickAdd')}:</span>
        ${commMembers.map(m => `
          <button type="button" class="comm-quick-btn inline-flex items-center gap-1 rounded-lg
            border border-cyan-400/20 bg-cyan-400/5 px-2.5 py-1 text-xs text-cyan-400
            hover:bg-cyan-400/15 transition" data-role="${esc(m.role)}" data-name="${esc(m.name)}">
            ${esc(m.name ? m.name : m.role)}
          </button>`).join('')}
      </div>`
    : '';

  wrap.innerHTML = `
    ${datalistHtml}
    ${sectionLabel ? `<p class="text-xs text-slate-500 mb-2">${esc(sectionLabel)}</p>` : ''}
    ${quickFillHtml}
    <div class="overflow-hidden rounded-xl border border-white/10">
      <table class="w-full text-sm">
        <thead>
          <tr class="bg-white/[0.04] border-b border-white/10">
            <th class="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wider text-slate-400 w-1/2">${t('act.roleLabel')}</th>
            <th class="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wider text-slate-400 w-1/2">${t('act.nameLabel')}</th>
            <th class="w-10"></th>
          </tr>
        </thead>
        <tbody class="divide-y divide-white/5">
          ${list.map((p, i) => `
            <tr>
              <td class="px-2 py-1.5">
                <input type="text" class="${inputCls} ${prefix}-role"
                  placeholder="${t('act.roleLabel')}" value="${esc(p.role)}" data-idx="${i}">
              </td>
              <td class="px-2 py-1.5">
                <input type="text" class="${inputCls} ${prefix}-name"
                  placeholder="${t('act.nameLabel')}" value="${esc(p.name)}" data-idx="${i}">
              </td>
              <td class="px-2 py-1.5 text-center">
                <button class="w-7 h-7 flex items-center justify-center rounded-lg text-slate-500
                  hover:text-red-400 hover:bg-red-400/10 transition del-person mx-auto"
                  data-idx="${i}" aria-label="${t('actions.delete')}">✕</button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>
    <button class="add-person mt-2 inline-flex items-center gap-1.5 rounded-xl border border-dashed
      border-white/20 bg-white/[0.03] px-3 py-2 text-xs font-medium text-slate-400 transition
      hover:border-cyan-400/30 hover:text-cyan-400 hover:bg-cyan-400/5 w-full justify-center">
      <span aria-hidden="true">＋</span>
      ${isComm ? t('act.addCommission') : t('act.addSupplierRep')}
    </button>`;

  wrap.querySelectorAll(`.${prefix}-role`).forEach(inp =>
    inp.addEventListener('input', () => { list[+inp.dataset.idx].role = inp.value; }));
  wrap.querySelectorAll(`.${prefix}-name`).forEach(inp =>
    inp.addEventListener('input', () => { list[+inp.dataset.idx].name = inp.value; }));
  wrap.querySelectorAll('.del-person').forEach(btn =>
    btn.addEventListener('click', () => {
      list.splice(+btn.dataset.idx, 1);
      if (!list.length) list.push({ role: '', name: '' });
      rerender();
    }));
  wrap.querySelector('.add-person')?.addEventListener('click', () => {
    list.push({ role: '', name: '' });
    rerender();
  });

  // Quick-fill: add commission member from saved list
  wrap.querySelectorAll('.comm-quick-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const role = btn.dataset.role || '';
      const name = btn.dataset.name || '';
      // Avoid duplicate entries
      const alreadyExists = list.some(p => p.role === role && p.name === name);
      if (!alreadyExists) {
        list.push({ role, name });
        rerender();
      }
    });
  });
}

/**
 * Calculates total qty delivered to a specific recipient for a product.
 * Source: state.shipments — same logic as recipients-view delivery history.
 * @param {number|null} recipientId
 * @param {number} productId
 * @returns {number|undefined} — undefined if no recipient selected
 */
function calcDeliveredToRecipient(recipientId, productId) {
  if (!recipientId || !productId) return undefined;
  const prod = state.products.find(p => p.id === productId);
  if (!prod) return undefined;
  const codeNorm = (prod.code || '').trim().toLowerCase();
  const nameNorm = (prod.name || '').trim().toLowerCase();
  let total = 0;
  for (const shipment of (state.shipments || [])) {
    for (const row of (shipment.rows || [])) {
      // Match product by productId, code or name
      const rowProd = row.productId === productId
        || (codeNorm && (row.productCode || '').trim().toLowerCase() === codeNorm)
        || (nameNorm && (row.productName || '').trim().toLowerCase() === nameNorm);
      if (!rowProd) continue;
      const recEntry = (row.recipients || []).find(r => r.recipientId === recipientId);
      if (recEntry && recEntry.qty > 0) total += Number(recEntry.qty);
    }
  }
  return total;
}

// ─── Items section ────────────────────────────────────────────────

function renderItems() {
  const wrap = document.getElementById('actItemsWrap');
  if (!wrap) return;

  const contract = _data.contractId ? state.contracts.find(c => c.id === _data.contractId) : null;

  if (!contract) {
    wrap.innerHTML = `<p class="text-xs text-slate-500 py-2">${t('act.selectContractFirst')}</p>`;
    return;
  }

  const rawItems = (contract.items || []).filter(i => i.name && String(i.name).trim());

  if (!rawItems.length) {
    wrap.innerHTML = `<p class="text-xs text-slate-500 py-2">${t('receiving.noItems')}</p>`;
    return;
  }

  // Sync _data.selectedItems with contract items (preserve existing checkResults/nonConform/siSoNotRequired)
  const existingMap = new Map(_data.selectedItems.map(si => [si.itemIdx, si]));
  const recipientId = _data.recipientId || null; // optional — may be set externally
  _data.selectedItems = rawItems.map((item, idx) => {
    // Resolve item code: prefer item.code (persisted by contracts-view),
    // but also recompute from productRef + contract.number as fallback
    const resolvedCode = resolveItemCode(item, contract);

    if (existingMap.has(idx)) {
      // Update itemCode in case contract was re-saved
      const existing = existingMap.get(idx);
      existing.itemCode = resolvedCode;
      // Refresh delivered-to-recipient count
      if (item.productRef != null) {
        existing._deliveredToRecipient = calcDeliveredToRecipient(recipientId, item.productRef);
      }
      return existing;
    }
    const product = item.productRef != null
      ? state.products.find(p => p.id === item.productRef)
      : null;
    const rawSpecs = product && Array.isArray(product.specs) ? product.specs : [];
    return {
      itemIdx: idx,
      itemCode: resolvedCode,   // code for cross-module matching
      name: product ? product.name : (item.name || ''),
      selected: false,
      contractQty: item.qty || '',   // кол-во по контракту
      qty: '',                        // фактическое кол-во (для mode=delivery)
      _deliveredToRecipient: item.productRef != null
        ? calcDeliveredToRecipient(recipientId, item.productRef)
        : undefined,
      siSoNotRequired: false,         // устанавливается пользователем в акте СО
      normDocEnabled: false,
      normDocConforms: true,
      normDocComment: '',
      specs: rawSpecs.map(s => ({
        param: s.param || '',
        unit: s.unit || '',
        value: s.value || '',
        checkResult: '',
        nonConform: false,
      })),
    };
  });

  // Строим карточки всех товаров
  const cardPairs = _data.selectedItems.map((si, i) => buildItemCard(si, i));

  wrap.innerHTML = `<div class="space-y-3">
    ${cardPairs.join('')}
  </div>`;

  // Wire item checkboxes (select/deselect item)
  wrap.querySelectorAll('.act-item-cb').forEach(cb => {
    cb.addEventListener('change', () => {
      const i = +cb.dataset.i;
      _data.selectedItems[i].selected = cb.checked;
      const body = wrap.querySelector(`.act-item-body[data-i="${i}"]`);
      if (body) body.classList.toggle('hidden', !cb.checked);
    });
  });

  // Wire «СО не предусмотрен» checkboxes (SO mode only)
  wrap.querySelectorAll('.act-si-so-not-required-cb').forEach(cb => {
    cb.addEventListener('change', () => {
      const i = +cb.dataset.i;
      _data.selectedItems[i].siSoNotRequired = cb.checked;
      // Redraw just this card
      const cardEl = wrap.querySelector(`.act-item-card[data-i="${i}"]`);
      if (cardEl) {
        const newHtml = buildItemCard(_data.selectedItems[i], i);
        const tmp = document.createElement('div');
        tmp.innerHTML = newHtml;
        cardEl.replaceWith(tmp.firstElementChild);
        // Re-wire events for the replaced card
        rewireItemCard(wrap, i);
      }
    });
  });

  // Wire check result inputs
  wrap.querySelectorAll('.act-check-inp').forEach(inp => {
    inp.addEventListener('input', () => {
      _data.selectedItems[+inp.dataset.i].specs[+inp.dataset.s].checkResult = inp.value;
    });
  });

  // Wire non-conform toggles (red/green slider per spec row)
  wrap.querySelectorAll('.act-nonconform-toggle').forEach(cb => {
    cb.addEventListener('change', () => {
      const i = +cb.dataset.i;
      const s = +cb.dataset.s;
      _data.selectedItems[i].specs[s].nonConform = cb.checked;
      // Update visual slider
      const row = cb.closest('tr');
      if (!row) return;
      const track = row.querySelector('.nc-track');
      const dot   = row.querySelector('.nc-dot');
      const lbl   = row.querySelector('.nc-label');
      if (track) {
        track.classList.toggle('bg-green-500/70', cb.checked);
        track.classList.toggle('bg-red-500/60',  !cb.checked);
      }
      if (dot) {
        dot.classList.toggle('translate-x-5', cb.checked);
        dot.classList.toggle('translate-x-0', !cb.checked);
      }
      if (lbl) {
        lbl.textContent = cb.checked ? 'Соответствует' : 'Не соответствует';
        lbl.classList.toggle('text-green-400', cb.checked);
        lbl.classList.toggle('text-red-400',  !cb.checked);
      }
      row.classList.toggle('bg-green-500/5', cb.checked);
      row.classList.toggle('bg-red-500/5',  !cb.checked);
    });
  });

  // Wire normDoc toggle (enable/disable the section)
  wrap.querySelectorAll('.act-normdoc-toggle-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const i = +btn.dataset.i;
      _data.selectedItems[i].normDocEnabled = !_data.selectedItems[i].normDocEnabled;
      const section = wrap.querySelector(`.act-normdoc-section[data-i="${i}"]`);
      const icon = btn.querySelector('.nd-icon');
      if (section) section.classList.toggle('hidden', !_data.selectedItems[i].normDocEnabled);
      if (icon) icon.textContent = _data.selectedItems[i].normDocEnabled ? '▲' : '▼';
      btn.setAttribute('aria-expanded', String(_data.selectedItems[i].normDocEnabled));
    });
  });

  // Wire normDoc conforms checkbox
  wrap.querySelectorAll('.act-normdoc-conforms-cb').forEach(cb => {
    cb.addEventListener('change', () => {
      const i = +cb.dataset.i;
      _data.selectedItems[i].normDocConforms = cb.checked;
      const track = cb.closest('label')?.querySelector('div > div');
      const dot   = cb.closest('label')?.querySelector('div > div > div');
      const lbl   = wrap.querySelector(`.act-normdoc-conforms-lbl[data-i="${i}"]`);
      if (track) {
        track.classList.toggle('bg-green-500/70', cb.checked);
        track.classList.toggle('bg-red-500/60',  !cb.checked);
      }
      if (dot) {
        dot.classList.toggle('translate-x-5', cb.checked);
        dot.classList.toggle('translate-x-0', !cb.checked);
      }
      if (lbl) {
        lbl.textContent = cb.checked ? 'Соответствует' : 'Не соответствует';
        lbl.className = `act-normdoc-conforms-lbl text-sm font-semibold ${cb.checked ? 'text-green-400' : 'text-red-400'}`;
      }
    });
  });

  // Wire normDoc comment textarea
  wrap.querySelectorAll('.act-normdoc-comment').forEach(ta => {
    ta.addEventListener('input', () => {
      _data.selectedItems[+ta.dataset.i].normDocComment = ta.value;
    });
  });

  // Wire qty inputs (delivery mode)
  wrap.querySelectorAll('.act-qty-inp').forEach(inp => {
    inp.addEventListener('input', () => {
      _data.selectedItems[+inp.dataset.i].qty = inp.value;
    });
  });

  // Wire shipping-allowed toggles (delivery mode only)
  wrap.querySelectorAll('.act-shipping-cb').forEach(cb => {
    cb.addEventListener('change', () => {
      const i = +cb.dataset.i;
      _data.selectedItems[i].shippingAllowed = cb.checked;
      const card = wrap.querySelector(`.act-item-body[data-i="${i}"]`)?.closest('.act-item-card');
      if (!card) return;
      const visual = card.querySelector('.act-shipping-visual');
      const dot    = visual?.querySelector('div');
      const label  = card.querySelector('.act-shipping-label');
      if (visual) {
        visual.classList.toggle('bg-green-500/80', cb.checked);
        visual.classList.toggle('bg-red-500/60',   !cb.checked);
      }
      if (dot) {
        dot.classList.toggle('translate-x-4', cb.checked);
        dot.classList.toggle('translate-x-0', !cb.checked);
      }
      if (label) {
        label.textContent = cb.checked ? 'Разрешена' : 'Запрещена';
        label.classList.toggle('text-green-400', cb.checked);
        label.classList.toggle('text-red-400',   !cb.checked);
      }
    });
  });

  wrap.querySelectorAll('.act-so-conforms-cb').forEach(cb => {
    cb.addEventListener('change', () => {
      const i = +cb.dataset.i;
      _data.selectedItems[i].soConforms = cb.checked;
      // Update visual toggle
      const card = wrap.querySelector(`.act-item-body[data-i="${i}"]`)?.closest('.act-item-card');
      if (!card) return;
      const visual = card.querySelector('.act-so-visual');
      const dot = visual?.querySelector('div');
      const label = card.querySelector('.act-so-label');
      if (visual) {
        if (cb.checked) {
          visual.classList.remove('bg-red-500/60');
          visual.classList.add('bg-green-500/80');
        } else {
          visual.classList.remove('bg-green-500/80');
          visual.classList.add('bg-red-500/60');
        }
      }
      if (dot) {
        dot.classList.toggle('translate-x-4', cb.checked);
        dot.classList.toggle('translate-x-0', !cb.checked);
      }
      if (label) {
        label.textContent = cb.checked ? '✓ Соответствует' : '✗ Не соответствует';
        label.classList.toggle('text-green-400', cb.checked);
        label.classList.toggle('text-red-400', !cb.checked);
      }
      // Update card border color
      card.classList.toggle('border-green-500/30', cb.checked);
      card.classList.toggle('border-red-500/20', !cb.checked && _data.selectedItems[i].selected !== false);
      card.classList.toggle('border-white/10', !cb.checked);
    });
  });
}

/**
 * Re-wire events for a single replaced card (after siSoNotRequired toggle).
 * Only wires events specific to that card index.
 */
function rewireItemCard(wrap, i) {
  // siSoNotRequired checkbox
  wrap.querySelectorAll(`.act-si-so-not-required-cb[data-i="${i}"]`).forEach(cb => {
    cb.addEventListener('change', () => {
      _data.selectedItems[i].siSoNotRequired = cb.checked;
      const cardEl = wrap.querySelector(`.act-item-card[data-i="${i}"]`);
      if (cardEl) {
        const tmp = document.createElement('div');
        tmp.innerHTML = buildItemCard(_data.selectedItems[i], i);
        cardEl.replaceWith(tmp.firstElementChild);
        rewireItemCard(wrap, i);
      }
    });
  });
  // item select checkbox
  wrap.querySelectorAll(`.act-item-cb[data-i="${i}"]`).forEach(cb => {
    cb.addEventListener('change', () => {
      _data.selectedItems[i].selected = cb.checked;
      const body = wrap.querySelector(`.act-item-body[data-i="${i}"]`);
      if (body) body.classList.toggle('hidden', !cb.checked);
    });
  });
  // SO conforms toggle
  wrap.querySelectorAll(`.act-so-conforms-cb[data-i="${i}"]`).forEach(cb => {
    cb.addEventListener('change', () => {
      _data.selectedItems[i].soConforms = cb.checked;
      const card = wrap.querySelector(`.act-item-card[data-i="${i}"]`);
      if (!card) return;
      const visual = card.querySelector('.act-so-visual');
      const dot = visual?.querySelector('div');
      const label = card.querySelector('.act-so-label');
      if (visual) {
        visual.classList.toggle('bg-green-500/80', cb.checked);
        visual.classList.toggle('bg-red-500/60', !cb.checked);
      }
      if (dot) {
        dot.classList.toggle('translate-x-4', cb.checked);
        dot.classList.toggle('translate-x-0', !cb.checked);
      }
      if (label) {
        label.textContent = cb.checked ? '✓ Соответствует' : '✗ Не соответствует';
        label.classList.toggle('text-green-400', cb.checked);
        label.classList.toggle('text-red-400', !cb.checked);
      }
    });
  });
  // check result inputs
  wrap.querySelectorAll(`.act-check-inp[data-i="${i}"]`).forEach(inp => {
    inp.addEventListener('input', () => {
      _data.selectedItems[i].specs[+inp.dataset.s].checkResult = inp.value;
    });
  });
  // nonconform toggles
  wrap.querySelectorAll(`.act-nonconform-toggle[data-i="${i}"]`).forEach(cb => {
    cb.addEventListener('change', () => {
      const s = +cb.dataset.s;
      _data.selectedItems[i].specs[s].nonConform = cb.checked;
      const row = cb.closest('tr');
      if (!row) return;
      const track = row.querySelector('.nc-track');
      const dot   = row.querySelector('.nc-dot');
      const lbl   = row.querySelector('.nc-label');
      if (track) { track.classList.toggle('bg-green-500/70', cb.checked); track.classList.toggle('bg-red-500/60', !cb.checked); }
      if (dot)   { dot.classList.toggle('translate-x-5', cb.checked); dot.classList.toggle('translate-x-0', !cb.checked); }
      if (lbl)   { lbl.textContent = cb.checked ? 'Соответствует' : 'Не соответствует'; lbl.classList.toggle('text-green-400', cb.checked); lbl.classList.toggle('text-red-400', !cb.checked); }
    });
  });
  // normDoc toggle
  wrap.querySelectorAll(`.act-normdoc-toggle-btn[data-i="${i}"]`).forEach(btn => {
    btn.addEventListener('click', () => {
      _data.selectedItems[i].normDocEnabled = !_data.selectedItems[i].normDocEnabled;
      const section = wrap.querySelector(`.act-normdoc-section[data-i="${i}"]`);
      const icon = btn.querySelector('.nd-icon');
      if (section) section.classList.toggle('hidden', !_data.selectedItems[i].normDocEnabled);
      if (icon) icon.textContent = _data.selectedItems[i].normDocEnabled ? '▲' : '▼';
    });
  });
  // normDoc conforms
  wrap.querySelectorAll(`.act-normdoc-conforms-cb[data-i="${i}"]`).forEach(cb => {
    cb.addEventListener('change', () => {
      _data.selectedItems[i].normDocConforms = cb.checked;
      const lbl = wrap.querySelector(`.act-normdoc-conforms-lbl[data-i="${i}"]`);
      if (lbl) { lbl.textContent = cb.checked ? 'Соответствует' : 'Не соответствует'; lbl.className = `act-normdoc-conforms-lbl text-sm font-semibold ${cb.checked ? 'text-green-400' : 'text-red-400'}`; }
    });
  });
  // normDoc comment
  wrap.querySelectorAll(`.act-normdoc-comment[data-i="${i}"]`).forEach(ta => {
    ta.addEventListener('input', () => { _data.selectedItems[i].normDocComment = ta.value; });
  });
}

function buildItemCard(si, i) {
  const checked = si.selected !== false;
  const isDelivery = _mode === 'delivery';
  const isSOMode = _mode === 'so';
  const siSoNotRequired = !!si.siSoNotRequired;
  const inputCls = 'w-full rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]';

  // Quantity row (only for delivery mode)
  const qtyRowHtml = isDelivery ? `
    <div class="flex items-center gap-4 mt-2 mb-3 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-2.5">
      <div class="flex items-center gap-3 text-xs text-slate-400">
        <span>По контракту:</span>
        <span class="font-semibold text-slate-200">${esc(String(si.contractQty || '—'))}</span>
      </div>
      ${si._deliveredToRecipient !== undefined ? `
      <div class="flex items-center gap-3 text-xs text-slate-400">
        <span>🚚 Доставлено:</span>
        <span class="font-semibold text-emerald-400">${si._deliveredToRecipient}</span>
      </div>` : ''}
      <div class="flex items-center gap-2 ml-auto">
        <label for="actQty_${i}" class="text-xs text-slate-400 whitespace-nowrap">Фактическое кол-во:</label>
        <input id="actQty_${i}" type="number" min="0" step="1"
          ${si._deliveredToRecipient !== undefined ? `max="${si._deliveredToRecipient}"` : ''}
          class="act-qty-inp w-24 rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-sm text-white text-right
            transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
          placeholder="0" value="${esc(String(si.qty || ''))}" data-i="${i}">
      </div>
      ${si._deliveredToRecipient !== undefined && Number(si.qty || 0) > si._deliveredToRecipient ? `
      <span class="text-amber-400 text-xs">⚠ Превышает доставленное (${si._deliveredToRecipient})</span>` : ''}
    </div>` : '';

  // Чекбокс «СО не предусмотрен контрактом» убран — управляется ползунком в карточке контракта
  const soNotRequiredCheckboxHtml = '';

  // Если siSoNotRequired — показываем только зелёную пометку, без спецификаций и SO-тоггла
  const soNotRequiredBannerHtml = isSOMode && siSoNotRequired ? `
    <div class="mt-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 flex items-center gap-2">
      <span class="text-emerald-400 text-base">✓</span>
      <div>
        <p class="text-sm font-semibold text-emerald-400">Не предусмотрен</p>
        <p class="text-xs text-slate-400 mt-0.5">Проверка СО по данному товару не проводится. Статус «СО соответствует» будет установлен автоматически.</p>
      </div>
    </div>` : '';

  const specsHtml = (!isSOMode || !siSoNotRequired)
    ? (si.specs.length === 0
      ? `<p class="text-xs text-slate-500 italic py-1">${t('act.noSpecs')}</p>`
      : `<div class="overflow-x-auto rounded-xl border border-white/10 mt-2">
          <table class="w-full text-xs">
            <thead class="bg-white/[0.04]">
              <tr>
                <th class="px-3 py-2 text-left text-slate-400 font-semibold w-1/5">${t('act.colParam')}</th>
                <th class="px-3 py-2 text-left text-slate-400 font-semibold w-14">${t('act.colUnit')}</th>
                <th class="px-3 py-2 text-left text-slate-400 font-semibold w-1/5">${t('act.colContractValue')}</th>
                <th class="px-3 py-2 text-left text-slate-400 font-semibold">${t('act.colCheckResult')}</th>
                <th class="px-3 py-2 text-left text-slate-400 font-semibold w-36">Соответствие</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-white/5">
              ${si.specs.map((spec, s) => `
                <tr class="${spec.nonConform ? 'bg-red-500/5' : ''}">
                  <td class="px-3 py-2 text-slate-300">${esc(spec.param || '—')}</td>
                  <td class="px-3 py-2 text-slate-400">${esc(spec.unit || '—')}</td>
                  <td class="px-3 py-2 text-cyan-400/80">${esc(spec.value || '—')}</td>
                  <td class="px-2 py-1.5">
                    <input type="text" class="act-check-inp ${inputCls}"
                      placeholder="${t('act.checkResultPlaceholder')}"
                      value="${esc(spec.checkResult || '')}"
                      data-i="${i}" data-s="${s}">
                  </td>
                  <td class="px-2 py-1.5">
                    <label class="flex items-center gap-2 cursor-pointer select-none whitespace-nowrap">
                      <div class="relative inline-flex items-center">
                        <input type="checkbox" class="act-nonconform-toggle sr-only"
                          data-i="${i}" data-s="${s}" ${spec.nonConform ? 'checked' : ''}>
                        <div class="nc-track w-11 h-6 rounded-full transition-all duration-200 flex items-center px-0.5 ${spec.nonConform ? 'bg-green-500/70' : 'bg-red-500/60'}">
                          <div class="nc-dot w-5 h-5 rounded-full bg-white shadow-sm transition-all duration-200 ${spec.nonConform ? 'translate-x-5' : 'translate-x-0'}"></div>
                        </div>
                      </div>
                      <span class="nc-label text-xs font-medium ${spec.nonConform ? 'text-green-400' : 'text-red-400'}">${spec.nonConform ? 'Соответствует' : 'Не соответствует'}</span>
                    </label>
                  </td>
                </tr>`).join('')}
            </tbody>
          </table>
        </div>`)
    : ''; // скрываем спецификации если siSoNotRequired

  // SO conformance toggle (only in SO mode, only if siSoNotRequired = false)
  const soConforms = si.soConforms === true;
  const soToggleHtml = (isSOMode && !siSoNotRequired) ? `
    <div class="mt-3 pt-3 border-t border-white/8 flex items-center gap-3">
      <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Сигнальный образец:</span>
      <label class="flex items-center gap-3 cursor-pointer select-none">
        <div class="relative inline-flex items-center">
          <input type="checkbox" class="act-so-conforms-cb sr-only" data-i="${i}" ${soConforms ? 'checked' : ''}>
          <div class="act-so-visual w-11 h-6 rounded-full transition-all duration-200 flex items-center px-0.5 ${soConforms ? 'bg-green-500/80' : 'bg-red-500/60'}">
            <div class="w-5 h-5 rounded-full bg-white shadow-sm transition-all duration-200 ${soConforms ? 'translate-x-5' : 'translate-x-0'}"></div>
          </div>
        </div>
        <span class="act-so-label text-sm font-semibold ${soConforms ? 'text-green-400' : 'text-red-400'}">${soConforms ? '✓ Соответствует' : '✗ Не соответствует'}</span>
      </label>
    </div>` : '';

  // Shipping-allowed toggle (only in delivery mode)
  const shippingAllowed = si.shippingAllowed === true;
  const shippingToggleHtml = isDelivery ? `
    <div class="mt-3 pt-3 border-t border-white/8 flex items-center gap-3">
      <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Отгрузка:</span>
      <label class="flex items-center gap-3 cursor-pointer select-none">
        <div class="relative inline-flex items-center">
          <input type="checkbox" class="act-shipping-cb sr-only" data-i="${i}" ${shippingAllowed ? 'checked' : ''}>
          <div class="act-shipping-visual w-11 h-6 rounded-full transition-all duration-200 flex items-center px-0.5 ${shippingAllowed ? 'bg-green-500/80' : 'bg-red-500/60'}">
            <div class="w-5 h-5 rounded-full bg-white shadow-sm transition-all duration-200 ${shippingAllowed ? 'translate-x-4' : 'translate-x-0'}"></div>
          </div>
        </div>
        <span class="act-shipping-label text-sm font-semibold ${shippingAllowed ? 'text-green-400' : 'text-red-400'}">${shippingAllowed ? 'Разрешена' : 'Запрещена'}</span>
      </label>
    </div>` : '';

  // ── Нормативные документы (опциональная строка) ──
  const normDocEnabled  = !!si.normDocEnabled;
  const normDocConforms = si.normDocConforms !== false; // default true
  const normDocComment  = si.normDocComment || '';
  const normDocHtml = (!isSOMode || !siSoNotRequired) ? `
    <div class="mt-3 pt-3 border-t border-white/8">
      <button type="button" class="act-normdoc-toggle-btn inline-flex items-center gap-2
        rounded-xl border border-dashed border-cyan-400/25 bg-cyan-400/5
        px-3 py-1.5 text-xs font-medium text-cyan-400
        hover:bg-cyan-400/10 hover:border-cyan-400/50 transition w-full justify-between"
        data-i="${i}" aria-expanded="${normDocEnabled}">
        <span class="flex items-center gap-1.5">
          <span aria-hidden="true">📋</span>
          Соответствие нормативным документам
        </span>
        <span class="nd-icon text-slate-400">${normDocEnabled ? '▲' : '▼'}</span>
      </button>
      <div class="act-normdoc-section mt-2 space-y-2 ${normDocEnabled ? '' : 'hidden'}" data-i="${i}">
        <label class="flex items-center gap-2.5 cursor-pointer select-none">
          <div class="relative inline-flex items-center">
            <input type="checkbox" class="act-normdoc-conforms-cb sr-only"
              data-i="${i}" ${normDocConforms ? 'checked' : ''}>
            <div class="w-11 h-6 rounded-full transition-all duration-200 flex items-center px-0.5
              ${normDocConforms ? 'bg-green-500/70' : 'bg-red-500/60'}">
              <div class="w-5 h-5 rounded-full bg-white shadow-sm transition-all duration-200
                ${normDocConforms ? 'translate-x-5' : 'translate-x-0'}"></div>
            </div>
          </div>
          <span class="act-normdoc-conforms-lbl text-sm font-semibold
            ${normDocConforms ? 'text-green-400' : 'text-red-400'}"
            data-i="${i}">${normDocConforms ? 'Соответствует' : 'Не соответствует'}</span>
        </label>
        <textarea class="act-normdoc-comment w-full rounded-xl border border-white/10 bg-white/5
          px-3 py-2 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]
          resize-none" rows="2"
          placeholder="Комментарий по нормативным документам…"
          data-i="${i}">${esc(normDocComment)}</textarea>
      </div>
    </div>` : '';

  // Determine card border based on SO status
  let borderCls = 'border-white/10';
  if (isSOMode && checked) {
    if (siSoNotRequired) borderCls = 'border-emerald-500/30';
    else if (soConforms) borderCls = 'border-green-500/30';
    else borderCls = 'border-red-500/20';
  }

  // Header badge — показываем соответствие/несоответствие по ползункам спецификаций
  // nonConform === false → ползунок влево → «Не соответствует»
  const hasSpecNonConform = si.specs.some(sp => sp.nonConform === false);
  let headerBadge = '';
  if (isSOMode) {
    if (siSoNotRequired) {
      headerBadge = `<span class="text-xs font-semibold px-2 py-0.5 rounded-lg bg-emerald-500/15 text-emerald-400 whitespace-nowrap">Не предусмотрен</span>`;
    } else if (hasSpecNonConform || !soConforms) {
      headerBadge = `<span class="text-xs font-semibold px-2 py-0.5 rounded-lg bg-red-500/15 text-red-400 whitespace-nowrap">⚠ Не соответствует</span>`;
    } else if (soConforms) {
      headerBadge = `<span class="text-xs font-semibold px-2 py-0.5 rounded-lg bg-green-500/15 text-green-400 whitespace-nowrap">✓ Соответствует</span>`;
    }
  } else if (isDelivery && checked) {
    // В режиме поставки: показываем статус соответствия по спецификациям
    if (hasSpecNonConform) {
      headerBadge = `<span class="text-xs font-semibold px-2 py-0.5 rounded-lg bg-red-500/15 text-red-400 whitespace-nowrap">⚠ Не соответствует</span>`;
    } else if (si.specs.length > 0) {
      headerBadge = `<span class="text-xs font-semibold px-2 py-0.5 rounded-lg bg-green-500/15 text-green-400 whitespace-nowrap">✓ Соответствует</span>`;
    }
  }

  return `
    <div class="act-item-card rounded-2xl border ${borderCls} bg-white/5 p-4 transition-colors" data-i="${i}">
      <label class="flex items-center gap-3 cursor-pointer select-none">
        <input type="checkbox" class="act-item-cb w-4 h-4 rounded accent-cyan-400"
          data-i="${i}" ${checked ? 'checked' : ''}>
        <div class="flex-1 min-w-0">
          ${si.itemCode ? `<span class="font-mono text-xs text-cyan-400/80 bg-cyan-400/10 rounded px-1.5 py-0.5 mr-1">${esc(si.itemCode)}</span>` : ''}
          <span class="text-sm font-semibold text-white">${esc(si.name)}</span>
        </div>
        ${headerBadge}
      </label>
      ${soNotRequiredCheckboxHtml}
      <div class="act-item-body mt-2 ${checked ? '' : 'hidden'}" data-i="${i}">
        ${soNotRequiredBannerHtml}
        ${qtyRowHtml}
        ${specsHtml}
        ${soToggleHtml}
        ${shippingToggleHtml}
        ${normDocHtml}
      </div>
    </div>`;
}

// ─── Result fields ────────────────────────────────────────────────

function renderResultFields() {
  const wrap = document.getElementById('actResultSectionWrap');
  if (!wrap) return;

  const areaCls = 'w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07] resize-none';

  wrap.innerHTML = `
    <div class="space-y-4">
      <div>
        <label for="actResult"
          class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">${t('act.fieldResult')}</label>
        <textarea id="actResult" rows="3" class="${areaCls}"
          placeholder="${t('act.resultPlaceholder')}">${esc(_data.result)}</textarea>
      </div>
      <div>
        <label for="actPrescription"
          class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">${t('act.fieldPrescription')}</label>
        <textarea id="actPrescription" rows="3" class="${areaCls}"
          placeholder="${t('act.prescriptionPlaceholder')}">${esc(_data.prescription)}</textarea>
      </div>
      <div>
        <label for="actDeadline"
          class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400">${t('act.fieldDeadline')}</label>
        <input id="actDeadline" type="date"
          class="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
          value="${esc(_data.deadline)}">
      </div>
    </div>`;

  document.getElementById('actResult')?.addEventListener('input', e => { _data.result = e.target.value; });
  document.getElementById('actPrescription')?.addEventListener('input', e => { _data.prescription = e.target.value; });
  document.getElementById('actDeadline')?.addEventListener('input', e => { _data.deadline = e.target.value; });
}

// ─── Save act to registry ─────────────────────────────────────────

async function onSave() {
  const btn = document.getElementById('actFormSaveBtn');

  // Collect latest DOM values
  _data.location     = document.getElementById('actLocation')?.value     ?? _data.location;
  _data.date         = document.getElementById('actDate')?.value         ?? _data.date;
  _data.result       = document.getElementById('actResult')?.value       ?? _data.result;
  _data.prescription = document.getElementById('actPrescription')?.value ?? _data.prescription;
  _data.deadline     = document.getElementById('actDeadline')?.value     ?? _data.deadline;

  if (!_data.contractId) {
    showToast(t('actsRegistry.selectContractToSave'), 'error');
    return;
  }

  try {
    if (btn) { btn.disabled = true; btn.textContent = '…'; }

    _data.mode = _mode;

    // ── Если контракт не предусматривает проверку СО —
    //    сохраняем акт, но НЕ транслируем результаты в контракт
    const actContract = _data.contractId
      ? state.contracts.find(c => c.id === _data.contractId)
      : null;
    const soNotRequiredByContract = actContract && actContract.soApprovalRequired === false;

    if (_editActId != null) {
      updateAct(_editActId, { ..._data });
    } else {
      saveAct({ ..._data });
    }

    // ── Синхронизация shippingAllowed в контракт (режим «поставка») ──
    if (_mode === 'delivery' && _data.contractId) {
      const contract = state.contracts.find(c => c.id === _data.contractId);
      if (contract) {
        let contractChanged = false;
        (_data.selectedItems || []).forEach(si => {
          if (si.selected === false) return;
          const contractItem = contract.items.find((ci, idx) => {
            if (si.itemCode && ci.code && ci.code === si.itemCode) return true;
            if (si.itemIdx !== undefined && idx === si.itemIdx) return true;
            return false;
          });
          if (contractItem) {
            const prev = contractItem.receiving?.shippingAllowed;
            const next = si.shippingAllowed === true;
            if (prev !== next) {
              contractItem.receiving = { ...(contractItem.receiving || {}), shippingAllowed: next };
              contractChanged = true;
            }
          }
        });
        if (contractChanged) {
          const { updateContract } = await import('../state.js');
          updateContract(contract.id, { items: contract.items });
        }
      }
    }

    await saveToStorage();
    showToast(_editActId != null ? 'Акт обновлён' : t('actsRegistry.saved'), 'success');

    // Update badge and refresh registry if open
    const { updateActsBadge, refreshRegistryIfOpen } = await import('./acts-registry-view.js');
    updateActsBadge();
    if (refreshRegistryIfOpen) refreshRegistryIfOpen();

  } catch (err) {
    console.error('Save act error:', err);
    showToast(t('toast.error'), 'error');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = _editActId != null ? 'Сохранить изменения' : t('actsRegistry.saveBtn');
    }
  }
}

// ─── Generate Word ────────────────────────────────────────────────

async function onGenerate() {
  const btn = document.getElementById('actFormGenerateBtn');
  if (btn) { btn.disabled = true; btn.textContent = t('act.generating'); }

  try {
    _data.location     = document.getElementById('actLocation')?.value     ?? _data.location;
    _data.date         = document.getElementById('actDate')?.value         ?? _data.date;
    _data.result       = document.getElementById('actResult')?.value       ?? _data.result;
    _data.prescription = document.getElementById('actPrescription')?.value ?? _data.prescription;
    _data.deadline     = document.getElementById('actDeadline')?.value     ?? _data.deadline;

    const contract = _data.contractId ? state.contracts.find(c => c.id === _data.contractId) : null;
    const supplier = contract?.supplierId ? state.suppliers.find(s => s.id === contract.supplierId) : null;
    // В режиме СО: товары с siSoNotRequired попадают в акт со статусом «не предусмотрен»
    const selected = _data.selectedItems.filter(si => si.selected !== false);

    _data.mode = _mode;
    const blob = await buildActDocx(_data, contract, supplier, selected);
    const typeLabel = _mode === 'so' ? 'СО' : 'поставки';
    const fname = `Акт_проверки_${typeLabel}_${contract?.number || 'б_н'}.docx`;
    downloadBlob(blob, fname);
    showToast(t('act.generated'), 'success');
  } catch (err) {
    console.error('Act generation error:', err);
    showToast(t('act.generateError'), 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = t('act.generateBtn'); }
  }
}

// ─── DOCX builder ─────────────────────────────────────────────────

/**
 * Exported so acts-registry-view can re-generate Word from saved act data.
 */
export async function buildActDocx(actData, contract, supplier, selectedItems) {
  const actDate       = fmtDate(actData.date || _data.date);
  const contractDate  = contract?.date ? fmtDate(contract.date) : '';
  const contractNum   = contract?.number || '';
  const contractTitle = contract?.title || '';
  const supplierName  = supplier?.name || (contract ? t('contracts.noSupplier') : '');

  // Use actData fields (supports both _data and saved act objects)
  const location     = actData.location     ?? '';
  const result       = actData.result       ?? '';
  const prescription = actData.prescription ?? '';
  const deadline     = actData.deadline     ?? '';

  // ── Mode-dependent text ──
  const isSO = (actData.mode || _mode) !== 'delivery';
  const subtitleLine = isSO
    ? `проверки сигнальных образцов по договору от ${contractDate}г. № ${contractNum}`
    : `проверки исполнения договора от ${contractDate}г. № ${contractNum}`;
  const bodyLine = isSO
    ? 'провели проверку представленных поставщиком сигнальных образцов. По результатам проверки установлено:'
    : 'провели проверку исполнения договора. По результатам проверки установлено:';

  // ── Commission table (invisible borders) ──
  const commFiltered = (actData.commission || []).filter(p => p.role || p.name);
  const commTable = xmlPersonTable(commFiltered);

  // ── Supplier rep table (invisible borders) ──
  const supplierRepFiltered = (actData.supplierReps || []).filter(p => p.role || p.name);
  // Если представители поставщика не указаны — вместо таблицы вставляем фразу
  const supplierRepTable = supplierRepFiltered.length > 0
    ? xmlPersonTable(supplierRepFiltered)
    : null;

  // ── Table rows — nonConform specs are bold ──
  const isDelivery = !isSO;
  let tableRows = '';
  let rowNum = 1;
  for (const si of selectedItems) {
    // Если СО не предусмотрен — одна строка с пометкой «Не предусмотрен»
    if (isSO && si.siSoNotRequired) {
      const cells = [String(rowNum), si.itemCode || '', si.name];
      // param, unit, value, checkResult columns
      cells.push('—', '—', '—', 'Не предусмотрен контрактом');
      tableRows += xmlTableRow(cells, false, false, isDelivery);
      rowNum++;
      continue;
    }

    const specs = si.specs.length > 0
      ? si.specs
      : [{ param: '', unit: '', value: '', checkResult: '', nonConform: false }];
    specs.forEach((spec, sIdx) => {
      const cells = [
        sIdx === 0 ? String(rowNum) : '',
        sIdx === 0 ? (si.itemCode || '') : '',  // Код товара
        sIdx === 0 ? si.name : '',
      ];
      if (isDelivery) {
        cells.push(sIdx === 0 ? String(si.contractQty || '') : '');
        cells.push(sIdx === 0 ? String(si.qty || '') : '');
      }
      cells.push(spec.param || '', spec.unit || '', spec.value || '', spec.checkResult || '');
      // nonConform = false → «Не соответствует» → жирный шрифт; nonConform = true → «Соответствует» → обычный
      tableRows += xmlTableRow(cells, false, false, isDelivery, !spec.nonConform ? cells.map(() => true) : null);
    });
    // Нормативные документы — отдельная строка если активировано
    if (si.normDocEnabled) {
      const ndConforms = si.normDocConforms !== false;
      const ndComment  = si.normDocComment || '';
      const ndStatus   = ndConforms ? 'Соответствует' : 'Не соответствует';
      const ndText     = ndComment ? `${ndStatus}: ${ndComment}` : ndStatus;
      const cells = ['', '', '']; // №, Код, Наименование
      if (isDelivery) { cells.push(''); cells.push(''); }
      cells.push('Соответствие НД', '', '', ndText);
      // ndConforms = false → «Не соответствует» → жирный; ndConforms = true → обычный
      tableRows += xmlTableRow(cells, false, false, isDelivery, !ndConforms ? cells.map(() => true) : null);
    }
    rowNum++;
  }

  // ── Signature tables ──
  const commSigTable = xmlSignatureTable(
    commFiltered.map(p => ({ org: '', role: p.role || '', name: toInitials(p.name) }))
  );
  const supplierSigTable = supplierRepFiltered.length > 0
    ? xmlSignatureTable(
        supplierRepFiltered.map(p => ({
          org: supplierName,
          role: p.role || '',
          name: toInitials(p.name),
        }))
      )
    : '';

  const body = [
    // Title
    xmlPara('АКТ', true, '0', '28', 'center'),
    xmlPara(''),
    // Subtitle: mode-dependent
    xmlPara(subtitleLine, false, '0', '22'),
    // Supplier name on next line
    ...(supplierName ? [xmlPara(`заключенного с ${supplierName}`, false, '0', '22')] : []),
    // Contract title on next line
    ...(contractTitle ? [xmlPara(`на ${contractTitle}`, false, '0', '22')] : []),
    xmlPara(''),
    // Location + date
    xmlPara(location, false, '0', '22'),
    xmlPara(actDate || fmtDate(actData.date), false, '0', '22'),
    xmlPara(''),
    // Commission intro
    xmlPara('В ходе исполнения указанного договора представители заказчика в составе:', false, '0', '22'),
    commTable,
    xmlPara(''),
    // Supplier reps intro + table or «не явился» phrase
    xmlPara(`при участии представителей ${supplierName}:`, false, '0', '22'),
    supplierRepTable
      ? supplierRepTable
      : xmlPara('не явился, извещен надлежащим образом', false, '720', '22'),
    xmlPara(''),
    // Body text: mode-dependent
    xmlPara(bodyLine, false, '0', '22'),
    xmlPara(''),
    // Specs table
    xmlTable(tableRows, isDelivery),
    xmlPara(''),
    // Conclusion
    xmlPara(`Заключение: ${result || '—'}`, true, '0', '22'),
    xmlPara(''),
    // Prescription
    xmlPara('Поставщику (исполнителю) необходимо', true, '0', '22'),
    xmlPara(prescription || '', false, '0', '22'),
    xmlPara(''),
    // Deadline
    xmlPara(`в срок до ${deadline ? fmtDate(deadline) : '_______________'}г.`, true, '0', '22'),
    xmlPara(''),
    xmlPara(''),
    // Signature blocks
    commSigTable,
    xmlPara(''),
    supplierSigTable,
  ].join('');

  const xml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document
  xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <w:body>
    ${body}
    <w:sectPr>
      <w:pgSz w:w="11906" w:h="16838"/>
      <w:pgMar w:top="1134" w:right="850" w:bottom="1134" w:left="1701"
               w:header="709" w:footer="709" w:gutter="0"/>
    </w:sectPr>
  </w:body>
</w:document>`;

  return buildZip(xml);
}

// ─── XML helpers ──────────────────────────────────────────────────

function xmlPara(text, bold = false, indent = '0', size = '22', align = '') {
  const alignXml  = align  ? `<w:jc w:val="${align}"/>` : '';
  const indentXml = indent && indent !== '0' ? `<w:ind w:left="${indent}"/>` : '';
  const boldXml   = bold   ? '<w:b/><w:bCs/>' : '';
  const sizeXml   = size !== '22' ? `<w:sz w:val="${size}"/><w:szCs w:val="${size}"/>` : '';
  return `<w:p>
    <w:pPr><w:spacing w:after="120"/>${alignXml}${indentXml}</w:pPr>
    <w:r><w:rPr>${boldXml}${sizeXml}</w:rPr>
      <w:t xml:space="preserve">${xe(text)}</w:t>
    </w:r>
  </w:p>`;
}

// Invisible-border two-column table for commission / supplier reps
function xmlPersonTable(persons) {
  if (!persons.length) return '';
  const noBorder = `
    <w:top    w:val="none" w:sz="0" w:space="0" w:color="auto"/>
    <w:left   w:val="none" w:sz="0" w:space="0" w:color="auto"/>
    <w:bottom w:val="none" w:sz="0" w:space="0" w:color="auto"/>
    <w:right  w:val="none" w:sz="0" w:space="0" w:color="auto"/>
    <w:insideH w:val="none" w:sz="0" w:space="0" w:color="auto"/>
    <w:insideV w:val="none" w:sz="0" w:space="0" w:color="auto"/>`;

  const rows = persons.map(p => `<w:tr>
    <w:tc>
      <w:tcPr>
        <w:tcW w:w="4500" w:type="dxa"/>
        <w:tcBorders>${noBorder}</w:tcBorders>
      </w:tcPr>
      <w:p><w:pPr><w:spacing w:after="80"/></w:pPr>
        <w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>
          <w:t xml:space="preserve">${xe(p.role || '')}</w:t></w:r></w:p>
    </w:tc>
    <w:tc>
      <w:tcPr>
        <w:tcW w:w="4860" w:type="dxa"/>
        <w:tcBorders>${noBorder}</w:tcBorders>
      </w:tcPr>
      <w:p><w:pPr><w:spacing w:after="80"/></w:pPr>
        <w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>
          <w:t xml:space="preserve">${xe(p.name || '')}</w:t></w:r></w:p>
    </w:tc>
  </w:tr>`).join('');

  return `<w:tbl>
    <w:tblPr>
      <w:tblW w:w="9360" w:type="dxa"/>
      <w:tblBorders>${noBorder}</w:tblBorders>
      <w:tblLayout w:type="fixed"/>
    </w:tblPr>
    <w:tblGrid>
      <w:gridCol w:w="4500"/>
      <w:gridCol w:w="4860"/>
    </w:tblGrid>
    ${rows}
  </w:tbl>`;
}

// Invisible-border signature table: role | signature line + initials
// For supplier reps: org | role | initials (3 cols)
function xmlSignatureTable(persons) {
  if (!persons.length) return '';
  const noBorder = `
    <w:top    w:val="none" w:sz="0" w:space="0" w:color="auto"/>
    <w:left   w:val="none" w:sz="0" w:space="0" w:color="auto"/>
    <w:bottom w:val="none" w:sz="0" w:space="0" w:color="auto"/>
    <w:right  w:val="none" w:sz="0" w:space="0" w:color="auto"/>
    <w:insideH w:val="none" w:sz="0" w:space="0" w:color="auto"/>
    <w:insideV w:val="none" w:sz="0" w:space="0" w:color="auto"/>`;

  const hasOrg = persons.some(p => p.org);

  const rows = persons.map(p => {
    if (hasOrg) {
      // 3-column: org | role | sig+initials
      return `<w:tr>
        <w:tc>
          <w:tcPr><w:tcW w:w="3000" w:type="dxa"/><w:tcBorders>${noBorder}</w:tcBorders></w:tcPr>
          <w:p><w:pPr><w:spacing w:after="80"/></w:pPr>
            <w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>
              <w:t xml:space="preserve">${xe(p.org)}</w:t></w:r></w:p>
        </w:tc>
        <w:tc>
          <w:tcPr><w:tcW w:w="3000" w:type="dxa"/><w:tcBorders>${noBorder}</w:tcBorders></w:tcPr>
          <w:p><w:pPr><w:spacing w:after="80"/></w:pPr>
            <w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>
              <w:t xml:space="preserve">${xe(p.role)}</w:t></w:r></w:p>
        </w:tc>
        <w:tc>
          <w:tcPr><w:tcW w:w="3360" w:type="dxa"/><w:tcBorders>${noBorder}</w:tcBorders></w:tcPr>
          <w:p><w:pPr><w:spacing w:after="80"/></w:pPr>
            <w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>
              <w:t xml:space="preserve">_____________________    ${xe(p.name)}</w:t></w:r></w:p>
        </w:tc>
      </w:tr>`;
    } else {
      // 2-column: role | sig+initials
      return `<w:tr>
        <w:tc>
          <w:tcPr><w:tcW w:w="4500" w:type="dxa"/><w:tcBorders>${noBorder}</w:tcBorders></w:tcPr>
          <w:p><w:pPr><w:spacing w:after="80"/></w:pPr>
            <w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>
              <w:t xml:space="preserve">${xe(p.role)}</w:t></w:r></w:p>
        </w:tc>
        <w:tc>
          <w:tcPr><w:tcW w:w="4860" w:type="dxa"/><w:tcBorders>${noBorder}</w:tcBorders></w:tcPr>
          <w:p><w:pPr><w:spacing w:after="80"/></w:pPr>
            <w:r><w:rPr><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr>
              <w:t xml:space="preserve">_____________________    ${xe(p.name)}</w:t></w:r></w:p>
        </w:tc>
      </w:tr>`;
    }
  }).join('');

  const gridCols = hasOrg
    ? `<w:gridCol w:w="3000"/><w:gridCol w:w="3000"/><w:gridCol w:w="3360"/>`
    : `<w:gridCol w:w="4500"/><w:gridCol w:w="4860"/>`;

  return `<w:tbl>
    <w:tblPr>
      <w:tblW w:w="9360" w:type="dxa"/>
      <w:tblBorders>${noBorder}</w:tblBorders>
      <w:tblLayout w:type="fixed"/>
    </w:tblPr>
    <w:tblGrid>${gridCols}</w:tblGrid>
    ${rows}
  </w:tbl>`;
}

function xmlTable(rows, isDelivery = false) {
  const headers = isDelivery
    ? ['№ п/п', 'Код товара', 'Наименование товара', 'Кол-во по договору', 'Факт. кол-во', 'Параметр', 'Ед. изм', 'Значение по договору', 'Фактическое значение']
    : ['№ п/п', 'Код товара', 'Наименование товара', 'Параметр', 'Ед. изм', 'Значение по договору', 'Фактическое значение'];
  const header = xmlTableRow(headers, true, false, isDelivery);
  const widths = isDelivery
    ? [380, 900, 1300, 700, 700, 1200, 560, 1660, 1660]
    : [380, 900, 1700, 1600, 700, 2040, 2040];
  const gridCols = widths.map(w => `<w:gridCol w:w="${w}"/>`).join('');

  return `<w:tbl>
    <w:tblPr>
      <w:tblW w:w="9360" w:type="dxa"/>
      <w:tblBorders>
        <w:top    w:val="single" w:sz="4" w:space="0" w:color="auto"/>
        <w:left   w:val="single" w:sz="4" w:space="0" w:color="auto"/>
        <w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>
        <w:right  w:val="single" w:sz="4" w:space="0" w:color="auto"/>
        <w:insideH w:val="single" w:sz="4" w:space="0" w:color="auto"/>
        <w:insideV w:val="single" w:sz="4" w:space="0" w:color="auto"/>
      </w:tblBorders>
      <w:tblLayout w:type="fixed"/>
    </w:tblPr>
    <w:tblGrid>${gridCols}</w:tblGrid>
    ${header}${rows}
  </w:tbl>`;
}

function xmlTableRow(cells, header = false, boldRow = false, isDelivery = false, boldCells = null) {
  const widths = isDelivery
    ? [380, 900, 1300, 700, 700, 1200, 560, 1660, 1660]
    : [380, 900, 1700, 1600, 700, 2040, 2040];
  const cellsXml = cells.map((text, i) => {
    const isBold = header || boldRow || (boldCells ? !!boldCells[i] : false);
    const boldXml    = isBold ? '<w:b/><w:bCs/>' : '';
    const shadingXml = header ? '<w:shd w:val="clear" w:color="auto" w:fill="D9EAF7"/>' : '';
    return `<w:tc>
      <w:tcPr>${shadingXml}<w:tcW w:w="${widths[i] ?? 1000}" w:type="dxa"/></w:tcPr>
      <w:p><w:pPr><w:jc w:val="${header ? 'center' : 'left'}"/>
        <w:spacing w:after="60"/>
      </w:pPr>
        <w:r><w:rPr>${boldXml}<w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr>
          <w:t xml:space="preserve">${xe(String(text ?? ''))}</w:t>
        </w:r>
      </w:p>
    </w:tc>`;
  }).join('');
  return `<w:tr>${cellsXml}</w:tr>`;
}

function xe(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// ─── ZIP builder ──────────────────────────────────────────────────

async function buildZip(documentXml) {
  const JSZip = window.JSZip;
  if (!JSZip) throw new Error('JSZip not loaded');

  const zip = new JSZip();
  zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml"  ContentType="application/xml"/>
  <Override PartName="/word/document.xml"
    ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`);

  zip.file('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1"
    Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
    Target="word/document.xml"/>
</Relationships>`);

  zip.file('word/document.xml', documentXml);

  zip.file('word/_rels/document.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
</Relationships>`);

  return zip.generateAsync({
    type: 'blob',
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  });
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ─── Helpers ──────────────────────────────────────────────────────

function esc(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function fmtDate(iso) {
  if (!iso) return '';
  try {
    const [y, m, d] = iso.split('-');
    return `${d}.${m}.${y}`;
  } catch { return iso; }
}

/** Convert full name "Иванов Иван Иванович" → "Иванов И.И." */
function toInitials(fullName) {
  if (!fullName) return '';
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 1) return parts[0];
  const last = parts[0];
  const initials = parts.slice(1).map(p => p[0] ? p[0].toUpperCase() + '.' : '').join('');
  return `${last} ${initials}`;
}
