/**
 * Orders view — registry and card form.
 *
 * DELIVERY MODEL:
 *   - order.deliveryRows: one row per (product × address).
 *     Fields: contractItemName, contractItemCode, price, qty, date, address, recipientName, recipientId
 *   - UI: address rows listed in a top table; product table shows qty per address.
 */

import { $, el, clearChildren } from './dom.js';
import { state } from '../state.js';
import {
  addOrder, updateOrder, deleteOrder,
  generateOrderNumber, getNextOrderSeq,
  calcOrderDelivered, calcOrderAssembled,
} from '../state.js';
import { saveToStorage } from '../storage.js';
import { showToast } from './toast.js';
import { renderProgramFinanceSummary, refreshContractItemsOrdered } from './contracts-view.js';
import { makeColumnsResizable } from './resizable-cols.js';
import { attachFrozenManager } from './frozen-table.js';

const t = (key, vals) => window.miniappI18n?.t(key, vals) ?? key;

const fmt = new Intl.NumberFormat('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtMoney = v => fmt.format(Number(v) || 0);
const fmtDate = d => {
  if (!d) return '—';
  const [y, m, day] = d.split('-');
  return `${day}.${m}.${y}`;
};

// ─── State ──────────────────────────────────────────────────────
let editingOrderId = null;
let registrySearchQuery = '';

/**
 * addressRows: list of delivery addresses.
 * Each: { id, address, recipientName, recipientId }
 */
let addressRows = [];
let nextAddrId = 1;
function makeAddrId() { return nextAddrId++; }

/**
 * itemRows: one entry per contract item.
 * Each: { id, contractItemName, contractItemCode, price, qtys: Map<addrId, qty>, date }
 */
let itemRows = [];
let nextItemId = 1;
function makeItemId() { return nextItemId++; }

// ─── Helpers ────────────────────────────────────────────────────
function getSupplierName(supplierId) {
  if (!supplierId) return '—';
  const s = (state.suppliers || []).find(x => x.id === supplierId);
  return s ? s.name : '—';
}

function getContractDisplay(c) {
  if (!c) return '—';
  return c.number ? `№ ${c.number}` : (c.title || `ID ${c.id}`);
}

function getApprovedItems(contract) {
  if (!contract || !Array.isArray(contract.items)) return [];
  return contract.items;
}

function getItemName(contractItem) {
  return contractItem.name && contractItem.name.trim() ? contractItem.name.trim() : '—';
}

function buildItemCode(contractItem, contractNumber) {
  const productRef = contractItem.productRef ?? contractItem.productId ?? null;
  const prod = productRef != null ? (state.products || []).find(p => p.id === productRef) : null;
  const prodNum = prod ? String(prod.number).padStart(4, '0') : '0000';
  const contractDigits = String(contractNumber ?? '').replace(/\D/g, '');
  const contractSuffix = contractDigits.length >= 4
    ? contractDigits.slice(-4)
    : contractDigits.padStart(4, '0');
  return `${prodNum}/${contractSuffix}`;
}

function resolveProductByContractItem(contractItem) {
  const ref = contractItem.productRef ?? contractItem.productId ?? null;
  if (ref != null) {
    const p = state.products.find(p => p.id === ref);
    if (p) return p;
  }
  const name = (contractItem.name || '').trim().toLowerCase();
  if (name) {
    const p = state.products.find(p => (p.name || '').trim().toLowerCase() === name);
    if (p) return p;
  }
  return null;
}

function productRequiresAssembly(product) {
  return product && product.assembly === 'required';
}

// ─── Flat rows ↔ structured model ───────────────────────────────

/**
 * Convert flat deliveryRows (saved format) → addressRows + itemRows
 */
function loadFromDeliveryRows(deliveryRows) {
  addressRows = [];
  itemRows = [];
  nextAddrId = 1;
  nextItemId = 1;

  if (!deliveryRows || deliveryRows.length === 0) return;

  // Collect unique addresses (preserve order)
  const addrMap = new Map(); // "address||recipientName" → addrId
  deliveryRows.forEach(r => {
    const key = (r.address || '') + '||' + (r.recipientName || '');
    if (!addrMap.has(key)) {
      const id = makeAddrId();
      addrMap.set(key, id);
      addressRows.push({
        id,
        address: r.address || '',
        recipientName: r.recipientName || '',
        recipientId: r.recipientId ?? null,
      });
    }
  });

  // Collect unique items (by contractItemName)
  const itemMap = new Map(); // contractItemName → itemId
  deliveryRows.forEach(r => {
    const key = r.contractItemName || '';
    if (!itemMap.has(key)) {
      const id = makeItemId();
      itemMap.set(key, id);
      itemRows.push({
        id,
        contractItemName: r.contractItemName || '',
        contractItemCode: r.contractItemCode || '',
        price: Number(r.price) || 0,
        date: r.date || '',
        qtys: new Map(),
      });
    }
    // Set qty for this address
    const itemId = itemMap.get(key);
    const addrId = addrMap.get((r.address || '') + '||' + (r.recipientName || ''));
    const item = itemRows.find(x => x.id === itemId);
    if (item && addrId != null) {
      item.qtys.set(addrId, (item.qtys.get(addrId) || 0) + (Number(r.qty) || 0));
    }
  });
}

/**
 * Convert addressRows + itemRows → flat deliveryRows for saving
 */
function buildDeliveryRowsForSave() {
  const rows = [];
  itemRows.forEach(item => {
    addressRows.forEach(addr => {
      const qty = item.qtys.get(addr.id) || 0;
      rows.push({
        contractItemName: item.contractItemName,
        contractItemCode: item.contractItemCode,
        price: item.price,
        qty,
        date: item.date,
        address: addr.address,
        recipientName: addr.recipientName,
        recipientId: addr.recipientId,
      });
    });
  });
  return rows;
}

// ─── Limit helpers ───────────────────────────────────────────────

function getCurrentContractId() {
  const sel = document.getElementById('orderContractSel');
  return sel ? Number(sel.value) || null : null;
}

function getItemQtyLimit(itemNameKey, contractId) {
  const contract = (state.contracts || []).find(c => c.id === contractId);
  if (!contract) return Infinity;
  const ci = (contract.items || []).find(i =>
    (i.name || '').trim().toLowerCase() === itemNameKey
  );
  if (!ci) return Infinity;
  const contractQty = Number(ci.qty) || 0;
  if (contractQty === 0) return Infinity;

  let alreadyOrdered = 0;
  (state.orders || [])
    .filter(o => o.contractId === contractId && o.id !== editingOrderId)
    .forEach(order => {
      (Array.isArray(order.deliveryRows) ? order.deliveryRows : []).forEach(r => {
        if ((r.contractItemName || '').trim().toLowerCase() === itemNameKey) {
          alreadyOrdered += Number(r.qty) || 0;
        }
      });
    });

  return Math.max(0, contractQty - alreadyOrdered);
}

function getContractMoneyLimit(contractId) {
  const contract = (state.contracts || []).find(c => c.id === contractId);
  if (!contract) return Infinity;
  const totalPrice = Number(contract.totalPrice) || 0;
  if (totalPrice === 0) return Infinity;

  let alreadySpent = 0;
  (state.orders || [])
    .filter(o => o.contractId === contractId && o.id !== editingOrderId)
    .forEach(order => {
      (Array.isArray(order.deliveryRows) ? order.deliveryRows : []).forEach(r => {
        alreadySpent += (Number(r.qty) || 0) * (Number(r.price) || 0);
      });
    });

  return Math.max(0, totalPrice - alreadySpent);
}

// ─── Badge ───────────────────────────────────────────────────────
export function updateOrdersBadge() {
  const badge = $('ordersBadge');
  if (!badge) return;
  const count = (state.orders || []).length;
  if (count > 0) {
    badge.textContent = count;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }
}

// ─── Registry Panel ──────────────────────────────────────────────
function renderRegistryList() {
  const container = $('ordersRegistryList');
  if (!container) return;
  clearChildren(container);

  const q = registrySearchQuery.trim().toLowerCase();
  const allOrders = state.orders || [];
  const orders = q
    ? allOrders.filter(o => {
        const contract = (state.contracts || []).find(c => c.id === o.contractId);
        const contractStr = contract
          ? `${contract.number || ''} ${contract.title || ''}`.toLowerCase()
          : '';
        const supplierStr = getSupplierName(contract?.supplierId).toLowerCase();
        const orderNum = (o.orderNumber || '').toLowerCase();
        return contractStr.includes(q) || supplierStr.includes(q) || orderNum.includes(q);
      })
    : allOrders;

  if (orders.length === 0) {
    container.appendChild(
      el('div', { className: 'py-12 text-center' },
        el('p', { className: 'text-4xl mb-3' }, q ? '🔍' : '📋'),
        el('p', { className: 'text-sm font-semibold text-slate-300 mb-1' },
          q ? 'Ничего не найдено' : t('orders.empty')),
        el('p', { className: 'text-xs text-slate-500' },
          q ? 'Попробуйте другой запрос' : t('orders.emptyHint')),
      )
    );
    return;
  }

  [...orders].reverse().forEach(order => {
    const contract = (state.contracts || []).find(c => c.id === order.contractId);
    const totalCost = (order.deliveryRows || []).reduce((s, r) =>
      s + (Number(r.qty) || 0) * (Number(r.price) || 0), 0);
    const uniqueItems = new Set((order.deliveryRows || []).map(r => r.contractItemName)).size;
    const uniqueAddrs = new Set((order.deliveryRows || []).map(r => r.address || '')).size;

    const card = el('div', { className: 'rounded-xl border border-white/10 bg-white/5 overflow-hidden transition hover:border-cyan-400/20' });

    const displayOrderNumber = (order.orderNumber && order.orderNumber.trim())
      ? order.orderNumber
      : `Заявка #${order.id}`;

    const headerRow = el('div', { className: 'flex items-center gap-2 px-4 py-3 cursor-pointer select-none' });
    headerRow.setAttribute('role', 'button');
    headerRow.setAttribute('aria-expanded', 'false');

    const arrow = el('span', { className: 'text-slate-500 text-xs shrink-0 select-none' }, '▶');
    arrow.style.transition = 'transform 0.2s';
    headerRow.appendChild(arrow);

    const titleArea = el('div', { className: 'flex-1 min-w-0 flex items-center gap-2 flex-wrap' });
    titleArea.appendChild(el('span', { className: 'text-sm font-bold text-cyan-400 truncate' }, displayOrderNumber));
    if (order.sent) titleArea.appendChild(el('span', { className: 'rounded-md bg-emerald-400/15 px-2 py-0.5 text-[10px] font-semibold text-emerald-400' }, '✉ Отправлена'));
    titleArea.appendChild(el('span', { className: 'text-xs text-slate-400 truncate' },
      `${getContractDisplay(contract)} · ${getSupplierName(contract?.supplierId)}`));
    titleArea.appendChild(el('span', { className: 'text-xs text-slate-500' },
      `${uniqueItems} поз. · ${uniqueAddrs} адр. · ${fmtMoney(totalCost)} ₽`));
    headerRow.appendChild(titleArea);

    const actions = el('div', { className: 'flex gap-1 shrink-0' });

    const supplier = contract?.supplierId
      ? (state.suppliers || []).find(s => s.id === contract.supplierId)
      : null;
    if (supplier?.email) {
      const emailBtn = el('button', {
        className: 'rounded-lg p-2 text-slate-400 hover:bg-emerald-500/20 hover:text-emerald-400 transition',
        'aria-label': 'Отправить на email',
        title: `Отправить на email: ${supplier.email}`,
      }, '✉');
      emailBtn.addEventListener('click', e => {
        e.stopPropagation();
        sendOrderByEmail(order, contract, supplier);
      });
      actions.appendChild(emailBtn);
    }

    const editBtn = el('button', {
      className: 'rounded-lg p-2 text-slate-400 hover:bg-white/10 hover:text-white transition',
      'aria-label': t('actions.edit'),
      title: t('actions.edit'),
    }, '✎');
    editBtn.addEventListener('click', e => { e.stopPropagation(); openOrderCard(order.id); });

    const delBtn = el('button', {
      className: 'rounded-lg p-2 text-slate-400 hover:bg-red-500/20 hover:text-red-400 transition',
      'aria-label': t('actions.delete'),
      title: t('actions.delete'),
    }, '✕');
    delBtn.addEventListener('click', e => {
      e.stopPropagation();
      if (!confirm(t('orders.confirmDelete'))) return;
      deleteOrder(order.id);
      saveToStorage();
      updateOrdersBadge();
      renderRegistryList();
      showToast(t('orders.deleted'), 'success');
    });

    actions.append(editBtn, delBtn);
    headerRow.appendChild(actions);
    card.appendChild(headerRow);

    const body = el('div', { className: 'hidden border-t border-white/10 px-4 py-3 space-y-1' });
    const dateStr = order.createdAt ? new Date(order.createdAt).toLocaleDateString('ru-RU') : '';
    if (order.sentDate) body.appendChild(el('p', { className: 'text-xs text-slate-500' }, `✉ Отправлена: ${fmtDate(order.sentDate)}`));
    if (dateStr) body.appendChild(el('p', { className: 'text[10px] text-slate-600' }, `Создана: ${dateStr}`));

    // Show address list preview
    const addrSet = new Set();
    (order.deliveryRows || []).forEach(r => {
      if (r.address) addrSet.add((r.recipientName ? r.recipientName + ': ' : '') + r.address);
    });
    addrSet.forEach(a => body.appendChild(el('p', { className: 'text-xs text-slate-500' }, `📍 ${a}`)));

    const openBtn = el('button', {
      type: 'button',
      className: 'mt-2 inline-flex items-center gap-1.5 rounded-xl border border-cyan-400/30 bg-cyan-400/5 px-3 py-1.5 text-xs font-semibold text-cyan-400 hover:bg-cyan-400/15 transition',
    }, '✎ Открыть заявку');
    openBtn.addEventListener('click', (e) => { e.stopPropagation(); openOrderCard(order.id, true); });
    body.appendChild(openBtn);
    card.appendChild(body);

    headerRow.addEventListener('click', e => {
      if (e.target.closest('button')) return;
      const expanded = headerRow.getAttribute('aria-expanded') === 'true';
      headerRow.setAttribute('aria-expanded', String(!expanded));
      arrow.style.transform = expanded ? '' : 'rotate(90deg)';
      body.classList.toggle('hidden', expanded);
    });

    container.appendChild(card);
  });
}

// ─── Email send ──────────────────────────────────────────────────
function sendOrderByEmail(order, contract, supplier) {
  const orderNum = order.orderNumber || `#${order.id}`;
  const contractStr = contract
    ? (contract.number ? `№ ${contract.number}` : contract.title || '—')
    : '—';
  const programCode = order.programCode || '—';

  const subject = encodeURIComponent(`Заявка на поставку ${orderNum}`);

  const lines = [
    `Заявка на поставку: ${orderNum}`,
    `Контракт: ${contractStr}`,
    `Целевая программа: ${programCode}`,
    '',
    '№  Наименование  Код  Цена  Адрес  Кол-во  Стоимость  Срок',
    '---',
  ];

  // Group by item
  const itemMap = new Map();
  (order.deliveryRows || []).forEach(r => {
    if (!itemMap.has(r.contractItemName)) itemMap.set(r.contractItemName, []);
    itemMap.get(r.contractItemName).push(r);
  });

  let n = 0;
  let grandTotal = 0;
  itemMap.forEach((rows, name) => {
    n++;
    const totalQty = rows.reduce((s, r) => s + (Number(r.qty) || 0), 0);
    const cost = rows.reduce((s, r) => s + (Number(r.qty) || 0) * (Number(r.price) || 0), 0);
    grandTotal += cost;
    lines.push(`${n}. ${name}  [${rows[0].contractItemCode}]  ${fmtMoney(rows[0].price)} ₽  итого: ${totalQty} шт.  ${fmtMoney(cost)} ₽`);
    rows.forEach(r => {
      if (r.address) {
        lines.push(`   → ${r.recipientName || r.address}: ${r.qty} шт.  ${r.date ? fmtDate(r.date) : '—'}`);
      }
    });
  });

  lines.push('', `ИТОГО: ${fmtMoney(grandTotal)} ₽`);
  lines.push('', `Дата формирования: ${new Date().toLocaleDateString('ru-RU')}`);

  const body = encodeURIComponent(lines.join('\n'));
  window.open(`mailto:${supplier.email}?subject=${subject}&body=${body}`, '_blank');

  const o = (state.orders || []).find(x => x.id === order.id);
  if (o) {
    o.sent = true;
    o.sentDate = new Date().toISOString().slice(0, 10);
    saveToStorage();
    renderRegistryList();
    showToast(`✉ Открыт почтовый клиент: ${supplier.email}`, 'success');
  }
}

// ─── Order Card ──────────────────────────────────────────────────

let _orderReadonly = false;
export function openOrderCard(orderId, readonly = false) {
  editingOrderId = orderId || null;
  addressRows = [];
  itemRows = [];
  nextAddrId = 1;
  nextItemId = 1;

  const panel = $('orderCardPanel');
  const listPanel = $('ordersRegistryListPanel');
  if (!panel || !listPanel) return;

  if (orderId) {
    const order = (state.orders || []).find(o => o.id === orderId);
    if (order) {
      if (Array.isArray(order.deliveryRows) && order.deliveryRows.length > 0) {
        loadFromDeliveryRows(order.deliveryRows);
      } else if (Array.isArray(order.items) && order.items.length > 0) {
        // Migrate old format
        const flatRows = [];
        order.items.forEach(item => {
          const scheds = Array.isArray(item.deliverySchedules) ? item.deliverySchedules : [];
          if (scheds.length === 0) {
            flatRows.push({
              contractItemName: item.contractItemName || '—',
              contractItemCode: item.contractItemCode || '—',
              price: Number(item.price) || 0,
              qty: Number(item.qty) || 0,
              date: item.defaultDate || '',
              address: '',
              recipientName: '',
            });
          } else {
            scheds.forEach(sc => {
              flatRows.push({
                contractItemName: item.contractItemName || '—',
                contractItemCode: item.contractItemCode || '—',
                price: Number(sc.price) || Number(item.price) || 0,
                qty: Number(sc.qty) || 0,
                date: sc.date || '',
                address: '',
                recipientName: '',
              });
            });
          }
        });
        loadFromDeliveryRows(flatRows);
      }
    }
  }

  listPanel.classList.add('hidden');
  panel.classList.remove('hidden');
  _orderReadonly = readonly;
  renderOrderCard();
  if (readonly) setOrderCardReadonly(true);
}

function closeOrderCard() {
  const panel = $('orderCardPanel');
  const listPanel = $('ordersRegistryListPanel');
  if (!panel || !listPanel) return;
  panel.classList.add('hidden');
  listPanel.classList.remove('hidden');
}

function setOrderCardReadonly(readonly) {
  _orderReadonly = readonly;
  const panel = $('orderCardPanel');
  if (!panel) return;
  panel.querySelectorAll('input, select, textarea').forEach(inp => {
    inp.disabled = readonly;
    inp.style.opacity = readonly ? '0.7' : '';
    inp.style.cursor = readonly ? 'default' : '';
  });
  const saveBtn = $('orderCardSaveBtn');
  const exportBtn = $('orderExportBtn');
  const editBtn = $('orderCardEditBtn');
  if (saveBtn) saveBtn.classList.toggle('hidden', readonly);
  if (exportBtn) exportBtn.classList.toggle('hidden', readonly);
  if (editBtn) editBtn.classList.toggle('hidden', !readonly);
  panel.querySelectorAll('.addr-del-btn, .addr-add-btn').forEach(b => {
    b.classList.toggle('hidden', readonly);
  });
}

// ─── Render order card ───────────────────────────────────────────

function renderOrderCard() {
  const wrap = $('orderCardBody');
  if (!wrap) return;
  clearChildren(wrap);

  const order = editingOrderId
    ? (state.orders || []).find(o => o.id === editingOrderId)
    : null;

  const contracts = state.contracts || [];

  // ── Info section ──
  const infoSection = el('section', {});
  infoSection.appendChild(
    el('h3', { className: 'text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3' },
      t('orders.sectionInfo'))
  );

  const fields = el('div', { className: 'space-y-4' });

  // Contract
  const contractSel = el('select', {
    id: 'orderContractSel',
    className: 'w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-slate-300 transition focus:border-cyan-400/50 focus:bg-white/[0.07]',
  });
  contractSel.appendChild(el('option', { value: '' }, t('orders.selectContract')));
  contracts.forEach(c => {
    const supplierName = getSupplierName(c.supplierId);
    const contractLabel = supplierName && supplierName !== '—'
      ? `${getContractDisplay(c)} — ${supplierName}`
      : getContractDisplay(c);
    const opt = el('option', { value: String(c.id) }, contractLabel);
    if (order && order.contractId === c.id) opt.selected = true;
    contractSel.appendChild(opt);
  });

  // Program
  const programSel = el('select', {
    id: 'orderProgramSel',
    className: 'w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-slate-300 transition focus:border-cyan-400/50 focus:bg-white/[0.07]',
  });

  // Number display
  const numDisplay = el('div', {
    id: 'orderNumberDisplay',
    className: 'w-full rounded-xl border border-white/10 bg-white/[0.03] px-4 py-2.5 text-sm font-bold text-cyan-400',
  }, order ? (order.orderNumber || '—') : t('orders.numberAutoHint'));

  // Warehouse selector
  const warehouseSel = el('select', {
    id: 'orderWarehouseSel',
    className: 'w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-slate-300 transition focus:border-cyan-400/50 focus:bg-white/[0.07]',
  });
  warehouseSel.appendChild(el('option', { value: '' }, '— Выберите склад (необязательно) —'));
  (state.warehouses || []).forEach(wh => {
    const opt = el('option', { value: String(wh.id) }, wh.name + (wh.address ? ` — ${wh.address}` : ''));
    if (order?.warehouseId === wh.id) opt.selected = true;
    warehouseSel.appendChild(opt);
  });

  fields.appendChild(wrapField(labelEl('orderContractSel', t('orders.fieldContract')), contractSel));
  fields.appendChild(wrapField(labelEl('orderProgramSel', t('orders.fieldProgram')), programSel));
  fields.appendChild(wrapField(labelEl('orderNumberDisplay', t('orders.fieldNumber')), numDisplay));
  fields.appendChild(wrapField(labelEl('orderWarehouseSel', 'Склад доставки'), (() => {
    const w = el('div', {});
    w.appendChild(warehouseSel);
    w.appendChild(el('p', { className: 'mt-1 text-[11px] text-slate-500' }, 'Необязательно'));
    return w;
  })()));

  // ── Sent status ──
  const sentWrap = el('div', { className: 'flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-3' });
  const sentLeft = el('div', { className: 'flex items-center gap-3' });
  const sentCheckbox = el('input', { type: 'checkbox', id: 'orderSentCheck', className: 'w-4 h-4 rounded accent-cyan-400 cursor-pointer' });
  if (order?.sent) sentCheckbox.checked = true;
  const sentLabel = el('label', { 'for': 'orderSentCheck', className: 'text-sm font-medium text-slate-300 cursor-pointer select-none' }, 'Отправлена поставщику');
  sentLeft.append(sentCheckbox, sentLabel);
  const sentDateInput = el('input', {
    type: 'date', id: 'orderSentDate',
    className: 'rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-white focus:border-cyan-400/50 focus:outline-none',
    'aria-label': 'Дата отправки',
  });
  sentDateInput.value = order?.sentDate || '';
  sentDateInput.style.display = order?.sent ? '' : 'none';
  sentCheckbox.addEventListener('change', () => {
    sentDateInput.style.display = sentCheckbox.checked ? '' : 'none';
    if (sentCheckbox.checked && !sentDateInput.value)
      sentDateInput.value = new Date().toISOString().slice(0, 10);
  });
  sentWrap.appendChild(sentLeft);
  sentWrap.appendChild(sentDateInput);

  const sentSection = el('div', { className: 'space-y-2' });
  sentSection.appendChild(sentWrap);

  const contractForEmail = order?.contractId
    ? (state.contracts || []).find(c => c.id === order.contractId)
    : null;
  const supplierForEmail = contractForEmail?.supplierId
    ? (state.suppliers || []).find(s => s.id === contractForEmail.supplierId)
    : null;
  if (supplierForEmail?.email) {
    const emailBtn = el('button', {
      type: 'button',
      className: 'w-full inline-flex items-center justify-center gap-2 rounded-xl border border-emerald-400/25 bg-emerald-400/[0.06] px-4 py-2.5 text-sm font-semibold text-emerald-400 transition hover:bg-emerald-400/15',
    }, '✉ Отправить на email поставщика (' + supplierForEmail.email + ')');
    emailBtn.addEventListener('click', () => {
      if (order) {
        sendOrderByEmail(order, contractForEmail, supplierForEmail);
        sentCheckbox.checked = true;
        sentDateInput.style.display = '';
        if (!sentDateInput.value) sentDateInput.value = new Date().toISOString().slice(0, 10);
      } else {
        showToast('Сначала сохраните заявку', 'info');
      }
    });
    sentSection.appendChild(emailBtn);
  }

  fields.appendChild(el('div', {}, ...(() => {
    const lbl = el('label', { className: 'mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400' }, 'Статус отправки');
    return [lbl, sentSection];
  })()));

  infoSection.appendChild(fields);
  wrap.appendChild(infoSection);

  // ── Validation warnings ──
  wrap.appendChild(el('div', { id: 'orderValidationWarnings', className: 'mt-4' }));

  // ── Program helpers ──
  function refreshProgramOptions() {
    clearChildren(programSel);
    const contractId = Number(contractSel.value) || null;
    const contract = contractId ? contracts.find(c => c.id === contractId) : null;
    const contractProgNames = (contract?.programs || []).map(p =>
      typeof p === 'string' ? p : (p.name || p.code || '')
    ).filter(Boolean);
    const globalProgs = (state.programs || []).filter(p =>
      contractProgNames.includes(p.name) || contractProgNames.includes(p.code)
    );
    const missingProgs = contractProgNames.filter(name =>
      !globalProgs.some(p => p.name === name || p.code === name)
    );
    if (!contract) {
      programSel.appendChild(el('option', { value: '' }, '— Сначала выберите контракт —'));
    } else if (globalProgs.length === 0 && missingProgs.length === 0) {
      programSel.appendChild(el('option', { value: '' }, '— Нет программ, привязанных к контракту —'));
    } else {
      const allProgs = [
        ...globalProgs.map(p => ({ value: p.code || p.name, label: p.code ? `${p.name} (${p.code})` : p.name })),
        ...missingProgs.map(name => ({ value: name, label: name })),
      ];
      allProgs.forEach(prog => {
        const opt = el('option', { value: prog.value }, prog.label);
        if (order && order.programCode === prog.value) opt.selected = true;
        programSel.appendChild(opt);
      });
      if (!order?.programCode && allProgs.length === 1) programSel.value = allProgs[0].value;
    }
  }

  function refreshOrderNumber() {
    const contractId = contractSel.value;
    const c = contracts.find(x => x.id === Number(contractId));
    const programCode = programSel.value;
    if (!c) { numDisplay.textContent = t('orders.numberAutoHint'); return; }
    if (editingOrderId !== null) {
      const existingOrder = (state.orders || []).find(o => o.id === editingOrderId);
      if (existingOrder) {
        const programChanged = existingOrder.programCode !== programCode;
        if (!programChanged && existingOrder.orderNumber) {
          numDisplay.textContent = existingOrder.orderNumber;
        } else if (existingOrder.orderNumber && programChanged) {
          const seq = existingOrder.seqNum || 1;
          numDisplay.textContent = generateOrderNumber(c, seq, programCode);
        } else {
          const seq = getNextOrderSeq(c.id);
          numDisplay.textContent = generateOrderNumber(c, seq, programCode);
        }
        return;
      }
    }
    const seq = getNextOrderSeq(c.id);
    numDisplay.textContent = generateOrderNumber(c, seq, programCode);
  }

  contractSel.addEventListener('change', () => {
    const contractId = Number(contractSel.value);
    const c = contracts.find(x => x.id === contractId);
    // Reset to contract items with empty addresses
    addressRows = [];
    itemRows = [];
    nextAddrId = 1;
    nextItemId = 1;
    if (c) {
      getApprovedItems(c).forEach(item => {
        itemRows.push({
          id: makeItemId(),
          contractItemName: getItemName(item),
          contractItemCode: buildItemCode(item, c.number),
          price: Number(item.price) || 0,
          date: '',
          qtys: new Map(),
        });
      });
    }
    refreshProgramOptions();
    refreshOrderNumber();
    renderAddressesSection(addrSection, contracts.find(x => x.id === contractId));
    renderItemsSection(itemsWrap, contracts.find(x => x.id === contractId));
    validateCurrentOrder();
  });

  programSel.addEventListener('change', () => {
    refreshOrderNumber();
    validateCurrentOrder();
  });

  refreshProgramOptions();
  if (order?.contractId) contractSel.value = String(order.contractId);
  refreshProgramOptions();
  refreshOrderNumber();

  const currentContract = order?.contractId
    ? contracts.find(c => String(c.id) === String(order.contractId))
    : null;

  // ── Addresses section ──
  const addrSection = el('section', { id: 'orderAddrSection', className: 'mt-6' });
  wrap.appendChild(addrSection);

  // ── Items section ──
  const itemsWrap = el('div', { id: 'orderItemsWrap' });
  const itemsSection = el('section', { className: 'mt-6' });
  itemsSection.appendChild(
    el('h3', { className: 'text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3' },
      t('orders.sectionItems'))
  );
  itemsSection.appendChild(itemsWrap);
  wrap.appendChild(itemsSection);

  renderAddressesSection(addrSection, currentContract);
  renderItemsSection(itemsWrap, currentContract);
  validateCurrentOrder();
}

function labelEl(forId, text) {
  return el('label', { 'for': forId, className: 'mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400' }, text);
}
function wrapField(label, input) {
  const div = el('div', {});
  div.appendChild(label);
  div.appendChild(input);
  return div;
}

// ─── Addresses section ───────────────────────────────────────────

function renderAddressesSection(container, contract) {
  clearChildren(container);

  const header = el('div', { className: 'flex items-center justify-between mb-3' });
  header.appendChild(el('h3', { className: 'text-xs font-semibold uppercase tracking-wider text-slate-400' }, 'Адреса поставки'));

  const addBtn = el('button', {
    type: 'button',
    className: 'addr-add-btn inline-flex items-center gap-1.5 rounded-xl border border-cyan-400/30 bg-cyan-400/[0.06] px-3 py-1.5 text-xs font-semibold text-cyan-400 hover:bg-cyan-400/15 transition',
    'aria-label': 'Добавить адрес',
  }, '＋ Добавить адрес');
  addBtn.addEventListener('click', () => {
    addressRows.push({ id: makeAddrId(), address: '', recipientName: '', recipientId: null });
    // Add empty qty for new address in all items
    renderAddressesSection(container, contract);
    renderItemsSection($('orderItemsWrap'), contract);
  });
  header.appendChild(addBtn);
  container.appendChild(header);

  if (addressRows.length === 0) {
    container.appendChild(
      el('div', { className: 'rounded-xl border border-dashed border-white/10 p-4 text-center text-xs text-slate-500' },
        '📍 Добавьте адреса поставки — для каждого можно указать отдельное количество товара'
      )
    );
    return;
  }

  const list = el('div', { className: 'space-y-2' });

  addressRows.forEach((addr, idx) => {
    const row = el('div', { className: 'flex items-start gap-2 rounded-xl border border-white/10 bg-white/5 p-3' });

    // Number
    row.appendChild(el('span', { className: 'text-xs text-slate-500 font-bold mt-2 shrink-0 w-5 text-center' }, String(idx + 1)));

    // Recipient name
    const recipInput = el('input', {
      type: 'text',
      value: addr.recipientName || '',
      placeholder: 'Получатель (название организации)',
      className: 'flex-1 min-w-0 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder-slate-600 focus:border-cyan-400/50 focus:outline-none',
      'aria-label': 'Название получателя',
      list: 'recipientsSuggestList',
    });
    recipInput.addEventListener('input', () => {
      addr.recipientName = recipInput.value;
      // Try to resolve recipientId from state
      const match = (state.recipients || []).find(r =>
        r.name && r.name.toLowerCase() === recipInput.value.toLowerCase()
      );
      addr.recipientId = match?.id ?? null;
    });
    row.appendChild(recipInput);

    // Address
    const addrInput = el('input', {
      type: 'text',
      value: addr.address || '',
      placeholder: 'Адрес поставки',
      className: 'flex-1 min-w-0 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder-slate-600 focus:border-cyan-400/50 focus:outline-none',
      'aria-label': 'Адрес поставки',
    });
    addrInput.addEventListener('input', () => {
      addr.address = addrInput.value;
    });
    row.appendChild(addrInput);

    // Delete button
    const delBtn = el('button', {
      type: 'button',
      className: 'addr-del-btn rounded-lg p-2 text-slate-500 hover:text-red-400 hover:bg-red-400/10 transition shrink-0',
      'aria-label': 'Удалить адрес',
      title: 'Удалить адрес',
    }, '✕');
    delBtn.addEventListener('click', () => {
      const i = addressRows.findIndex(a => a.id === addr.id);
      if (i !== -1) addressRows.splice(i, 1);
      renderAddressesSection(container, contract);
      renderItemsSection($('orderItemsWrap'), contract);
    });
    row.appendChild(delBtn);

    list.appendChild(row);
  });

  container.appendChild(list);

  // Datalist for recipients autocomplete
  const dl = el('datalist', { id: 'recipientsSuggestList' });
  (state.recipients || []).forEach(r => {
    dl.appendChild(el('option', { value: r.name || '' }));
  });
  container.appendChild(dl);
}

// ─── Items section ───────────────────────────────────────────────

function renderItemsSection(wrap, contract) {
  clearChildren(wrap);

  if (!contract) {
    wrap.appendChild(el('p', { className: 'text-sm text-slate-500 py-4' }, t('orders.selectContractFirst')));
    return;
  }

  if (itemRows.length === 0) {
    wrap.appendChild(el('div', { className: 'rounded-xl border border-amber-400/20 bg-amber-400/5 p-4' },
      el('p', { className: 'text-sm text-amber-400' }, '⚠️ ' + t('orders.noApprovedItems')),
      el('p', { className: 'text-xs text-slate-500 mt-1' }, t('orders.noApprovedItemsHint')),
    ));
    return;
  }

  if (addressRows.length === 0) {
    wrap.appendChild(el('p', { className: 'text-xs text-slate-500 py-2 italic' },
      'Добавьте адреса поставки выше — затем укажите количество для каждого адреса'));
    return;
  }

  const tableWrap = el('div', { id: 'orderItemsWrap2', className: 'overflow-x-auto rounded-xl border border-white/10' });
  const table = el('table', { className: 'w-full text-sm border-collapse' });

  // ── Header ──
  const thead = el('thead', { className: 'bg-slate-900' });

  // Row 1: fixed cols + address group headers
  const hRow1 = el('tr', {});
  [
    { label: '№',                     cls: 'w-8 text-center',      rowspan: 2 },
    { label: 'Наименование',          cls: 'min-w-[200px]',        rowspan: 2 },
    { label: 'Код',                   cls: 'min-w-[100px]',        rowspan: 2 },
    { label: 'Цена, ₽',              cls: 'w-28 text-right',      rowspan: 2 },
    { label: 'Итого шт.',            cls: 'w-20 text-right',      rowspan: 2 },
    { label: 'Итого ₽',             cls: 'w-32 text-right',      rowspan: 2 },
    { label: 'Поставлено',           cls: 'w-24 text-right',      rowspan: 2 },
    { label: 'Собрано',              cls: 'w-24 text-right',      rowspan: 2 },
    { label: 'Срок поставки',        cls: 'min-w-[130px]',        rowspan: 2 },
  ].forEach(h => {
    const th = el('th', {
      className: `px-3 py-2 text-xs font-semibold uppercase tracking-wider text-slate-400 ${h.cls}`,
      rowspan: String(h.rowspan || 1),
    }, h.label);
    hRow1.appendChild(th);
  });

  // Address columns header (span 2 rows)
  addressRows.forEach((addr, idx) => {
    const label = addr.recipientName || addr.address || `Адрес ${idx + 1}`;
    const th = el('th', {
      className: 'px-2 py-1.5 text-[11px] font-semibold text-slate-300 text-center min-w-[90px] border-l border-white/10',
      title: addr.address || '',
    });
    // Short label (max 20 chars)
    const shortLabel = label.length > 20 ? label.slice(0, 18) + '…' : label;
    th.textContent = shortLabel;
    if (addr.address && addr.address !== label) {
      th.title = addr.address;
    }
    hRow1.appendChild(th);
  });

  thead.appendChild(hRow1);
  table.appendChild(thead);

  // ── Body ──
  const tbody = el('tbody', { className: 'divide-y divide-white/5 align-middle' });

  let grandTotalQty = 0;
  let grandTotalCost = 0;

  itemRows.forEach((item, idx) => {
    const tr = el('tr', { className: 'hover:bg-white/[0.02] align-middle' });

    // Col 0: №
    tr.appendChild(el('td', { className: 'px-2 py-2.5 text-xs text-slate-500 text-center tabular-nums' }, String(idx + 1)));

    // Col 1: Name
    const nameTd = el('td', { className: 'px-3 py-2.5 text-sm text-white font-medium' });
    nameTd.textContent = item.contractItemName;
    tr.appendChild(nameTd);

    // Col 2: Code
    tr.appendChild(el('td', { className: 'px-3 py-2.5 text-xs font-mono text-slate-400 whitespace-nowrap' }, item.contractItemCode));

    // Col 3: Price (readonly)
    tr.appendChild(el('td', { className: 'px-3 py-2.5 text-sm text-slate-400 text-right tabular-nums whitespace-nowrap' },
      fmtMoney(item.price) + ' ₽'));

    // Totals (will be filled after address qty inputs)
    const totalQtyTd = el('td', { className: 'px-3 py-2.5 text-sm font-semibold text-white text-right tabular-nums' });
    const totalCostTd = el('td', { className: 'px-3 py-2.5 text-sm font-medium text-cyan-400/80 text-right tabular-nums whitespace-nowrap' });

    // Col 6: Поставлено
    const deliveredTd = el('td', { className: 'px-3 py-2.5 text-sm text-right tabular-nums whitespace-nowrap' });
    const contractId = contract ? contract.id : null;
    const orderId = editingOrderId ? ((state.orders || []).find(o => o.id === editingOrderId)?.id ?? null) : null;
    const delivered = calcOrderDelivered(orderId, item.contractItemName, item.contractItemCode);
    const totalOrderedQty = addressRows.reduce((s, a) => s + (item.qtys.get(a.id) || 0), 0);
    const deliveredColor = delivered >= totalOrderedQty && totalOrderedQty > 0
      ? 'text-emerald-400 font-semibold'
      : delivered > 0 ? 'text-amber-400' : 'text-slate-500';
    deliveredTd.appendChild(el('span', { className: deliveredColor }, delivered > 0 ? String(delivered) : '—'));

    // Col 7: Собрано
    const assembledTd = el('td', { className: 'px-3 py-2.5 text-sm text-right tabular-nums whitespace-nowrap' });
    const contractItem = (contract.items || []).find(i =>
      (i.name || '').trim().toLowerCase() === (item.contractItemName || '').trim().toLowerCase()
    );
    const catalogProduct = contractItem ? resolveProductByContractItem(contractItem) : null;
    const needsAssembly = productRequiresAssembly(catalogProduct);
    if (needsAssembly) {
      const assembled = calcOrderAssembled(contractId, item.contractItemName, item.contractItemCode, catalogProduct?.id ?? null);
      const assembledColor = assembled >= totalOrderedQty && totalOrderedQty > 0
        ? 'text-emerald-400 font-semibold'
        : assembled > 0 ? 'text-amber-400' : 'text-slate-500';
      assembledTd.appendChild(el('span', { className: assembledColor }, assembled > 0 ? String(assembled) : '—'));
    } else {
      assembledTd.appendChild(el('span', { className: 'text-slate-700 text-xs' }, '—'));
    }

    // Col 8: Date (shared for all addresses of this item)
    const dateTd = el('td', { className: 'px-3 py-2' });
    const dateInput = el('input', {
      type: 'date',
      value: item.date || '',
      className: 'rounded-lg border border-white/10 bg-white/5 px-2 py-1.5 text-xs text-white focus:border-cyan-400/50 focus:outline-none',
      'aria-label': 'Срок поставки',
    });
    dateInput.addEventListener('change', () => { item.date = dateInput.value; });
    dateTd.appendChild(dateInput);

    // Now append fixed cols in order
    tr.appendChild(totalQtyTd);
    tr.appendChild(totalCostTd);
    tr.appendChild(deliveredTd);
    tr.appendChild(assembledTd);
    tr.appendChild(dateTd);

    // ── Per-address qty inputs ──
    function refreshTotals() {
      let tQty = 0;
      addressRows.forEach(a => { tQty += item.qtys.get(a.id) || 0; });
      const tCost = tQty * item.price;
      totalQtyTd.textContent = tQty > 0 ? String(tQty) : '—';
      totalCostTd.textContent = tQty > 0 ? fmtMoney(tCost) + ' ₽' : '—';
      refreshGrandTotals();
    }

    addressRows.forEach(addr => {
      const addrTd = el('td', { className: 'px-2 py-2 text-center border-l border-white/10' });
      const qtyInput = el('input', {
        type: 'number', min: '0', step: '1',
        value: String(item.qtys.get(addr.id) || 0),
        className: 'w-20 rounded-lg border border-white/10 bg-white/5 px-2 py-1.5 text-sm text-white text-right tabular-nums focus:border-cyan-400/50 focus:outline-none',
        'aria-label': `Кол-во для ${addr.recipientName || addr.address || 'адреса'}`,
      });
      qtyInput.addEventListener('input', () => {
        const v = Math.max(0, parseInt(qtyInput.value, 10) || 0);
        item.qtys.set(addr.id, v);
        refreshTotals();
        validateCurrentOrder();
      });
      addrTd.appendChild(qtyInput);
      tr.appendChild(addrTd);
    });

    refreshTotals();
    tbody.appendChild(tr);
  });

  table.appendChild(tbody);
  tableWrap.appendChild(table);
  wrap.appendChild(tableWrap);

  // Grand totals footer
  function refreshGrandTotals() {
    let gQty = 0, gCost = 0;
    itemRows.forEach(item => {
      addressRows.forEach(a => {
        const q = item.qtys.get(a.id) || 0;
        gQty += q;
        gCost += q * item.price;
      });
    });
    const tc = document.getElementById('orderTableTotalCost');
    if (tc) tc.textContent = fmtMoney(gCost) + ' ₽';
    const tq = document.getElementById('orderTableTotalQty');
    if (tq) tq.textContent = String(gQty) + ' шт.';
  }

  // Tfoot
  const tfoot = el('tfoot', { className: 'border-t border-white/10 bg-slate-900' });
  const tfRow = el('tr', {});
  tfRow.appendChild(el('td', { colspan: '4', className: 'px-3 py-3 text-xs font-semibold uppercase tracking-wider text-slate-400 text-right' }, 'ИТОГО:'));
  const tqTd = el('td', { id: 'orderTableTotalQty', className: 'px-3 py-3 text-sm font-bold text-white tabular-nums text-right' });
  tfRow.appendChild(tqTd);
  const tcTd = el('td', { id: 'orderTableTotalCost', colspan: String(3 + addressRows.length), className: 'px-3 py-3 text-base font-bold text-cyan-400 tabular-nums text-right whitespace-nowrap' });
  tfRow.appendChild(tcTd);
  tfoot.appendChild(tfRow);
  table.appendChild(tfoot);

  refreshGrandTotals();
  makeColumnsResizable(table, 'orders-items');
  requestAnimationFrame(() => attachFrozenManager(table, 'orders-items'));
}

// ─── Validation ──────────────────────────────────────────────────

function validateCurrentOrder() {
  const container = $('orderValidationWarnings');
  if (!container) return;
  clearChildren(container);

  const contractSel = $('orderContractSel');
  const contractId = contractSel ? Number(contractSel.value) : null;
  if (!contractId) return;

  const contract = (state.contracts || []).find(c => c.id === contractId);
  if (!contract) return;

  const contractTotalPrice = Number(contract.totalPrice) || 0;
  let currentOrderTotal = 0;
  const currentOrderItemQty = new Map();

  itemRows.forEach(item => {
    const qty = addressRows.reduce((s, a) => s + (item.qtys.get(a.id) || 0), 0);
    const key = (item.contractItemName || '').trim().toLowerCase();
    if (key) currentOrderItemQty.set(key, (currentOrderItemQty.get(key) || 0) + qty);
    currentOrderTotal += qty * item.price;
  });

  const otherOrdersItemQty = new Map();
  let otherOrdersTotal = 0;

  (state.orders || [])
    .filter(o => o.contractId === contractId && o.id !== editingOrderId)
    .forEach(order => {
      (Array.isArray(order.deliveryRows) ? order.deliveryRows : []).forEach(r => {
        const qty = Number(r.qty) || 0;
        otherOrdersTotal += qty * (Number(r.price) || 0);
        const key = (r.contractItemName || '').trim().toLowerCase();
        if (key) otherOrdersItemQty.set(key, (otherOrdersItemQty.get(key) || 0) + qty);
      });
    });

  const overages = { qty: [], total: 0 };

  currentOrderItemQty.forEach((currentQty, itemKey) => {
    const ci = contract.items.find(i => (i.name || '').trim().toLowerCase() === itemKey);
    if (!ci) return;
    const contractQty = Number(ci.qty) || 0;
    const alreadyOrdered = otherOrdersItemQty.get(itemKey) || 0;
    const remaining = contractQty - alreadyOrdered;
    if (contractQty > 0 && currentQty > remaining) {
      overages.qty.push({ name: ci.name, current: currentQty, remaining });
    }
  });

  if (contractTotalPrice > 0) {
    const newTotal = otherOrdersTotal + currentOrderTotal;
    if (newTotal > contractTotalPrice) overages.total = newTotal - contractTotalPrice;
  }

  const hasOverage = overages.qty.length > 0 || overages.total > 0;
  if (!hasOverage) return;

  const panel = el('div', { className: 'rounded-xl border border-amber-400/25 bg-amber-400/[0.06] p-4' });
  panel.appendChild(el('p', { className: 'text-xs font-bold text-amber-400 mb-3' }, '⚠️ Превышение лимитов контракта'));
  const list = el('ul', { className: 'space-y-2' });
  overages.qty.forEach(o => {
    list.appendChild(el('li', { className: 'text-xs text-amber-300/90' },
      `▸ ${o.name}: заявлено ${o.current}, доступно ${o.remaining}`));
  });
  if (overages.total > 0) {
    list.appendChild(el('li', { className: 'text-xs text-amber-300/90' },
      `▸ Сумма заказов превышает цену контракта на ${fmtMoney(overages.total)} ₽`));
  }
  panel.appendChild(list);
  container.appendChild(panel);
}

// ─── Save ────────────────────────────────────────────────────────

function syncOrderedToContract(contractId) {
  const contract = (state.contracts || []).find(c => c.id === contractId);
  if (!contract || !Array.isArray(contract.items)) return;
  const orderedMap = new Map();
  (state.orders || [])
    .filter(o => o.contractId === contractId)
    .forEach(order => {
      (Array.isArray(order.deliveryRows) ? order.deliveryRows : []).forEach(r => {
        const key = (r.contractItemName || '').trim().toLowerCase();
        if (!key) return;
        orderedMap.set(key, (orderedMap.get(key) || 0) + (Number(r.qty) || 0));
      });
    });
  contract.items.forEach(item => {
    const key = (item.name || '').trim().toLowerCase();
    item.ordered = orderedMap.get(key) || 0;
  });
}

function saveOrderCard() {
  const contractSel = $('orderContractSel');
  const programSel  = $('orderProgramSel');
  const numDisplay  = $('orderNumberDisplay');
  const warehouseSelEl = document.getElementById('orderWarehouseSel');
  const sentCheck   = document.getElementById('orderSentCheck');
  const sentDateInp = document.getElementById('orderSentDate');

  if (!contractSel || !contractSel.value) {
    showToast(t('orders.contractRequired'), 'error');
    return;
  }
  if (!programSel || !programSel.value) {
    showToast('Выберите целевую программу', 'error');
    programSel?.focus();
    return;
  }

  const contractId = Number(contractSel.value);
  const contractCheck = (state.contracts || []).find(c => c.id === contractId);
  if (contractCheck && Number(contractCheck.totalPrice) > 0) {
    const moneyLimit = getContractMoneyLimit(contractId);
    const currentTotal = itemRows.reduce((s, item) => {
      const qty = addressRows.reduce((qs, a) => qs + (item.qtys.get(a.id) || 0), 0);
      return s + qty * item.price;
    }, 0);
    if (currentTotal > moneyLimit) {
      showToast(`Сумма заявки ${fmtMoney(currentTotal)} ₽ превышает остаток по контракту ${fmtMoney(moneyLimit)} ₽`, 'error');
      validateCurrentOrder();
      return;
    }
  }

  validateCurrentOrder();
  const warnContainer = $('orderValidationWarnings');
  if (warnContainer && warnContainer.children.length > 0) {
    const proceed = confirm('⚠️ Обнаружено превышение количества по некоторым позициям.\n\nСохранить заявку несмотря на превышение?');
    if (!proceed) return;
  }

  const programCode     = programSel ? programSel.value : '';
  const contract        = (state.contracts || []).find(c => c.id === contractId);
  const warehouseId     = warehouseSelEl && warehouseSelEl.value ? Number(warehouseSelEl.value) : null;
  const sentStatus      = sentCheck ? sentCheck.checked : false;
  const sentDateVal     = sentDateInp ? sentDateInp.value : '';
  const rowsToSave      = buildDeliveryRowsForSave();

  // deliveryAddress — first address for backward compat
  const deliveryAddress = addressRows.length > 0 ? addressRows[0].address : '';

  if (editingOrderId !== null) {
    const order = (state.orders || []).find(o => o.id === editingOrderId);
    if (order) {
      const programChanged = order.programCode !== programCode;
      let finalOrderNumber;
      if (order.orderNumber && !programChanged) {
        finalOrderNumber = order.orderNumber;
      } else if (order.orderNumber && programChanged) {
        finalOrderNumber = generateOrderNumber(contract, order.seqNum || 1, programCode);
      } else {
        const seqNum = order.seqNum || getNextOrderSeq(contractId);
        finalOrderNumber = generateOrderNumber(contract, seqNum, programCode);
      }
      updateOrder(editingOrderId, {
        contractId, programCode, deliveryAddress, warehouseId,
        orderNumber: finalOrderNumber,
        seqNum: order.seqNum || 1,
        deliveryRows: rowsToSave,
        sent: sentStatus, sentDate: sentDateVal,
        items: [],
      });
      showToast(t('orders.saved'), 'success');
    }
  } else {
    const seq = getNextOrderSeq(contractId);
    const orderNumber = generateOrderNumber(contract, seq, programCode);
    addOrder({
      contractId, programCode, deliveryAddress, warehouseId,
      orderNumber, seqNum: seq,
      deliveryRows: rowsToSave,
      sent: sentStatus, sentDate: sentDateVal,
      items: [],
    });
    showToast(t('orders.saved'), 'success');
  }

  syncOrderedToContract(contractId);
  refreshContractItemsOrdered(contractId);
  saveToStorage();
  updateOrdersBadge();
  closeOrderCard();
  renderRegistryList();
}

// ─── Excel Export ─────────────────────────────────────────────────

function exportOrderToExcel() {
  const XLSX = window.XLSX;
  if (!XLSX) { showToast('Библиотека Excel не загружена', 'error'); return; }

  const contractSel = $('orderContractSel');
  const programSel  = $('orderProgramSel');
  const numDisplay  = $('orderNumberDisplay');

  const contractId  = contractSel ? Number(contractSel.value) : null;
  const contract    = contractId ? (state.contracts || []).find(c => c.id === contractId) : null;
  const supplier    = contract?.supplierId
    ? (state.suppliers || []).find(s => s.id === contract.supplierId)
    : null;
  const orderNumber     = numDisplay?.textContent || '—';
  const programCode     = programSel?.value || '';

  const wb = XLSX.utils.book_new();

  const headerRows = [
    ['Заявка на поставку'],
    [],
    ['Номер заявки', orderNumber],
    ['Контракт', contract ? (contract.number ? `№ ${contract.number}` : contract.title || '—') : '—'],
    ['Поставщик', supplier ? supplier.name : '—'],
    ['Целевая программа', programCode || '—'],
    ['Дата формирования', new Date().toLocaleDateString('ru-RU')],
    [],
  ];

  // Build address list
  if (addressRows.length > 0) {
    headerRows.push(['Адреса поставки:']);
    addressRows.forEach((a, i) => {
      headerRows.push([`${i + 1}.`, a.recipientName || '', a.address || '']);
    });
    headerRows.push([]);
  }

  // Table header: №, Name, Code, Price, Total qty, Total cost, Date, then per-address qty
  const colHeader = ['№', 'Наименование', 'Код товара', 'Цена, ₽', 'Итого шт.', 'Итого ₽', 'Срок поставки'];
  addressRows.forEach((a, i) => {
    colHeader.push(a.recipientName || a.address || `Адрес ${i + 1}`);
  });
  headerRows.push(colHeader);

  const dataRows = [];
  let grandTotal = 0;
  let grandQty = 0;

  itemRows.forEach((item, idx) => {
    const totalQty = addressRows.reduce((s, a) => s + (item.qtys.get(a.id) || 0), 0);
    const totalCost = totalQty * item.price;
    grandTotal += totalCost;
    grandQty += totalQty;

    const row = [
      idx + 1,
      item.contractItemName,
      item.contractItemCode,
      item.price,
      totalQty,
      totalCost,
      item.date ? fmtDate(item.date) : '—',
    ];
    addressRows.forEach(a => { row.push(item.qtys.get(a.id) || 0); });
    dataRows.push(row);
  });

  dataRows.push([]);
  const totalRow = ['', '', '', '', grandQty, grandTotal, ''];
  addressRows.forEach(() => totalRow.push(''));
  totalRow[3] = 'ИТОГО:';
  dataRows.push(totalRow);

  const ws = XLSX.utils.aoa_to_sheet([...headerRows, ...dataRows]);
  const baseCols = [
    { wch: 4 }, { wch: 44 }, { wch: 14 }, { wch: 14 }, { wch: 12 }, { wch: 18 }, { wch: 16 },
  ];
  addressRows.forEach(() => baseCols.push({ wch: 12 }));
  ws['!cols'] = baseCols;

  XLSX.utils.book_append_sheet(wb, ws, 'Заявка');
  const safeNum = orderNumber.replace(/[/\\?%*:|"<>]/g, '-');
  XLSX.writeFile(wb, `Заявка_${safeNum}.xlsx`);
  showToast('Файл скачан: Заявка_' + safeNum + '.xlsx', 'success');
}

// ─── Modal open/close ─────────────────────────────────────────────

export function openOrdersModal() {
  const overlay = $('ordersModal');
  if (!overlay) return;
  overlay.classList.add('open');
  registrySearchQuery = '';
  const searchInput = document.getElementById('ordersSearchInput');
  if (searchInput) searchInput.value = '';
  renderRegistryList();
  updateOrdersBadge();
}

export function closeOrdersModal() {
  const overlay = $('ordersModal');
  if (overlay) overlay.classList.remove('open');
}

// ─── Init ─────────────────────────────────────────────────────────

export function initOrdersView() {
  const overlay = $('ordersModal');
  if (overlay) {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) closeOrdersModal();
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && overlay.classList.contains('open')) {
        const cardPanel = $('orderCardPanel');
        if (cardPanel && !cardPanel.classList.contains('hidden')) {
          closeOrderCard();
        } else {
          closeOrdersModal();
        }
      }
    });
  }

  const closeBtn = $('ordersCloseBtn');
  if (closeBtn) closeBtn.addEventListener('click', closeOrdersModal);

  const addBtn = $('addOrderBtn');
  if (addBtn) addBtn.addEventListener('click', () => openOrderCard(null));

  const cardBackBtn = $('orderCardBackBtn');
  if (cardBackBtn) cardBackBtn.addEventListener('click', closeOrderCard);

  const exportBtn = $('orderExportBtn');
  if (exportBtn) exportBtn.addEventListener('click', exportOrderToExcel);

  const cardSaveBtn = $('orderCardSaveBtn');
  if (cardSaveBtn) cardSaveBtn.addEventListener('click', saveOrderCard);

  const cardEditBtn = $('orderCardEditBtn');
  if (cardEditBtn) cardEditBtn.addEventListener('click', () => setOrderCardReadonly(false));

  const searchInput = document.getElementById('ordersSearchInput');
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      registrySearchQuery = searchInput.value;
      renderRegistryList();
    });
  }
}
