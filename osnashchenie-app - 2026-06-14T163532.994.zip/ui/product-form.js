/**
 * Product add/edit form modal.
 * Specs are structured as { param, unit, value }[] — three fields per row.
 * Category and productGroup are required fields.
 */

import { $, el, clearChildren, qs } from './dom.js';
import { addProduct, updateProduct, generateNumber, getCategories, addCategory, normalizeSpecs, getProductGroups } from '../state.js';
import { saveToStorage } from '../storage.js';
import { showToast } from './toast.js';
import { openSpecsImportModal } from './specs-import.js';
import { refreshProductGroupDatalist } from './product-groups.js';

const t = (key, vals) => window.miniappI18n?.t(key, vals) ?? key;

let currentProduct = null;
let onSaveCallback = null;

/** Current specs list: { param, unit, value }[] */
let _specs = [];

// ─── Category select ──────────────────────────────────────────────

function populateCategorySelect(selectedValue = '') {
  const sel = $('fieldCategory');
  if (!sel) return;
  clearChildren(sel);
  sel.appendChild(el('option', { value: '' }, t('form.selectCategory')));
  getCategories().forEach(cat => {
    sel.appendChild(el('option', { value: cat }, cat));
  });
  sel.appendChild(el('option', { value: '__add_new__' }, t('form.addCategory')));
  if (selectedValue) sel.value = selectedValue;
}

// ─── Specs list ───────────────────────────────────────────────────

/** Render the three-column specs list */
function renderSpecsList() {
  const container = $('specsListWrap');
  if (!container) return;
  clearChildren(container);

  if (_specs.length > 0) {
    const header = el('div', {
      className: 'grid gap-2 mb-1',
      style: 'grid-template-columns: 1fr 90px 1fr 32px',
    });
    header.appendChild(el('span', { className: 'text-[10px] font-semibold uppercase tracking-wider text-slate-500 px-1' }, t('form.specParam')));
    header.appendChild(el('span', { className: 'text-[10px] font-semibold uppercase tracking-wider text-slate-500 px-1' }, t('form.specUnit')));
    header.appendChild(el('span', { className: 'text-[10px] font-semibold uppercase tracking-wider text-slate-500 px-1' }, t('form.specValue')));
    header.appendChild(el('span', {}));
    container.appendChild(header);
  }

  _specs.forEach((spec, idx) => {
    const row = el('div', {
      className: 'grid gap-2 items-center',
      style: 'grid-template-columns: 1fr 90px 1fr 32px',
      'data-spec-row': String(idx),
    });

    const inputCls = 'w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]';

    const paramInput = el('input', {
      type: 'text',
      className: inputCls,
      placeholder: t('form.specParamPlaceholder'),
      value: spec.param,
      'aria-label': t('form.specParam'),
      'data-spec-field': 'param',
    });
    paramInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addSpecRow(); } });

    const unitInput = el('input', {
      type: 'text',
      className: inputCls,
      placeholder: t('form.specUnitPlaceholder'),
      value: spec.unit,
      'aria-label': t('form.specUnit'),
      'data-spec-field': 'unit',
    });
    unitInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addSpecRow(); } });

    const valueInput = el('input', {
      type: 'text',
      className: inputCls,
      placeholder: t('form.specValuePlaceholder'),
      value: spec.value,
      'aria-label': t('form.specValue'),
      'data-spec-field': 'value',
    });
    valueInput.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addSpecRow(); } });

    const delBtn = el('button', {
      type: 'button',
      className: 'shrink-0 w-8 h-8 flex items-center justify-center rounded-xl text-slate-500 hover:text-red-400 hover:bg-red-400/10 transition',
      'aria-label': t('actions.delete'),
    }, '✕');
    delBtn.addEventListener('click', () => {
      _specs = collectSpecsFromDOM();
      _specs.splice(idx, 1);
      renderSpecsList();
    });

    row.append(paramInput, unitInput, valueInput, delBtn);
    container.appendChild(row);
  });

  if (_specs.length > 0) {
    requestAnimationFrame(() => {
      const allInputs = container.querySelectorAll('input');
      if (allInputs.length) allInputs[allInputs.length - 3]?.focus();
    });
  }
}

function addSpecRow() {
  _specs = collectSpecsFromDOM();
  _specs.push({ param: '', unit: '', value: '' });
  renderSpecsList();
}

function collectSpecsFromDOM() {
  const container = document.getElementById('specsListWrap');
  if (!container) return [..._specs];
  const rows = container.querySelectorAll('[data-spec-row]');
  const result = [];
  rows.forEach(row => {
    const inputs = row.querySelectorAll('input[data-spec-field]');
    const obj = { param: '', unit: '', value: '' };
    inputs.forEach(inp => { obj[inp.dataset.specField] = inp.value; });
    result.push(obj);
  });
  return result;
}

// ─── Field error highlight ────────────────────────────────────────

function setFieldError(fieldId, hasError) {
  const el = $(fieldId);
  if (!el) return;
  if (hasError) {
    el.classList.add('border-red-500/70');
    el.classList.remove('border-white/10');
  } else {
    el.classList.remove('border-red-500/70');
    el.classList.add('border-white/10');
  }
}

// ─── Open / Close ─────────────────────────────────────────────────

export function openProductForm(product = null, onSave = null) {
  currentProduct = product;
  onSaveCallback = onSave;

  const overlay = $('formModal');
  if (!overlay) return;

  const isEdit = !!product;
  const titleEl = qs('[data-form-title]', overlay);
  if (titleEl) titleEl.textContent = isEdit ? t('form.editTitle') : t('form.addTitle');

  const numberInput = $('fieldNumber');
  const nameInput   = $('fieldName');
  const colorInput  = $('fieldColor');

  if (numberInput) {
    numberInput.value = isEdit ? product.number : generateNumber();
    numberInput.readOnly = true;
    numberInput.classList.add('opacity-60', 'cursor-not-allowed');
  }
  if (nameInput)  nameInput.value  = product?.name  || '';
  if (colorInput) colorInput.value = product?.color || '';

  // Assembly field
  const assemblyVal     = product?.assembly ?? 'not_required';
  const radioRequired    = $('fieldAssemblyRequired');
  const radioNotRequired = $('fieldAssemblyNotRequired');
  if (radioRequired)    radioRequired.checked    = (assemblyVal === 'required');
  if (radioNotRequired) radioNotRequired.checked = (assemblyVal !== 'required');

  // Product group field
  const pgInput = $('fieldProductGroup');
  if (pgInput) pgInput.value = product?.productGroup || '';
  refreshProductGroupDatalist();

  // Clear previous validation errors
  setFieldError('fieldCategory', false);
  setFieldError('fieldProductGroup', false);

  // Populate specs
  _specs = normalizeSpecs(product || {});
  if (_specs.length === 0) _specs = [{ param: '', unit: '', value: '' }];
  renderSpecsList();

  populateCategorySelect(product?.category || '');

  const newCatWrap  = $('newCategoryWrap');
  if (newCatWrap)  newCatWrap.classList.add('hidden');
  const newCatInput = $('newCategoryInput');
  if (newCatInput) newCatInput.value = '';

  overlay.classList.add('open');
  setTimeout(() => nameInput?.focus(), 100);
}

export function closeProductForm() {
  const overlay = $('formModal');
  if (overlay) overlay.classList.remove('open');
  currentProduct = null;
  _specs = [];

  const numberInput = $('fieldNumber');
  if (numberInput) {
    numberInput.readOnly = false;
    numberInput.classList.remove('opacity-60', 'cursor-not-allowed');
  }
}

// ─── Category handlers ────────────────────────────────────────────

function handleCategoryChange() {
  const sel  = $('fieldCategory');
  const wrap = $('newCategoryWrap');
  if (!sel || !wrap) return;
  if (sel.value === '__add_new__') {
    wrap.classList.remove('hidden');
    setTimeout(() => $('newCategoryInput')?.focus(), 50);
  } else {
    wrap.classList.add('hidden');
    setFieldError('fieldCategory', false);
  }
}

async function handleInlineAddCategory() {
  const input = $('newCategoryInput');
  if (!input) return;
  const name = input.value.trim();
  if (!name) return;
  if (addCategory(name)) {
    await saveToStorage();
    populateCategorySelect(name);
    $('newCategoryWrap')?.classList.add('hidden');
    input.value = '';
    showToast(t('toast.categoryAdded'), 'success');
    setFieldError('fieldCategory', false);
  }
}

// ─── Save ─────────────────────────────────────────────────────────

export async function handleFormSubmit() {
  const nameInput      = $('fieldName');
  const categorySelect = $('fieldCategory');
  const colorInput     = $('fieldColor');
  const pgInput        = $('fieldProductGroup');

  const name = (nameInput?.value || '').trim();
  if (!name) {
    nameInput?.focus();
    showToast(t('form.required'), 'warning');
    return;
  }

  let category = categorySelect?.value || '';
  if (category === '__add_new__') category = '';

  // Validate required: category
  if (!category) {
    setFieldError('fieldCategory', true);
    categorySelect?.focus();
    showToast(t('form.categoryRequired'), 'warning');
    return;
  }
  setFieldError('fieldCategory', false);

  // Validate required: productGroup
  const productGroup = (pgInput?.value || '').trim();
  if (!productGroup) {
    setFieldError('fieldProductGroup', true);
    pgInput?.focus();
    showToast(t('form.productGroupRequired'), 'warning');
    return;
  }
  setFieldError('fieldProductGroup', false);

  // Collect specs
  const specs = collectSpecsFromDOM().filter(s => s.param.trim() || s.unit.trim() || s.value.trim());

  const data = {
    name,
    category,
    color: (colorInput?.value || '').trim(),
    productGroup,
    specs,
  };

  const radioReq = $('fieldAssemblyRequired');
  data.assembly = (radioReq && radioReq.checked) ? 'required' : 'not_required';

  if (currentProduct) {
    data.number = currentProduct.number;
    updateProduct(currentProduct.id, data);
  } else {
    addProduct(data);
  }

  showToast(t('toast.saved'), 'success');
  await saveToStorage();
  closeProductForm();
  if (onSaveCallback) onSaveCallback();
}

// ─── Init ─────────────────────────────────────────────────────────

export function initProductForm() {
  const overlay = $('formModal');
  if (!overlay) return;

  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeProductForm();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && overlay.classList.contains('open')) closeProductForm();
  });

  $('formCancelBtn')?.addEventListener('click', closeProductForm);
  $('formSaveBtn')?.addEventListener('click', handleFormSubmit);

  $('fieldCategory')?.addEventListener('change', handleCategoryChange);
  $('addCategoryInlineBtn')?.addEventListener('click', handleInlineAddCategory);
  $('newCategoryInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); handleInlineAddCategory(); }
  });

  // Clear productGroup error on input
  $('fieldProductGroup')?.addEventListener('input', () => setFieldError('fieldProductGroup', false));

  $('addSpecBtn')?.addEventListener('click', addSpecRow);

  $('importSpecsBtn')?.addEventListener('click', () => {
    openSpecsImportModal(importedSpecs => {
      const nonEmpty = _specs.filter(s => s.param.trim() || s.unit.trim() || s.value.trim());
      _specs = [...nonEmpty, ...importedSpecs];
      if (_specs.length === 0) _specs = [{ param: '', unit: '', value: '' }];
      renderSpecsList();
    });
  });
}
