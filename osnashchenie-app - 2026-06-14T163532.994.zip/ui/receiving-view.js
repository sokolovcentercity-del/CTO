/**
 * Receiving View — модуль «Приёмка».
 * Список контрактов (синхр. с модулем Контракты).
 * В каждом контракте — список товаров с полями приёмки + вкладка реестра актов.
 *
 * Структура item в контракте:
 *   item.name       — наименование (введено вручную или выбрано из каталога)
 *   item.productRef — id товара из каталога (только если выбран через автодополнение)
 *   item.price, item.qty — цена и количество
 *   item.receiving  — объект с данными приёмки
 */

import { state } from '../state.js';
import { saveToStorage } from '../storage.js';
import { showToast } from './toast.js';
import { openActForm } from './act-form-view.js';
import { addCommissionMember, updateCommissionMember, removeCommissionMember } from '../state.js';
import { openActsRegistryInReceiving } from './acts-registry-view.js';
import { updateActsBadge } from './acts-registry-view.js';


const t = (key, vals) => window.miniappI18n?.t(key, vals) ?? key;

// ─── Open / Close ─────────────────────────────────────────────────

// Active tab: 'receiving' | 'acts'
let _activeTab = 'receiving';

export function openReceivingModal() {
  const overlay = document.getElementById('receivingModal');
  if (!overlay) return;
  overlay.classList.add('open');
  _activeTab = 'receiving';
  renderListView();
  renderCommissionBlock();
  updateCommissionBadge();
  updateActsBadge();
}

export function closeReceivingModal() {
  const overlay = document.getElementById('receivingModal');
  if (overlay) overlay.classList.remove('open');
}

export function initReceivingView() {
  const overlay = document.getElementById('receivingModal');
  if (!overlay) return;

  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeReceivingModal();
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && overlay.classList.contains('open')) {
      const cardPanel = document.getElementById('receivingCardPanel');
      if (cardPanel && !cardPanel.classList.contains('hidden')) {
        closeContractCard();
      } else {
        closeReceivingModal();
      }
    }
  });

  const closeBtn = document.getElementById('receivingCloseBtn');
  if (closeBtn) closeBtn.addEventListener('click', closeReceivingModal);

  const backBtn = document.getElementById('receivingCardBackBtn');
  if (backBtn) backBtn.addEventListener('click', closeContractCard);

  const generateActBtn = document.getElementById('generateActBtn');
  if (generateActBtn) {
    generateActBtn.addEventListener('click', () => {
      openActForm(_currentContractId, 'delivery');
    });
  }

  // Tab buttons
  document.getElementById('receivingTabReceiving')?.addEventListener('click', () => {
    _activeTab = 'receiving';
    renderListView();
  });
  document.getElementById('receivingTabActs')?.addEventListener('click', () => {
    _activeTab = 'acts';
    renderListView();
  });

  // Commission block init
  renderCommissionBlock();
  updateCommissionBadge();

  // Toggle commission panel
  const toggleBtn = document.getElementById('commissionToggleBtn');
  const panelWrap = document.getElementById('commissionPanelWrap');
  const toggleIcon = document.getElementById('commissionToggleIcon');
  if (toggleBtn && panelWrap) {
    toggleBtn.addEventListener('click', () => {
      const isOpen = !panelWrap.classList.contains('hidden');
      panelWrap.classList.toggle('hidden', isOpen);
      if (toggleIcon) toggleIcon.textContent = isOpen ? '▼' : '▲';
    });
  }
}

// ─── List panel ───────────────────────────────────────────────────

function renderListView() {
  _renderTabBar();
  // Show/hide commission block depending on active tab
  const commToggle = document.getElementById('commissionToggleBtn');
  if (commToggle) {
    const commBlock = commToggle.closest('.mb-4') || commToggle.parentElement;
    if (commBlock) commBlock.style.display = _activeTab === 'acts' ? 'none' : '';
  }

  if (_activeTab === 'acts') {
    _renderActsTab();
  } else {
    renderReceivingButtons();
  }
}

function _renderTabBar() {
  const tabBar = document.getElementById('receivingTabBar');
  if (!tabBar) return;
  const isReceiving = _activeTab === 'receiving';
  const activeCls = 'bg-cyan-400/20 text-white border-b-2 border-cyan-400';
  const inactiveCls = 'text-slate-400 hover:text-slate-200';
  const rBtn = document.getElementById('receivingTabReceiving');
  const aBtn = document.getElementById('receivingTabActs');
  if (rBtn) {
    rBtn.className = `flex-1 py-2.5 text-sm font-semibold transition rounded-tl-xl ${isReceiving ? activeCls : inactiveCls}`;
    rBtn.setAttribute('aria-selected', String(isReceiving));
  }
  if (aBtn) {
    aBtn.className = `flex-1 py-2.5 text-sm font-semibold transition rounded-tr-xl ${!isReceiving ? activeCls : inactiveCls}`;
    aBtn.setAttribute('aria-selected', String(!isReceiving));
  }
}

function _renderActsTab() {
  const wrap = document.getElementById('receivingListContainer');
  if (!wrap) return;
  wrap.innerHTML = '';
  openActsRegistryInReceiving(wrap);
}

function renderReceivingButtons() {
  const wrap = document.getElementById('receivingListContainer');
  if (!wrap) return;

  wrap.innerHTML = `
    <div class="space-y-3 py-2">
      <button id="btnCheckSO" type="button"
        class="w-full group flex items-start gap-4 rounded-2xl border border-white/10 bg-white/5 p-5 text-left
          transition hover:bg-white/[0.09] hover:border-cyan-400/30 active:scale-[0.98]">
        <span class="text-3xl mt-0.5" aria-hidden="true">🔬</span>
        <div class="flex-1 min-w-0">
          <p class="text-sm font-semibold text-white">Проверка сигнальных образцов</p>
          <p class="text-xs text-slate-500 mt-1">Акт проверки соответствия характеристик образцов условиям договора</p>
        </div>
        <svg class="mt-1 shrink-0 text-slate-500 group-hover:text-cyan-400 transition" width="18" height="18"
          viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2"
          stroke-linecap="round" stroke-linejoin="round"><path d="M7 10h6M13 7l3 3-3 3"/></svg>
      </button>

      <button id="btnCheckDelivery" type="button"
        class="w-full group flex items-start gap-4 rounded-2xl border border-white/10 bg-white/5 p-5 text-left
          transition hover:bg-white/[0.09] hover:border-cyan-400/30 active:scale-[0.98]">
        <span class="text-3xl mt-0.5" aria-hidden="true">📦</span>
        <div class="flex-1 min-w-0">
          <p class="text-sm font-semibold text-white">Проверка поставленного товара</p>
          <p class="text-xs text-slate-500 mt-1">Акт проверки поставленного товара с указанием фактического количества</p>
        </div>
        <svg class="mt-1 shrink-0 text-slate-500 group-hover:text-cyan-400 transition" width="18" height="18"
          viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2"
          stroke-linecap="round" stroke-linejoin="round"><path d="M7 10h6M13 7l3 3-3 3"/></svg>
      </button>
    </div>`;

  document.getElementById('btnCheckSO')?.addEventListener('click', () => {
    openActForm(null, 'so');
  });
  document.getElementById('btnCheckDelivery')?.addEventListener('click', () => {
    openActForm(null, 'delivery');
  });
}

// ─── Contract card (full-screen) ──────────────────────────────────

let _currentContractId = null;

function openContractCard(contractId) {
  _currentContractId = contractId;
  const listPanel = document.getElementById('receivingListPanel');
  const cardPanel = document.getElementById('receivingCardPanel');
  if (listPanel) listPanel.classList.add('hidden');
  if (cardPanel) cardPanel.classList.remove('hidden');
  renderContractCard(contractId);
}

function closeContractCard() {
  _currentContractId = null;
  const listPanel = document.getElementById('receivingListPanel');
  const cardPanel = document.getElementById('receivingCardPanel');
  if (cardPanel) cardPanel.classList.add('hidden');
  if (listPanel) listPanel.classList.remove('hidden');
  renderReceivingButtons();
}

function renderContractCard(contractId) {
  const contract = state.contracts.find(c => c.id === contractId);
  if (!contract) return;

  const titleEl = document.getElementById('receivingCardTitle');
  if (titleEl) titleEl.textContent = contract.number || t('contracts.noNumber');

  const wrap = document.getElementById('receivingCardWrap');
  if (!wrap) return;

  // Only show rows that have a name (skip empty placeholder rows)
  const items = (contract.items || []).filter(i => i.name && i.name.trim());

  if (items.length === 0) {
    wrap.innerHTML = `<p class="text-sm text-slate-400 py-8 text-center">${t('receiving.noItems')}</p>`;
    return;
  }

  // Recipient options for datalist
  const recipientOptions = (state.recipients || [])
    .map(r => `<option value="${escHtml(r.name)}" data-id="${r.id}">`)
    .join('');

  wrap.innerHTML = `
    <datalist id="receivingRecipientList">${recipientOptions}</datalist>
    <div class="space-y-4">
      ${items.map((item, idx) => renderItemCard(contract, item, idx)).join('')}
    </div>
  `;

  // Wire save buttons
  items.forEach((item, idx) => {
    wireItemCard(wrap, contract, item, idx);
  });
}

// ─── Build product info from item ─────────────────────────────────

function resolveProduct(item) {
  // productRef is set only when user picks from autocomplete in contracts view
  if (item.productRef != null) {
    const p = state.products.find(p => p.id === item.productRef);
    if (p) return p;
  }
  return null;
}

/**
 * Get the item code directly from item.code (set by contracts-view when
 * product is selected via autocomplete). Falls back to empty string.
 */
function getItemCode(item) {
  return (item.code || '').trim();
}

// ─── Item card HTML ───────────────────────────────────────────────

function renderItemCard(contract, item, idx) {
  const product = resolveProduct(item);
  // Name: prefer catalog name, then manually entered name
  const productName = product ? product.name : (item.name || t('receiving.unknownProduct'));
  // Code comes directly from item.code (set and persisted by contracts-view)
  const code = getItemCode(item);

  const r = item.receiving || {};

  // Recipient display name
  const recipientName = r.recipientId
    ? (state.recipients.find(rec => rec.id === r.recipientId)?.name || r.recipientName || '')
    : (r.recipientName || '');

  return `
    <div class="rounded-2xl border border-white/10 bg-white/5 p-5" data-item-idx="${idx}">
      <!-- Product header -->
      <div class="flex items-start gap-3 mb-4">
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-2 flex-wrap">
            ${code ? `<span class="font-mono text-xs text-cyan-400/80 bg-cyan-400/10 rounded px-1.5 py-0.5">${escHtml(code)}</span>` : ''}
            <span class="text-sm font-semibold text-white">${escHtml(productName)}</span>
          </div>
          <div class="flex gap-4 mt-1 text-xs text-slate-500">
            ${item.qty ? `<span>${t('receiving.qty')}: <b class="text-slate-300">${item.qty}</b></span>` : ''}
            ${item.price ? `<span>${t('receiving.price')}: <b class="text-slate-300">${fmtNum(item.price)} ₽</b></span>` : ''}
          </div>
        </div>
      </div>

      <!-- Receiving fields grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">

        <!-- СО Deadline -->
        <div>
          <label class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400"
            for="soDeadline_${idx}">${t('receiving.soDeadline')}</label>
          <input id="soDeadline_${idx}" type="date"
            class="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
            value="${escHtml(r.soDeadline || '')}"
            data-field="soDeadline" data-idx="${idx}">
        </div>

        <!-- СО Result -->
        <div>
          <label class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400"
            for="soResult_${idx}">${t('receiving.soResult')}</label>
          <select id="soResult_${idx}"
            class="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-300 transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
            data-field="soResult" data-idx="${idx}">
            <option value="" ${!r.soResult ? 'selected' : ''}>${t('receiving.resultNone')}</option>
            <option value="passed" ${r.soResult === 'passed' ? 'selected' : ''}>${t('receiving.resultPassed')}</option>
            <option value="failed" ${r.soResult === 'failed' ? 'selected' : ''}>${t('receiving.resultFailed')}</option>
            <option value="partial" ${r.soResult === 'partial' ? 'selected' : ''}>${t('receiving.resultPartial')}</option>
          </select>
        </div>

        <!-- Warehouse Deadline -->
        <div>
          <label class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400"
            for="warehouseDeadline_${idx}">${t('receiving.warehouseDeadline')}</label>
          <input id="warehouseDeadline_${idx}" type="date"
            class="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
            value="${escHtml(r.warehouseDeadline || '')}"
            data-field="warehouseDeadline" data-idx="${idx}">
        </div>

        <!-- Warehouse Result -->
        <div>
          <label class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400"
            for="warehouseResult_${idx}">${t('receiving.warehouseResult')}</label>
          <select id="warehouseResult_${idx}"
            class="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-300 transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
            data-field="warehouseResult" data-idx="${idx}">
            <option value="" ${!r.warehouseResult ? 'selected' : ''}>${t('receiving.resultNone')}</option>
            <option value="passed" ${r.warehouseResult === 'passed' ? 'selected' : ''}>${t('receiving.resultPassed')}</option>
            <option value="failed" ${r.warehouseResult === 'failed' ? 'selected' : ''}>${t('receiving.resultFailed')}</option>
            <option value="partial" ${r.warehouseResult === 'partial' ? 'selected' : ''}>${t('receiving.resultPartial')}</option>
          </select>
        </div>

        <!-- Recipient (autocomplete from recipients module) -->
        <div>
          <label class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400"
            for="recipient_${idx}">${t('receiving.recipient')}</label>
          <input id="recipient_${idx}" type="text" list="receivingRecipientList"
            class="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
            placeholder="${t('receiving.recipientPlaceholder')}"
            value="${escHtml(recipientName)}"
            data-field="recipientName" data-idx="${idx}">
        </div>

        <!-- Recipient Result -->
        <div>
          <label class="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-slate-400"
            for="recipientResult_${idx}">${t('receiving.recipientResult')}</label>
          <select id="recipientResult_${idx}"
            class="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-300 transition focus:border-cyan-400/50 focus:bg-white/[0.07]"
            data-field="recipientResult" data-idx="${idx}">
            <option value="" ${!r.recipientResult ? 'selected' : ''}>${t('receiving.resultNone')}</option>
            <option value="passed" ${r.recipientResult === 'passed' ? 'selected' : ''}>${t('receiving.resultPassed')}</option>
            <option value="failed" ${r.recipientResult === 'failed' ? 'selected' : ''}>${t('receiving.resultFailed')}</option>
            <option value="partial" ${r.recipientResult === 'partial' ? 'selected' : ''}>${t('receiving.resultPartial')}</option>
          </select>
        </div>

      </div>

      <!-- Shipping status (read-only, driven by delivery acts) -->
      <div class="mt-3 flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.03] px-4 py-3">
        <span class="text-xs font-semibold uppercase tracking-wider text-slate-500">${t('receiving.shippingAllowed')}</span>
        ${r.shippingAllowed
          ? `<span class="ml-auto text-xs font-semibold text-green-400 bg-green-400/10 rounded-lg px-2 py-0.5">✓ ${t('receiving.shippingAllowedYes')}</span>`
          : `<span class="ml-auto text-xs font-semibold text-red-400 bg-red-400/10 rounded-lg px-2 py-0.5">✕ ${t('receiving.shippingAllowedNo')}</span>`}
        <span class="text-[10px] text-slate-600 ml-1">из акта поставки</span>
      </div>

      <div class="mt-4 flex justify-end">
        <button type="button"
          class="save-item-btn inline-flex items-center gap-2 rounded-xl bg-cyan-400/10 border border-cyan-400/20 px-4 py-2 text-xs font-semibold text-cyan-400 transition hover:bg-cyan-400/20 active:scale-[0.97]"
          data-idx="${idx}">
          ✓ ${t('receiving.saveItem')}
        </button>
      </div>
    </div>
  `;
}

// ─── Wire save button ─────────────────────────────────────────────

function wireItemCard(wrap, contract, item, idx) {
  const saveBtn = wrap.querySelector(`.save-item-btn[data-idx="${idx}"]`);
  if (saveBtn) {
    saveBtn.addEventListener('click', async () => {
      await saveItemReceiving(wrap, contract, item, idx);
    });
  }
}

async function saveItemReceiving(wrap, contract, item, idx) {
  const fields = ['soDeadline', 'soResult', 'warehouseDeadline', 'warehouseResult', 'recipientResult'];
  const receiving = { ...(item.receiving || {}) };

  fields.forEach(field => {
    const el = wrap.querySelector(`[data-field="${field}"][data-idx="${idx}"]`);
    if (el) receiving[field] = el.value;
  });

  // Note: shippingAllowed is now read-only (set by delivery acts sync), not saved here.

  // Recipient: resolve name → id
  const recipientInput = wrap.querySelector(`[data-field="recipientName"][data-idx="${idx}"]`);
  if (recipientInput) {
    const name = recipientInput.value.trim();
    const found = state.recipients.find(r => r.name === name);
    receiving.recipientId = found ? found.id : null;
    receiving.recipientName = name;
  }

  // Save directly on the original item reference (works because item is a reference into contract.items)
  item.receiving = receiving;

  await saveToStorage();
  showToast(t('receiving.saved'), 'success');

  // Visual feedback on button
  const saveBtn = wrap.querySelector(`.save-item-btn[data-idx="${idx}"]`);
  if (saveBtn) {
    const orig = saveBtn.innerHTML;
    saveBtn.innerHTML = `✓ ${t('receiving.savedOk')}`;
    saveBtn.classList.add('bg-cyan-400/30');
    setTimeout(() => {
      saveBtn.innerHTML = orig;
      saveBtn.classList.remove('bg-cyan-400/30');
    }, 1800);
  }
}

// ─── Commission block ─────────────────────────────────────────────

/**
 * Renders the «Комиссия» block inside the receiving list panel.
 * The block is appended to #receivingCommissionWrap (must exist in HTML).
 */
export function renderCommissionBlock() {
  const wrap = document.getElementById('receivingCommissionWrap');
  if (!wrap) return;

  const members = state.commission || [];
  const inputCls = 'w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]';

  wrap.innerHTML = `
    <div class="overflow-hidden rounded-xl border border-white/10">
      <table class="w-full text-sm">
        <thead>
          <tr class="bg-white/[0.04] border-b border-white/10">
            <th class="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wider text-slate-400 w-1/2">${t('commission.fieldRole')}</th>
            <th class="px-3 py-2 text-left text-xs font-semibold uppercase tracking-wider text-slate-400 w-1/2">${t('commission.fieldName')}</th>
            <th class="w-10"></th>
          </tr>
        </thead>
        <tbody class="divide-y divide-white/5" id="commissionTableBody">
          ${members.length === 0
            ? `<tr><td colspan="3" class="px-4 py-4 text-xs text-slate-500 text-center">${t('commission.empty')}</td></tr>`
            : members.map((m, i) => `
              <tr data-member-id="${m.id}">
                <td class="px-2 py-1.5">
                  <input type="text" class="${inputCls} comm-role-inp"
                    placeholder="${t('commission.fieldRole')}"
                    value="${escHtml(m.role)}" data-id="${m.id}">
                </td>
                <td class="px-2 py-1.5">
                  <input type="text" class="${inputCls} comm-name-inp"
                    placeholder="${t('commission.fieldName')}"
                    value="${escHtml(m.name)}" data-id="${m.id}">
                </td>
                <td class="px-2 py-1.5 text-center">
                  <button class="w-7 h-7 flex items-center justify-center rounded-lg text-slate-500
                    hover:text-red-400 hover:bg-red-400/10 transition comm-del-btn mx-auto"
                    data-id="${m.id}" aria-label="${t('actions.delete')}">✕</button>
                </td>
              </tr>`).join('')
          }
        </tbody>
      </table>
    </div>
    <div class="mt-2 flex items-center gap-2">
      <button id="commAddBtn" type="button"
        class="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl border border-dashed
          border-white/20 bg-white/[0.03] px-3 py-2 text-xs font-medium text-slate-400 transition
          hover:border-cyan-400/30 hover:text-cyan-400 hover:bg-cyan-400/5">
        <span aria-hidden="true">＋</span> ${t('commission.add')}
      </button>
      <button id="commSaveBtn" type="button"
        class="inline-flex items-center gap-1.5 rounded-xl bg-cyan-400/10 border border-cyan-400/20
          px-4 py-2 text-xs font-semibold text-cyan-400 transition hover:bg-cyan-400/20 active:scale-[0.97]">
        ✓ ${t('commission.save')}
      </button>
    </div>`;

  // Add member
  document.getElementById('commAddBtn')?.addEventListener('click', () => {
    addCommissionMember('', '');
    renderCommissionBlock();
  });

  // Save all
  document.getElementById('commSaveBtn')?.addEventListener('click', async () => {
    _saveCommissionFromDOM(wrap);
    await saveToStorage();
    showToast(t('commission.saved'), 'success');
    renderCommissionBlock();
  });

  // Delete member
  wrap.querySelectorAll('.comm-del-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = Number(btn.dataset.id);
      removeCommissionMember(id);
      await saveToStorage();
      renderCommissionBlock();
    });
  });
}

/** Update badge showing commission member count */
function updateCommissionBadge() {
  const badge = document.getElementById('commissionCountBadge');
  if (!badge) return;
  const count = (state.commission || []).length;
  if (count > 0) {
    badge.textContent = count;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }
}

/** Read current DOM values and update state.commission */
function _saveCommissionFromDOM(wrap) {
  const roleInputs = wrap.querySelectorAll('.comm-role-inp');
  const nameInputs = wrap.querySelectorAll('.comm-name-inp');
  roleInputs.forEach((inp, i) => {
    const id = Number(inp.dataset.id);
    const nameInp = nameInputs[i];
    updateCommissionMember(id, inp.value, nameInp ? nameInp.value : undefined);
  });
}

// ─── Helpers ──────────────────────────────────────────────────────

function escHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function fmtNum(n) {
  const num = parseFloat(n) || 0;
  return num.toLocaleString('ru-RU', { maximumFractionDigits: 2 });
}
