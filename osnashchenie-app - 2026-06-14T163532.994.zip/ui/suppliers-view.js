/**
 * Suppliers view.
 * Panel 1: list of suppliers.
 * Panel 2: full-screen supplier card:
 *   – Basic info: name, INN, address, email
 *   – Phones (multiple)
 *   – Contact persons (multiple)
 *   – Contracts: read-only list auto-synced from state.contracts
 *   – Contract cards are clickable → open in Contracts module
 */

import { $, el, clearChildren } from './dom.js';
import { state } from '../state.js';
import { saveToStorage } from '../storage.js';
import { showToast } from './toast.js';

const t = (key, vals) => window.miniappI18n?.t(key, vals) ?? key;

let editingSupplierId = null;
let editingPhones     = [];   // [{id, value}]
let editingPersons    = [];   // [{id, value}]

// ─── Helpers ──────────────────────────────────────────────────────

function uid() { return Date.now() + Math.random(); }

function nextSupplierId() {
  if (!state.suppliers || state.suppliers.length === 0) return 1;
  return Math.max(...state.suppliers.map(s => s.id)) + 1;
}

function getSupplierById(id) {
  return (state.suppliers || []).find(s => s.id === id) || null;
}

function makeContract(overrides = {}) {
  return { id: uid(), number: '', email: '', phone: '', contactPerson: '', ...overrides };
}

function makePhone(value = '')   { return { id: uid(), value }; }
function makePerson(value = '')  { return { id: uid(), value }; }

// ─── List render ──────────────────────────────────────────────────

function renderSuppliersList() {
  const container = $('suppliersList');
  if (!container) return;
  clearChildren(container);

  const suppliers = state.suppliers || [];

  if (suppliers.length === 0) {
    const empty = el('div', { className: 'flex flex-col items-center justify-center py-16 text-center' });
    empty.appendChild(el('span', { className: 'text-5xl mb-4' }, '🏢'));
    empty.appendChild(el('p', { className: 'text-sm text-slate-500' }, t('suppliers.empty')));
    container.appendChild(empty);
    return;
  }

  const grid = el('div', { className: 'flex flex-col gap-3' });

  suppliers.forEach(sup => {
    const contractCount = (state.contracts || []).filter(c => c.supplierId === sup.id).length;

    const card = el('div', {
      className: 'rounded-2xl border border-white/10 bg-white/5 p-4 transition hover:bg-white/[0.07] cursor-pointer',
    });

    // Top row
    const top = el('div', { className: 'flex items-start justify-between gap-3 mb-2' });
    const nameWrap = el('div', { className: 'flex-1 min-w-0' });
    nameWrap.appendChild(el('h3', { className: 'text-base font-semibold text-white truncate' }, sup.name));
    if (sup.inn) {
      nameWrap.appendChild(el('p', { className: 'text-xs text-slate-500 mt-0.5' }, 'ИНН: ' + sup.inn));
    }
    if (sup.address) {
      nameWrap.appendChild(el('p', { className: 'text-xs text-slate-500 mt-0.5 truncate' }, '📍 ' + sup.address));
    }
    // First phone
    const phones = sup.phones || [];
    if (phones.length > 0 && phones[0].value) {
      nameWrap.appendChild(el('p', { className: 'text-xs text-slate-500 mt-0.5' }, '📞 ' + phones[0].value));
    }
    top.appendChild(nameWrap);

    if (contractCount > 0) {
      top.appendChild(el('span', {
        className: 'rounded-lg bg-cyan-400/15 px-2 py-0.5 text-xs font-bold text-cyan-400 tabular-nums shrink-0',
      }, t('suppliers.contractCount', { count: contractCount })));
    }
    card.appendChild(top);

    // Small action buttons
    const actions = el('div', { className: 'flex gap-1 justify-end' });
    actions.appendChild(el('button', {
      className: 'rounded-xl p-2 text-slate-500 hover:bg-cyan-400/10 hover:text-cyan-400 transition',
      'aria-label': t('actions.edit'),
      title: t('actions.edit'),
      onClick: (e) => { e.stopPropagation(); openEditSupplier(sup.id); },
    }, '✎'));
    actions.appendChild(el('button', {
      className: 'rounded-xl p-2 text-slate-500 hover:bg-red-500/20 hover:text-red-400 transition',
      'aria-label': t('actions.delete'),
      title: t('actions.delete'),
      onClick: (e) => { e.stopPropagation(); handleDeleteSupplier(sup); },
    }, '✕'));
    card.appendChild(actions);

    card.addEventListener('click', () => openViewSupplier(sup.id));

    grid.appendChild(card);
  });

  container.appendChild(grid);
}

// ─── Open / close edit panel ──────────────────────────────────────

function openEditSupplier(supplierId) {
  const sup = getSupplierById(supplierId);
  if (!sup) return;
  _supplierReadonly = false;
  editingSupplierId = supplierId;
  editingPhones     = (sup.phones    || []).map(p => ({ ...p }));
  editingPersons    = (sup.persons   || []).map(p => ({ ...p }));

  $('editSupplierName').value    = sup.name    || '';
  $('editSupplierInn').value     = sup.inn     || '';
  $('editSupplierAddress').value = sup.address || '';
  $('editSupplierEmail').value   = sup.email   || '';

  renderPhonesList();
  renderPersonsList();
  renderLinkedContractsList();

  $('supplierListPanel').classList.add('hidden');
  $('supplierEditPanel').classList.remove('hidden');
  setTimeout(() => $('editSupplierName')?.focus(), 100);
}

let _supplierReadonly = false;

function openViewSupplier(supplierId) {
  openEditSupplier(supplierId);
  setSupplierCardReadonly(true);
}

function setSupplierCardReadonly(readonly) {
  _supplierReadonly = readonly;
  const panel = $('supplierEditPanel');
  if (!panel) return;
  panel.querySelectorAll('input, select, textarea').forEach(inp => {
    inp.disabled = readonly;
    inp.style.opacity = readonly ? '0.7' : '';
    inp.style.cursor = readonly ? 'default' : '';
  });
  const saveBtn = $('supplierEditSaveBtn');
  const editBtn = $('supplierEditEditBtn');
  if (saveBtn) saveBtn.classList.toggle('hidden', readonly);
  if (editBtn) editBtn.classList.toggle('hidden', !readonly);
  // Hide add/remove buttons for phones, persons
  panel.querySelectorAll(
    '#addPhoneBtn, #addPersonBtn, [aria-label="' + t('actions.delete') + '"]'
  ).forEach(b => {
    b.classList.toggle('hidden', readonly);
  });
}

function closeEditSupplier() {
  editingSupplierId = null;
  editingPhones     = [];
  editingPersons    = [];
  $('supplierEditPanel').classList.add('hidden');
  $('supplierListPanel').classList.remove('hidden');
  renderSuppliersList();
}

// ─── Save ─────────────────────────────────────────────────────────

function handleSaveSupplier() {
  const name = ($('editSupplierName').value || '').trim();
  if (!name) {
    showToast(t('form.required'), 'error');
    $('editSupplierName').focus();
    return;
  }

  const phones    = collectMulti('supplierPhonesWrap',  'phone-value');
  const persons   = collectMulti('supplierPersonsWrap', 'person-value');

  const sup = getSupplierById(editingSupplierId);
  if (sup) {
    sup.name     = name;
    sup.inn      = ($('editSupplierInn').value     || '').trim();
    sup.address  = ($('editSupplierAddress').value || '').trim();
    sup.email    = ($('editSupplierEmail').value   || '').trim();
    sup.phones    = phones;
    sup.persons   = persons;
  }

  saveToStorage();
  showToast(t('toast.saved'), 'success');
  closeEditSupplier();
}

// ─── Multi-value helpers (phones / persons) ───────────────────────

/** Render a list of removable text inputs inside a wrapper element */
function renderMultiList({ wrapperId, items, dataProp, placeholder, addBtnId }) {
  const wrap = $(wrapperId);
  if (!wrap) return;
  clearChildren(wrap);

  if (items.length === 0) {
    wrap.appendChild(el('p', {
      className: 'text-xs text-slate-500 italic py-1',
    }, t('suppliers.noneYet')));
    return;
  }

  items.forEach((item, idx) => {
    const row = el('div', { className: 'flex gap-2 items-center' });

    const input = el('input', {
      type: dataProp === 'phone-value' ? 'tel' : 'text',
      className: 'flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white transition focus:border-cyan-400/50 focus:bg-white/[0.07]',
      placeholder,
      'data-multi': dataProp,
      'data-idx': String(idx),
    });
    input.value = item.value || '';

    const removeBtn = el('button', {
      type: 'button',
      className: 'rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-sm text-slate-400 transition hover:bg-red-500/15 hover:text-red-400 shrink-0',
      'aria-label': t('actions.delete'),
      onClick: () => {
        items.splice(idx, 1);
        renderMultiList({ wrapperId, items, dataProp, placeholder, addBtnId });
      },
    }, '✕');

    row.appendChild(input);
    row.appendChild(removeBtn);
    wrap.appendChild(row);
  });
}

function collectMulti(wrapperId, dataProp) {
  const wrap = $(wrapperId);
  if (!wrap) return [];
  return [...wrap.querySelectorAll(`[data-multi="${dataProp}"]`)].map((inp, idx) => ({
    id: uid(),
    value: inp.value.trim(),
  })).filter(x => x.value);
}

function renderPhonesList() {
  renderMultiList({
    wrapperId: 'supplierPhonesWrap',
    items: editingPhones,
    dataProp: 'phone-value',
    placeholder: '+7 (999) 000-00-00',
    addBtnId: 'addPhoneBtn',
  });
}

function renderPersonsList() {
  renderMultiList({
    wrapperId: 'supplierPersonsWrap',
    items: editingPersons,
    dataProp: 'person-value',
    placeholder: 'Иванов Иван Иванович',
    addBtnId: 'addPersonBtn',
  });
}

// ─── Contracts list (read-only, auto-synced from state.contracts) ─

/** Render read-only list of contracts linked to current supplier */
export function renderLinkedContractsList(supplierId) {
  const id = supplierId ?? editingSupplierId;
  const wrap = $('contractsListWrap');
  if (!wrap) return;
  clearChildren(wrap);

  const linked = (state.contracts || []).filter(c => c.supplierId === id);
  const fmt = new Intl.NumberFormat('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  if (linked.length === 0) {
    wrap.appendChild(el('div', {
      className: 'rounded-xl border border-dashed border-white/15 p-5 text-center',
    }, el('p', { className: 'text-sm text-slate-500' },
      'Контрактов пока нет — добавьте контракт в разделе «Контракты»')));
    return;
  }

  linked.forEach(contract => {
    const card = el('div', {
      className: 'rounded-xl border border-white/10 bg-white/5 px-4 py-3 space-y-1.5 cursor-pointer transition hover:bg-white/[0.09] hover:border-cyan-400/25 group',
    });

    // Number + date
    const header = el('div', { className: 'flex items-center gap-2 flex-wrap' });
    const numSpan = el('span', {
      className: 'text-sm font-semibold text-cyan-400 flex-1',
    }, contract.number ? `№ ${contract.number}` : t('contracts.noNumber'));
    header.appendChild(numSpan);
    if (contract.date) {
      header.appendChild(el('span', { className: 'text-xs text-slate-500' }, contract.date));
    }
    // «Открыть →» hint
    header.appendChild(el('span', {
      className: 'text-xs text-cyan-400 opacity-0 group-hover:opacity-100 transition ml-auto shrink-0',
    }, 'Открыть →'));
    card.appendChild(header);

    if (contract.title) {
      card.appendChild(el('p', { className: 'text-xs text-slate-300 truncate' }, contract.title));
    }

    // Price + positions + programs
    const itemCount = (contract.items || []).filter(i => i.name && i.name.trim()).length;
    const meta = el('div', { className: 'flex gap-3 text-xs text-slate-500 flex-wrap' });
    meta.appendChild(el('span', { className: 'tabular-nums text-slate-400' },
      fmt.format(Number(contract.totalPrice) || 0) + ' ₽'));
    if (itemCount > 0) meta.appendChild(el('span', {}, `${itemCount} ${t('contracts.positions')}`));
    const progNames = (contract.programs || []).map(p => p.name).filter(Boolean).join(', ');
    if (progNames) meta.appendChild(el('span', {}, '📋 ' + progNames));
    card.appendChild(meta);

    // Click → open contract card in Contracts module
    card.addEventListener('click', () => {
      // Close suppliers modal first, then open contracts modal at this contract
      import('./contracts-view.js').then(m => {
        closeSuppliersModal();
        m.openContractsModal();
        // Small delay to let the contracts list render before opening the card
        setTimeout(() => {
          m.openContractView(contract.id);
        }, 60);
      });
    });

    wrap.appendChild(card);
  });
}

// ─── Delete supplier ──────────────────────────────────────────────

function handleDeleteSupplier(sup) {
  if (!confirm(t('suppliers.confirmDelete') + '\n' + sup.name)) return;
  state.suppliers = (state.suppliers || []).filter(s => s.id !== sup.id);
  saveToStorage();
  showToast(t('toast.deleted'), 'success');
  renderSuppliersList();
}

// ─── Add supplier ─────────────────────────────────────────────────

function handleAddSupplier() {
  const input = $('newSupplierInput');
  if (!input) return;
  const name = input.value.trim();
  if (!name) return;

  if (!state.suppliers) state.suppliers = [];
  const sup = {
    id: nextSupplierId(),
    name,
    inn:       '',
    address:   '',
    email:     '',
    phones:    [],
    persons:   [],
    contracts: [],
  };
  state.suppliers.push(sup);
  saveToStorage();
  showToast(t('suppliers.added'), 'success');
  input.value = '';
  openEditSupplier(sup.id);
}

// ─── Open / Close modal ───────────────────────────────────────────

export function openSuppliersModal() {
  const overlay = $('suppliersModal');
  if (!overlay) return;
  $('supplierListPanel').classList.remove('hidden');
  $('supplierEditPanel').classList.add('hidden');
  renderSuppliersList();
  overlay.classList.add('open');
  setTimeout(() => $('newSupplierInput')?.focus(), 100);
}

export function closeSuppliersModal() {
  editingSupplierId = null;
  const overlay = $('suppliersModal');
  if (overlay) overlay.classList.remove('open');
}

// ─── Init ─────────────────────────────────────────────────────────

export function initSuppliersView() {
  const overlay = $('suppliersModal');
  if (!overlay) return;

  overlay.addEventListener('click', e => {
    if (e.target === overlay) closeSuppliersModal();
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && overlay.classList.contains('open')) {
      if (!$('supplierEditPanel').classList.contains('hidden')) {
        closeEditSupplier();
      } else {
        closeSuppliersModal();
      }
    }
  });

  $('addSupplierBtn')?.addEventListener('click', handleAddSupplier);
  $('newSupplierInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); handleAddSupplier(); }
  });
  $('suppliersCloseBtn')?.addEventListener('click', closeSuppliersModal);
  $('supplierEditBackBtn')?.addEventListener('click', closeEditSupplier);
  $('supplierEditSaveBtn')?.addEventListener('click', handleSaveSupplier);
  $('supplierEditEditBtn')?.addEventListener('click', () => setSupplierCardReadonly(false));

  // Add phone
  $('addPhoneBtn')?.addEventListener('click', () => {
    editingPhones.push(makePhone());
    renderPhonesList();
  });

  // Add contact person
  $('addPersonBtn')?.addEventListener('click', () => {
    editingPersons.push(makePerson());
    renderPersonsList();
  });

  // Note: contracts are managed in the Contracts module and auto-appear here
}
