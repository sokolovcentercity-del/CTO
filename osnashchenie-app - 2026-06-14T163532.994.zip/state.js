/**
 * Application state management.
 * Single source of truth for products, categories, filters, and sorting.
 */

const DEFAULT_CATEGORIES = ['Мебель', 'Спорт', 'Учебное', 'Пищеблок'];

export const state = {
  products: [],
  categories: [...DEFAULT_CATEGORIES],
  productGroups: [],     // Товарные группы: string[]
  recipients: [],
  suppliers: [],
  programs: [],          // Финансы: целевые программы
  nextProgramId: 1,
  contracts: [],
  warehouses: [],        // Склады: [{ id, name, supplierId, address, phone }]
  nextWarehouseId: 1,
  nextProductGroupId: 1,
  activeWarehouseId: null, // null = сводный режим (все склады)
  commission: [],        // Комиссия приёмки: [{ id, role, name }]
  nextCommissionId: 1,
  acts: [],              // Реестр актов проверки: [{ id, ...actData, savedAt }]
  nextActId: 1,
  orders: [],            // Реестр заявок: [{ id, orderNumber, contractId, ... }]
  nextOrderId: 1,
  warehouseEntries: [],  // Склад: поступления товаров
  nextWarehouseEntryId: 1,
  shipments: [],         // Реестр отгрузок: [{ id, date, items, grid, createdAt }]
  nextShipmentId: 1,
  filters: { search: '', category: '', color: '' },
  sort: { key: 'number', dir: 'asc' },
  nextId: 1,
  nextRecipientId: 1,
  nextContractId: 1,
};

/** Get all used product numbers */
function getUsedNumbers() {
  return new Set(state.products.map(p => p.number));
}

/** Generate a unique product number that doesn't collide with any existing */
export function generateNumber() {
  const used = getUsedNumbers();
  let candidate = state.products.length > 0
    ? Math.max(...state.products.map(p => p.number)) + 1
    : 1;
  while (used.has(candidate)) {
    candidate++;
  }
  return candidate;
}

/** Ensure a specific number is unique; if not, find the next available */
export function ensureUniqueNumber(desired) {
  const used = getUsedNumbers();
  let n = desired;
  while (used.has(n)) {
    n++;
  }
  return n;
}

/** Get all categories (predefined + from products) */
export function getCategories() {
  const seen = new Map(); // lowercase -> canonical name
  for (const cat of state.categories) {
    seen.set(cat.toLowerCase(), cat);
  }
  state.products.forEach(p => {
    if (p.category && !seen.has(p.category.toLowerCase())) {
      seen.set(p.category.toLowerCase(), p.category);
    }
  });
  return [...seen.values()].sort((a, b) => a.localeCompare(b));
}

/** Get unique colors from products */
export function getColors() {
  const cols = new Set(state.products.map(p => p.color).filter(Boolean));
  return [...cols].sort((a, b) => a.localeCompare(b));
}

/** Get filtered and sorted products */
export function getFilteredProducts() {
  const { search, category, color } = state.filters;
  const query = search.toLowerCase().trim();

  let result = state.products.filter(p => {
    if (category && p.category !== category) return false;
    if (color && p.color !== color) return false;
    if (query) {
      const specsText = Array.isArray(p.specs) ? p.specs.join(' ') : (p.characteristics || '');
      const haystack = [p.name, p.category, p.color, specsText, String(p.number)]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      if (!haystack.includes(query)) return false;
    }
    return true;
  });

  // Apply sorting
  const { key, dir } = state.sort;
  const mult = dir === 'asc' ? 1 : -1;

  result.sort((a, b) => {
    let va = a[key];
    let vb = b[key];

    // Numeric sort for 'number'
    if (key === 'number') {
      return ((va || 0) - (vb || 0)) * mult;
    }

    // String sort for everything else
    va = (va || '').toString().toLowerCase();
    vb = (vb || '').toString().toLowerCase();
    return va.localeCompare(vb) * mult;
  });

  return result;
}

/** Set sort column and direction */
export function setSort(key) {
  if (state.sort.key === key) {
    state.sort.dir = state.sort.dir === 'asc' ? 'desc' : 'asc';
  } else {
    state.sort.key = key;
    state.sort.dir = 'asc';
  }
}

/** Add a category */
export function addCategory(name) {
  const trimmed = name.trim();
  if (!trimmed) return false;
  const lower = trimmed.toLowerCase();
  if (state.categories.some(c => c.toLowerCase() === lower)) return false;
  state.categories.push(trimmed);
  state.categories.sort((a, b) => a.localeCompare(b));
  return true;
}

/** Remove a category */
export function removeCategory(name) {
  const idx = state.categories.indexOf(name);
  if (idx === -1) return false;
  state.categories.splice(idx, 1);
  return true;
}

/**
 * Normalize a single spec entry to { param, unit, value }.
 * Handles old plain strings (e.g. "Длина: 120 см" or "Длина 120 см").
 */
function normalizeSpecItem(s) {
  if (s && typeof s === 'object') {
    return {
      param: String(s.param ?? ''),
      unit:  String(s.unit  ?? ''),
      value: String(s.value ?? ''),
    };
  }
  // Migrate old string: try "Param: value unit" or "Param | unit | value"
  const str = String(s ?? '').trim();
  if (!str) return null;
  // Pipe-separated: "param | unit | value"
  const pipeParts = str.split('|').map(p => p.trim());
  if (pipeParts.length === 3) {
    return { param: pipeParts[0], unit: pipeParts[1], value: pipeParts[2] };
  }
  // Colon-separated: "param: value"
  const colonIdx = str.indexOf(':');
  if (colonIdx > 0) {
    return { param: str.slice(0, colonIdx).trim(), unit: '', value: str.slice(colonIdx + 1).trim() };
  }
  // Fallback: put whole string into param
  return { param: str, unit: '', value: '' };
}

/**
 * Normalize product specs to { param, unit, value }[].
 * Handles old string `characteristics` and new `specs` array.
 */
export function normalizeSpecs(product) {
  if (Array.isArray(product.specs)) {
    return product.specs.map(normalizeSpecItem).filter(Boolean);
  }
  if (typeof product.characteristics === 'string' && product.characteristics.trim()) {
    return product.characteristics
      .split('\n')
      .map(s => s.trim())
      .filter(Boolean)
      .map(normalizeSpecItem)
      .filter(Boolean);
  }
  return [];
}

/** Add a product (manual entry — number is auto-assigned) */
export function addProduct(product) {
  product.id = state.nextId++;
  product.number = generateNumber();
  // Normalize specs
  if (!Array.isArray(product.specs)) {
    product.specs = normalizeSpecs(product);
  }
  if (product.assembly === undefined) product.assembly = 'not_required';
  delete product.characteristics;
  state.products.push(product);
  return product;
}

/** Update a product by id */
export function updateProduct(id, data) {
  const idx = state.products.findIndex(p => p.id === id);
  if (idx === -1) return null;
  // Normalize specs in incoming data
  if (data.specs !== undefined && !Array.isArray(data.specs)) {
    data.specs = normalizeSpecs(data);
  }
  if (data.characteristics !== undefined && data.specs === undefined) {
    data.specs = typeof data.characteristics === 'string'
      ? data.characteristics.split('\n').map(s => s.trim()).filter(Boolean)
      : [];
    delete data.characteristics;
  }
  Object.assign(state.products[idx], data);
  return state.products[idx];
}

/** Delete a product by id */
export function deleteProduct(id) {
  const idx = state.products.findIndex(p => p.id === id);
  if (idx === -1) return false;
  state.products.splice(idx, 1);
  // Clean up recipient needs referencing deleted product
  removeRecipientNeedsForProduct(id);
  return true;
}

/** Get recipient by id */
export function getRecipientById(id) {
  return state.recipients.find(r => r.id === id) || null;
}

/** Add a recipient */
export function addRecipient(name) {
  const trimmed = name.trim();
  if (!trimmed) return null;
  const recipient = {
    id: state.nextRecipientId++,
    name: trimmed,
    address: '',
    readinessStatus: '',
    targetProgram: '',
    needs: {},
  };
  state.recipients.push(recipient);
  return recipient;
}

/** Delete a recipient by id */
export function deleteRecipient(id) {
  const idx = state.recipients.findIndex(r => r.id === id);
  if (idx === -1) return false;
  state.recipients.splice(idx, 1);
  return true;
}

/** Update recipient fields */
export function updateRecipient(id, data) {
  const r = getRecipientById(id);
  if (!r) return null;
  if (data.name !== undefined) r.name = data.name;
  if (data.address !== undefined) r.address = data.address;
  if (data.readinessStatus !== undefined) r.readinessStatus = data.readinessStatus;
  if (data.targetProgram !== undefined) r.targetProgram = data.targetProgram;
  return r;
}

/** Update recipient needs */
export function updateRecipientNeeds(id, needs) {
  const r = getRecipientById(id);
  if (!r) return null;
  r.needs = needs;
  return r;
}

/** Remove a product reference from all recipients' needs */
export function removeRecipientNeedsForProduct(productId) {
  state.recipients.forEach(r => {
    delete r.needs[productId];
  });
}

/** Add multiple products (for import — numbers come from file) */
export function addProducts(products) {
  products.forEach(p => {
    p.id = state.nextId++;
    if (!p.number || p.number <= 0) {
      p.number = generateNumber();
    } else {
      p.number = ensureUniqueNumber(p.number);
    }
    if (p.category && !state.categories.some(c => c.toLowerCase() === p.category.toLowerCase())) {
      state.categories.push(p.category);
    }
    // Normalize specs
    if (!Array.isArray(p.specs)) {
      p.specs = normalizeSpecs(p);
    }
    delete p.characteristics;
    state.products.push(p);
  });
  state.categories.sort((a, b) => a.localeCompare(b));
  return products.length;
}

/** Find product by id */
export function getProductById(id) {
  return state.products.find(p => p.id === id) || null;
}

/**
 * Scan all products for duplicate numbers and reassign unique numbers.
 * Returns the number of products that were renumbered.
 */
export function renumberDuplicateNumbers() {
  if (state.products.length <= 1) return 0;

  const sorted = [...state.products].sort((a, b) => (a.number - b.number) || (a.id - b.id));

  const used = new Set();
  let renumbered = 0;
  let nextFree = 1;

  for (const product of sorted) {
    if (used.has(product.number)) {
      while (used.has(nextFree)) nextFree++;
      product.number = nextFree;
      renumbered++;
    }
    used.add(product.number);
    if (nextFree <= product.number) nextFree = product.number + 1;
  }

  return renumbered;
}

/**
 * Deduplicate categories case-insensitively.
 * Keeps the first occurrence (original casing), removes case-only duplicates.
 * Also normalizes product category references to match the kept variant.
 */
export function deduplicateCategories() {
  const seen = new Map(); // lowercase -> canonical name
  const kept = [];

  for (const cat of state.categories) {
    const lower = cat.toLowerCase();
    if (!seen.has(lower)) {
      seen.set(lower, cat);
      kept.push(cat);
    }
  }

  // Also merge categories found in products
  for (const p of state.products) {
    if (!p.category) continue;
    const lower = p.category.toLowerCase();
    if (!seen.has(lower)) {
      seen.set(lower, p.category);
      kept.push(p.category);
    }
  }

  state.categories = kept.sort((a, b) => a.localeCompare(b));

  // Normalize product category references to the canonical form
  for (const p of state.products) {
    if (!p.category) continue;
    const canonical = seen.get(p.category.toLowerCase());
    if (canonical && canonical !== p.category) {
      p.category = canonical;
    }
  }
}

// ─── Contracts ───────────────────────────────────────────────────

/** Add a contract */
export function addContract(data) {
  const contract = {
    id: state.nextContractId++,
    title: data.title || '',
    number: data.number || '',
    date: data.date || '',
    supplierId: data.supplierId || null,
    totalPrice: data.totalPrice || 0,
    programs: data.programs || [],
    items: data.items || [],
  };
  state.contracts.push(contract);
  return contract;
}

/** Update a contract by id */
export function updateContract(id, data) {
  const c = state.contracts.find(ct => ct.id === id);
  if (!c) return null;
  if (data.title     !== undefined) c.title     = data.title;
  if (data.number    !== undefined) c.number    = data.number;
  if (data.date      !== undefined) c.date      = data.date;
  if (data.supplierId !== undefined) c.supplierId = data.supplierId;
  if (data.totalPrice !== undefined) c.totalPrice = data.totalPrice;
  if (data.advancePct !== undefined) c.advancePct = data.advancePct;
  if (data.programs  !== undefined) c.programs  = data.programs;
  if (data.items     !== undefined) c.items     = data.items;
  return c;
}

/** Delete a contract by id */
export function deleteContract(id) {
  const idx = state.contracts.findIndex(ct => ct.id === id);
  if (idx === -1) return false;
  state.contracts.splice(idx, 1);
  return true;
}

/** Get contract by id */
export function getContractById(id) {
  return state.contracts.find(ct => ct.id === id) || null;
}

/**
 * Sync contract items with catalog:
 * - removes items for deleted products
 * - adds missing products (qty=0, price=0)
 * - sorts by product number
 */
export function syncContractItems(contract) {
  const existingMap = new Map(contract.items.map(i => [i.productId, i]));
  const productIds = new Set(state.products.map(p => p.id));

  // Remove items for deleted products
  contract.items = contract.items.filter(i => productIds.has(i.productId));

  // Add missing products
  for (const p of state.products) {
    if (!existingMap.has(p.id)) {
      contract.items.push({
        productId: p.id,
        price: 0,
        qty: 0,
        ordered: 0,
        delivered: 0,
        paidAdvance: 0,
        paid50: 0,
        paid30: 0,
        receiving: {},
      });
    }
  }

  // Sort by product number
  contract.items.sort((a, b) => {
    const pa = state.products.find(p => p.id === a.productId);
    const pb = state.products.find(p => p.id === b.productId);
    return ((pa?.number || 0) - (pb?.number || 0));
  });
}

// ─── Finance Programs ─────────────────────────────────────────────

/** Get all finance programs */
export function getPrograms() {
  return state.programs;
}

/** Get program names as string array (for dropdowns) */
export function getProgramNames() {
  return state.programs.map(p => p.name).filter(Boolean);
}

/** Add a finance program */
export function addProgram(data) {
  const program = {
    id: state.nextProgramId++,
    name: data.name || '',
    code: data.code || '',
    kbk: data.kbk || '',
    limit: data.limit || 0,
  };
  state.programs.push(program);
  return program;
}

/** Update a finance program */
export function updateProgram(id, data) {
  const p = state.programs.find(pr => pr.id === id);
  if (!p) return null;
  if (data.name  !== undefined) p.name  = data.name;
  if (data.code  !== undefined) p.code  = data.code;
  if (data.kbk   !== undefined) p.kbk   = data.kbk;
  if (data.limit !== undefined) p.limit = data.limit;
  return p;
}

/** Delete a finance program */
export function deleteProgram(id) {
  const idx = state.programs.findIndex(p => p.id === id);
  if (idx === -1) return false;
  state.programs.splice(idx, 1);
  return true;
}

// ─── Receiving ────────────────────────────────────────────────────

/**
 * Update receiving data for a specific item in a contract.
 * @param {number} contractId
 * @param {number} productId
 * @param {object} receivingData
 */
export function updateReceivingItem(contractId, productId, receivingData) {
  const contract = state.contracts.find(c => c.id === contractId);
  if (!contract) return null;
  const item = contract.items.find(i => i.productId === productId);
  if (!item) return null;
  item.receiving = { ...(item.receiving || {}), ...receivingData };
  return item;
}

// ─── Commission (Приёмочная комиссия) ─────────────────────────────

/** Get all commission members */
export function getCommission() {
  return state.commission;
}

/** Add a commission member */
export function addCommissionMember(role, name) {
  const member = {
    id: state.nextCommissionId++,
    role: role || '',
    name: name || '',
  };
  state.commission.push(member);
  return member;
}

/** Update a commission member */
export function updateCommissionMember(id, role, name) {
  const m = state.commission.find(c => c.id === id);
  if (!m) return null;
  m.role = role ?? m.role;
  m.name = name ?? m.name;
  return m;
}

/** Remove a commission member */
export function removeCommissionMember(id) {
  const idx = state.commission.findIndex(c => c.id === id);
  if (idx === -1) return false;
  state.commission.splice(idx, 1);
  return true;
}

// ─── Acts Registry ────────────────────────────────────────────────

/** Get all saved acts */
export function getActs() {
  return state.acts;
}

/** Save a new act */
export function saveAct(actData) {
  const act = {
    id: state.nextActId++,
    ...actData,
    savedAt: new Date().toISOString(),
  };
  state.acts.push(act);
  return act;
}

/** Update an existing act by id */
export function updateAct(id, actData) {
  const idx = state.acts.findIndex(a => a.id === id);
  if (idx === -1) return null;
  state.acts[idx] = {
    ...state.acts[idx],
    ...actData,
    id,
    updatedAt: new Date().toISOString(),
  };
  return state.acts[idx];
}

/** Delete an act by id */
export function deleteAct(id) {
  const idx = state.acts.findIndex(a => a.id === id);
  if (idx === -1) return false;
  state.acts.splice(idx, 1);
  return true;
}

// ─── Orders (Заявки) ─────────────────────────────────────────────

/** Generate order number: last 4 digits of contract number + seq + program code */
export function generateOrderNumber(contract, seqNum, programCode) {
  const contractNum = String(contract.number || '');
  const last4 = contractNum.replace(/\D/g, '').slice(-4).padStart(4, '0') || '0000';
  const seq = String(seqNum).padStart(2, '0');
  const code = programCode ? `-${programCode}` : '';
  return `${last4}-${seq}${code}`;
}

/** Get next sequence number for a contract */
export function getNextOrderSeq(contractId) {
  const existing = state.orders.filter(o => o.contractId === contractId);
  if (existing.length === 0) return 1;
  const maxSeq = existing.reduce((max, o) => Math.max(max, o.seqNum || 0), 0);
  return maxSeq + 1;
}

/** Add an order */
export function addOrder(data) {
  const order = { id: state.nextOrderId++, ...data, createdAt: new Date().toISOString() };
  state.orders.push(order);
  return order;
}

/** Update an order */
export function updateOrder(id, data) {
  const o = state.orders.find(x => x.id === id);
  if (!o) return null;
  Object.assign(o, data);
  return o;
}

/** Delete an order */
export function deleteOrder(id) {
  const idx = state.orders.findIndex(x => x.id === id);
  if (idx === -1) return false;
  state.orders.splice(idx, 1);
  return true;
}

// ─── Warehouse (Склад) ────────────────────────────────────────────

/**
 * Warehouse entry shape:
 * { id, productId, productCode, productName, supplierId, contractId, orderId,
 *   date, received, shipped, accepted, notes, createdAt }
 *
 * balance = received - shipped  (computed on read)
 * category: string — подтягивается из каталога по productId при сохранении
 * accepted: boolean — true = принято, false = не принято
 */

/** Compute balance for an entry */
export function warehouseBalance(entry) {
  return (entry.received || 0) - (entry.shipped || 0);
}

/** Get all warehouse entries (with computed balance) */
export function getWarehouseEntries() {
  return state.warehouseEntries.map(e => ({ ...e, balance: warehouseBalance(e) }));
}

/** Add a warehouse entry */
export function addWarehouseEntry(data) {
  const entry = {
    id: state.nextWarehouseEntryId++,
    productId:   data.productId   ?? null,
    productCode: data.productCode ?? '',
    productName: data.productName ?? '',
    category:    data.category    ?? '',
    supplierId:  data.supplierId  ?? null,
    contractId:  data.contractId  ?? null,
    orderId:     data.orderId     ?? null,
    date:        data.date        ?? '',
    received:    Number(data.received)  || 0,
    shipped:     Number(data.shipped)   || 0,
    accepted:    Boolean(data.accepted),
    notes:       data.notes       ?? '',
    items:       Array.isArray(data.items) ? data.items : [],
    createdAt:   new Date().toISOString(),
    warehouseId: data.warehouseId ?? null,
  };
  state.warehouseEntries.push(entry);
  return entry;
}

/** Update a warehouse entry */
export function updateWarehouseEntry(id, data) {
  const e = state.warehouseEntries.find(x => x.id === id);
  if (!e) return null;
  const fields = ['productId','productCode','productName','supplierId','contractId',
                  'orderId','date','received','shipped','accepted','notes','category',
                  'items'];
  fields.push('warehouseId');
  for (const f of fields) {
    if (data[f] !== undefined) e[f] = data[f];
  }
  if (data.received !== undefined) e.received = Number(data.received) || 0;
  if (data.shipped  !== undefined) e.shipped  = Number(data.shipped)  || 0;
  return e;
}

/** Delete a warehouse entry */
export function deleteWarehouseEntry(id) {
  const idx = state.warehouseEntries.findIndex(x => x.id === id);
  if (idx === -1) return false;
  state.warehouseEntries.splice(idx, 1);
  return true;
}

// ─── Warehouses (Склады) ──────────────────────────────────────────

/** Ensure default "Основной склад" exists and migrate old entries */
export function ensureDefaultWarehouse() {
  if (state.warehouses.length === 0) {
    const main = {
      id: state.nextWarehouseId++,
      name: 'Основной склад',
      supplierId: null,
      address: '',
      phone: '',
      isDefault: true,
    };
    state.warehouses.push(main);
    // Migrate all existing entries to the main warehouse
    state.warehouseEntries.forEach(e => {
      if (!e.warehouseId) e.warehouseId = main.id;
    });
    return main;
  }
  // Migrate entries that have no warehouseId to first warehouse
  const first = state.warehouses[0];
  state.warehouseEntries.forEach(e => {
    if (!e.warehouseId) e.warehouseId = first.id;
  });
  return first;
}

export function addWarehouse(data) {
  const wh = {
    id: state.nextWarehouseId++,
    name: data.name || 'Склад',
    supplierId: data.supplierId ?? null,
    address: data.address ?? '',
    phone: data.phone ?? '',
    isDefault: false,
  };
  state.warehouses.push(wh);
  return wh;
}

export function updateWarehouse(id, data) {
  const wh = state.warehouses.find(w => w.id === id);
  if (!wh) return null;
  if (data.name       !== undefined) wh.name       = data.name;
  if (data.supplierId !== undefined) wh.supplierId = data.supplierId;
  if (data.address    !== undefined) wh.address    = data.address;
  if (data.phone      !== undefined) wh.phone      = data.phone;
  return wh;
}

export function deleteWarehouse(id) {
  const wh = state.warehouses.find(w => w.id === id);
  if (!wh || wh.isDefault) return false;
  const idx = state.warehouses.findIndex(w => w.id === id);
  if (idx === -1) return false;
  state.warehouses.splice(idx, 1);
  const fallback = state.warehouses[0];
  if (fallback) {
    state.warehouseEntries.forEach(e => {
      if (e.warehouseId === id) e.warehouseId = fallback.id;
    });
  }
  return true;
}

export function getWarehouseById(id) {
  return state.warehouses.find(w => w.id === id) || null;
}

// ─── Acts shipping helpers ────────────────────────────────────────

/**
 * Returns true if ANY saved delivery act has shippingAllowed === true
 * for a product matching the given productCode or productName.
 *
 * This is the authoritative source for «принято / допущено к отгрузке»
 * in the warehouse module.
 */
export function isShippingAllowedByActs(productCode, productName) {
  const code = (productCode || '').trim().toLowerCase();
  const name = (productName || '').trim().toLowerCase();
  if (!code && !name) return false;

  return (state.acts || []).some(act => {
    if ((act.mode || 'so') !== 'delivery') return false;
    return (act.selectedItems || []).some(si => {
      if (si.selected === false) return false;
      if (si.shippingAllowed !== true) return false;
      const siCode = (si.itemCode || '').trim().toLowerCase();
      const siName = (si.name    || '').trim().toLowerCase();
      // Match by code first (more reliable), then by name
      if (code && siCode && siCode === code) return true;
      if (name && siName && siName === name) return true;
      return false;
    });
  });
}

// ─── Shipments (Отгрузки) ─────────────────────────────────────────

/**
 * Shipment shape:
 * { id, date, note, rows: [{ codeKey, productCode, productName, category, recipients: [{ recipientId, recipientName, qty }] }], totalQty, createdAt }
 */

/** Get all shipments */
export function getShipments() {
  return state.shipments;
}

/** Add a shipment record */
export function addShipment(data) {
  const shipment = { id: state.nextShipmentId++, ...data, createdAt: new Date().toISOString() };
  state.shipments.push(shipment);
  return shipment;
}

/** Update a shipment record */
export function updateShipment(id, data) {
  const s = state.shipments.find(x => x.id === id);
  if (!s) return null;
  Object.assign(s, data, { id, updatedAt: new Date().toISOString() });
  return s;
}

/** Delete a shipment record */
export function deleteShipment(id) {
  const idx = state.shipments.findIndex(s => s.id === id);
  if (idx === -1) return false;
  state.shipments.splice(idx, 1);
  return true;
}

// ─── Delivered recalculation ──────────────────────────────────────

/**
 * Атомарный пересчёт delivered у всех получателей из реестра отгрузок.
 * Вызывается после загрузки и после каждого сохранения/редактирования отгрузки.
 * Гарантирует консистентность: delivered = сумма всех отгрузок по данному
 * товару для данного получателя.
 */
export function recalcAllDelivered() {
  // Собираем суммы по (recipientId, productId) из всех отгрузок
  const deliveredMap = new Map(); // key: `${recipientId}:${productId}` -> total qty

  for (const shipment of (state.shipments || [])) {
    for (const row of (shipment.rows || [])) {
      // Находим product по коду или имени
      const prod = row.productCode
        ? state.products.find(p => p.code && p.code.trim().toLowerCase() === row.productCode.trim().toLowerCase())
        : null;
      const prodByName = !prod && row.productName
        ? state.products.find(p => p.name && p.name.trim().toLowerCase() === row.productName.trim().toLowerCase())
        : null;
      const resolvedProd = prod || prodByName;
      if (!resolvedProd) continue;

      for (const recEntry of (row.recipients || [])) {
        const qty = Number(recEntry.qty) || 0;
        if (qty <= 0) continue;
        const mapKey = `${recEntry.recipientId}:${resolvedProd.id}`;
        deliveredMap.set(mapKey, (deliveredMap.get(mapKey) || 0) + qty);
      }
    }
  }

  // Применяем к state.recipients
  for (const rec of (state.recipients || [])) {
    if (!rec.needs) continue;
    for (const [pidStr, entry] of Object.entries(rec.needs)) {
      const pid = Number(pidStr);
      const mapKey = `${rec.id}:${pid}`;
      const newDelivered = deliveredMap.get(mapKey) || 0;
      if (typeof entry === 'object') {
        entry.delivered = newDelivered;
      } else {
        rec.needs[pidStr] = { qty: Number(entry) || 0, delivered: newDelivered, assembled: 0 };
      }
    }
    // Set delivered for products that appear in shipments but not yet in needs
    for (const [mapKey, qty] of deliveredMap.entries()) {
      const [rId, pId] = mapKey.split(':').map(Number);
      if (rId !== rec.id) continue;
      if (!rec.needs[pId]) {
        rec.needs[pId] = { qty: 0, delivered: qty, assembled: 0 };
      }
    }
  }
}

// ─── Assembled recalculation ──────────────────────────────────────

/**
 * Атомарный пересчёт assembled у всех получателей из реестра актов сборки.
 * Вызывается после загрузки и после каждого сохранения/удаления акта сборки.
 *
 * Одинаковые товары из разных заявок или разных контрактов суммируются:
 * assembled = Σ item.assembled по всем актам для данного (recipientId, productId).
 *
 * ПРАВИЛО: assembled не может превышать delivered.
 * Если превышает — обрезается до delivered, возвращается список нарушений.
 *
 * @returns {{ warnings: Array<{recipientName:string, productName:string, assembled:number, delivered:number}> }}
 */
export function recalcAllAssembled() {
  const warnings = [];

  // Собираем суммы по (recipientId, productId) из всех актов сборки
  const assembledMap = new Map(); // key: `${recipientId}:${productId}` -> total assembled

  for (const act of (state.assemblyActs || [])) {
    const recipientId = act.recipientId;
    if (!recipientId) continue;

    for (const item of (act.items || [])) {
      const qty = Number(item.assembled) || 0;
      if (qty <= 0) continue;

      // Resolve productId: сначала из поля item.productId, затем по коду/имени
      let prod = item.productId
        ? state.products.find(p => p.id === item.productId)
        : null;

      if (!prod) {
        const code = (item.productCode || '').trim().toLowerCase();
        const name = (item.productName || '').trim().toLowerCase();
        if (code) {
          prod = state.products.find(p => (p.code || '').trim().toLowerCase() === code);
          if (!prod) prod = state.products.find(p => {
            const pc = (p.code || '').trim().toLowerCase();
            return pc && (pc.includes(code) || code.includes(pc));
          });
        }
        if (!prod && name) {
          prod = state.products.find(p => (p.name || '').trim().toLowerCase() === name);
          if (!prod) prod = state.products.find(p => {
            const pn = (p.name || '').trim().toLowerCase();
            return pn && pn.length > 3 && (pn.includes(name) || name.includes(pn));
          });
        }
      }

      if (!prod) continue;

      const mapKey = `${recipientId}:${prod.id}`;
      assembledMap.set(mapKey, (assembledMap.get(mapKey) || 0) + qty);
    }
  }

  // Применяем к state.recipients
  for (const rec of (state.recipients || [])) {
    if (!rec.needs) continue;
    for (const [pidStr, entry] of Object.entries(rec.needs)) {
      const pid = Number(pidStr);
      const mapKey = `${rec.id}:${pid}`;
      let newAssembled = assembledMap.get(mapKey) || 0;
      if (typeof entry === 'object') {
        // Enforce assembled ≤ delivered
        const delivered = entry.delivered || 0;
        if (newAssembled > delivered && delivered > 0) {
          const prod = state.products.find(p => p.id === pid);
          warnings.push({
            recipientName: rec.name,
            productName: prod ? (prod.name || prod.code || String(pid)) : String(pid),
            assembled: newAssembled,
            delivered,
          });
          newAssembled = delivered;
        }
        entry.assembled = newAssembled;
      } else {
        rec.needs[pidStr] = { qty: Number(entry) || 0, delivered: 0, assembled: newAssembled };
      }
    }
    // Применяем для товаров, которые есть в актах, но не в needs
    for (const [mapKey, qty] of assembledMap.entries()) {
      const [rId, pId] = mapKey.split(':').map(Number);
      if (rId !== rec.id) continue;
      if (!rec.needs[pId]) {
        // No delivery recorded yet — assembled cannot exceed delivered (0)
        // Don't create a needs entry with assembled > 0 if delivered = 0
        rec.needs[pId] = { qty: 0, delivered: 0, assembled: 0 };
        if (qty > 0) {
          const prod = state.products.find(p => p.id === pId);
          warnings.push({
            recipientName: rec.name,
            productName: prod ? (prod.name || prod.code || String(pId)) : String(pId),
            assembled: qty,
            delivered: 0,
          });
        }
      }
    }
  }

  return { warnings };
}

/**
 * Миграция: добавляет productId в строки старых отгрузок, где он отсутствует.
 * Ищет товар по productCode, затем по productName.
 * Возвращает количество изменённых строк.
 */
export function migrateShipmentProductIds() {
  let changed = 0;
  for (const shipment of (state.shipments || [])) {
    for (const row of (shipment.rows || [])) {
      if (row.productId) continue;
      const code = (row.productCode || '').trim().toLowerCase();
      const name = (row.productName || '').trim().toLowerCase();
      let prod = null;
      if (code) prod = state.products.find(p => (p.code || '').trim().toLowerCase() === code);
      if (!prod && code) prod = state.products.find(p => { const pc = (p.code || '').trim().toLowerCase(); return pc && (pc.includes(code) || code.includes(pc)); });
      if (!prod && name) prod = state.products.find(p => (p.name || '').trim().toLowerCase() === name);
      if (!prod && name) prod = state.products.find(p => { const pn = (p.name || '').trim().toLowerCase(); return pn && pn.length > 3 && (pn.includes(name) || name.includes(pn)); });
      if (prod) { row.productId = prod.id; changed++; }
    }
  }
  return changed;
}

/**
 * Миграция: заполняет orderNum / orderId в строках старых отгрузок,
 * где эти поля отсутствуют или равны null.
 *
 * Алгоритм:
 *  1. Если у строки есть orderKey вида «codeKey::orderId» — берём orderId из него.
 *  2. Если orderId найден — ищем заявку в state.orders и берём orderNumber.
 *  3. Если orderKey нет / orderId = noorder — ищем складскую запись
 *     по codeKey и берём её orderId, затем заявку.
 *
 * Возвращает количество изменённых строк.
 */
export function migrateShipmentOrderNums() {
  let changed = 0;

  for (const shipment of (state.shipments || [])) {
    for (const row of (shipment.rows || [])) {
      // Уже заполнено — пропускаем
      if (row.orderNum) continue;

      let resolvedOrderId = row.orderId ?? null;

      // Шаг 1: попробуем извлечь orderId из orderKey
      if (!resolvedOrderId && row.orderKey) {
        const parts = row.orderKey.split('::');
        if (parts.length === 2 && parts[1] !== 'noorder') {
          const parsed = Number(parts[1]);
          if (!isNaN(parsed)) resolvedOrderId = parsed;
        }
      }

      // Шаг 2: если orderId всё ещё нет — ищем по codeKey в складских записях
      if (!resolvedOrderId && row.codeKey) {
        const ck = row.codeKey.toLowerCase();
        for (const entry of (state.warehouseEntries || [])) {
          if (!entry.orderId) continue;
          const items = Array.isArray(entry.items) ? entry.items : [];
          const match = items.some(item => {
            const code = (item.productCode || '').trim().toLowerCase();
            const name = (item.productName || '').trim().toLowerCase();
            return (code && code === ck) || (name && name === ck);
          });
          if (match) { resolvedOrderId = entry.orderId; break; }
        }
      }

      // Шаг 3: по orderId находим заявку и берём номер
      if (resolvedOrderId) {
        const order = (state.orders || []).find(o => o.id === resolvedOrderId);
        if (order) {
          row.orderId  = resolvedOrderId;
          row.orderNum = order.orderNumber || ('Заявка #' + resolvedOrderId);
          // Обновляем orderKey если он был без orderId
          if (!row.orderKey || row.orderKey.endsWith('::noorder')) {
            row.orderKey = (row.codeKey || '') + '::' + String(resolvedOrderId);
          }
          changed++;
        }
      }
    }
  }

  return changed;
}

// ─── Order delivery/assembly aggregates ──────────────────────────

/**
 * Суммарное количество поставленного по заявке для данного товара.
 * Источник: state.warehouseEntries — записи с orderId === orderId,
 * в entry.items ищем совпадение по имени или коду.
 */
export function calcOrderDelivered(orderId, productName, productCode) {
  if (!orderId) return 0;
  const nameLow = (productName || '').trim().toLowerCase();
  const codeLow = (productCode || '').trim().toLowerCase();
  let total = 0;
  for (const entry of (state.warehouseEntries || [])) {
    if (entry.orderId !== orderId) continue;
    const items = Array.isArray(entry.items) ? entry.items : [];
    if (items.length > 0) {
      for (const item of items) {
        const iName = (item.productName || '').trim().toLowerCase();
        const iCode = (item.productCode || '').trim().toLowerCase();
        const matchCode = codeLow && iCode && codeLow === iCode;
        const matchName = nameLow && iName && nameLow === iName;
        if (matchCode || matchName) total += Number(item.qty) || 0;
      }
    } else {
      // Старый формат: одна запись = один товар
      const eName = (entry.productName || '').trim().toLowerCase();
      const eCode = (entry.productCode || '').trim().toLowerCase();
      const matchCode = codeLow && eCode && codeLow === eCode;
      const matchName = nameLow && eName && nameLow === eName;
      if (matchCode || matchName) total += Number(entry.received) || 0;
    }
  }
  return total;
}

/**
 * Суммарное количество собранного для данного товара по данному контракту.
 * Источник: state.assemblyActs — фильтруем по contractId,
 * в act.items ищем совпадение по productId, коду или имени.
 * Если contractId не задан — считаем по всем актам.
 */
export function calcOrderAssembled(contractId, productName, productCode, productId) {
  const nameLow = (productName || '').trim().toLowerCase();
  const codeLow = (productCode || '').trim().toLowerCase();
  let total = 0;
  for (const act of (state.assemblyActs || [])) {
    if (contractId && act.contractId !== contractId) continue;
    for (const item of (act.items || [])) {
      // 1. По productId
      if (productId && item.productId && item.productId === productId) {
        total += Number(item.assembled) || 0;
        continue;
      }
      // 2. По коду
      const iCode = (item.productCode || '').trim().toLowerCase();
      if (codeLow && iCode && codeLow === iCode) {
        total += Number(item.assembled) || 0;
        continue;
      }
      // 3. По имени
      const iName = (item.productName || '').trim().toLowerCase();
      if (nameLow && iName && nameLow === iName) {
        total += Number(item.assembled) || 0;
      }
    }
  }
  return total;
}

/**
 * Суммарное поставленное по контракту для данного товара
 * (суммирует по всем записям склада с contractId === contractId).
 * Источник: state.warehouseEntries.
 */
export function calcContractDelivered(contractId, productName, productCode) {
  if (!contractId) return 0;
  const nameLow = (productName || '').trim().toLowerCase();
  const codeLow = (productCode || '').trim().toLowerCase();
  let total = 0;
  for (const entry of (state.warehouseEntries || [])) {
    if (entry.contractId !== contractId) continue;
    const items = Array.isArray(entry.items) ? entry.items : [];
    if (items.length > 0) {
      for (const item of items) {
        const iName = (item.productName || '').trim().toLowerCase();
        const iCode = (item.productCode || '').trim().toLowerCase();
        const matchCode = codeLow && iCode && codeLow === iCode;
        const matchName = nameLow && iName && nameLow === iName;
        if (matchCode || matchName) total += Number(item.qty) || 0;
      }
    } else {
      const eName = (entry.productName || '').trim().toLowerCase();
      const eCode = (entry.productCode || '').trim().toLowerCase();
      const matchCode = codeLow && eCode && codeLow === eCode;
      const matchName = nameLow && eName && nameLow === eName;
      if (matchCode || matchName) total += Number(entry.received) || 0;
    }
  }
  return total;
}

/**
 * Суммарное собранное по контракту для данного товара
 * (суммирует по всем актам сборки данного контракта).
 */
export function calcContractAssembled(contractId, productName, productCode, productId) {
  return calcOrderAssembled(contractId, productName, productCode, productId);
}

// ─── Product Groups (Товарные группы) ────────────────────────────

/** Get all product groups (sorted) */
export function getProductGroups() {
  if (!Array.isArray(state.productGroups)) state.productGroups = [];
  return [...state.productGroups].sort((a, b) => a.localeCompare(b));
}

/** Add a product group; returns true if added, false if duplicate */
export function addProductGroup(name) {
  const trimmed = name.trim();
  if (!trimmed) return false;
  if (!Array.isArray(state.productGroups)) state.productGroups = [];
  const lower = trimmed.toLowerCase();
  if (state.productGroups.some(g => g.toLowerCase() === lower)) return false;
  state.productGroups.push(trimmed);
  state.productGroups.sort((a, b) => a.localeCompare(b));
  return true;
}

/** Remove a product group by name */
export function removeProductGroup(name) {
  if (!Array.isArray(state.productGroups)) return false;
  const idx = state.productGroups.indexOf(name);
  if (idx === -1) return false;
  state.productGroups.splice(idx, 1);
  return true;
}

/** Count products using a given group */
export function countProductsInGroup(groupName) {
  return state.products.filter(p => p.productGroup === groupName).length;
}

// ─── Needs / Contract quantity helpers ───────────────────────────

/**
 * Суммарная потребность по товару (productId) по всем получателям.
 * Источник: state.recipients[].needs[productId].qty
 */
export function calcTotalNeedForProduct(productId) {
  let total = 0;
  for (const rec of (state.recipients || [])) {
    if (!rec.needs) continue;
    const entry = rec.needs[productId];
    if (!entry) continue;
    const qty = typeof entry === 'object' ? (Number(entry.qty) || 0) : (Number(entry) || 0);
    total += qty;
  }
  return total;
}

/**
 * Суммарное количество товара во всех контрактах по имени/коду.
 * excludeContractId — текущий контракт (исключить из суммы, чтобы не считать дважды).
 * Сопоставление: по item.productRef (id каталога), затем по имени.
 */
export function calcTotalContractedForProduct(productId, productName, excludeContractId) {
  const nameLow = (productName || '').trim().toLowerCase();
  let total = 0;
  for (const c of (state.contracts || [])) {
    for (const item of (c.items || [])) {
      const matchById   = productId && item.productRef === productId;
      const matchByName = !matchById && nameLow && (item.name || '').trim().toLowerCase() === nameLow;
      if (matchById || matchByName) total += Number(item.qty) || 0;
    }
  }
  // Вычитаем текущий контракт (он учтён через DOM-значение отдельно)
  if (excludeContractId) {
    const excContract = state.contracts.find(c => c.id === excludeContractId);
    if (excContract) {
      for (const item of (excContract.items || [])) {
        const matchById   = productId && item.productRef === productId;
        const matchByName = !matchById && nameLow && (item.name || '').trim().toLowerCase() === nameLow;
        if (matchById || matchByName) total -= Number(item.qty) || 0;
      }
    }
  }
  return total;
}

// ─── Assembly helpers ─────────────────────────────────────────────

/**
 * Считает количество, уже собранного по предыдущим актам для данного
 * (recipientId, productId), исключая акт с id === excludeActId.
 *
 * Используется в форме нового акта сборки чтобы показать «Собрано ранее»
 * и вычислить доступное количество (delivered - previouslyAssembled).
 *
 * @param {number} recipientId
 * @param {number} productId
 * @param {number|null} [excludeActId] — id редактируемого акта (исключить из суммы)
 * @param {number|null} [supplierId]   — если задан, считать только акты этого поставщика
 * @returns {number}
 */
export function calcPreviouslyAssembled(recipientId, productId, excludeActId = null, supplierId = null) {
  let total = 0;
  for (const act of (state.assemblyActs || [])) {
    if (act.recipientId !== recipientId) continue;
    if (excludeActId !== null && act.id === excludeActId) continue;
    // Фильтрация по поставщику: если supplierId задан — берём только акты этого поставщика
    if (supplierId !== null) {
      // Поставщик акта определяется через контракт акта
      const actContract = act.contractId
        ? (state.contracts || []).find(c => c.id === act.contractId)
        : null;
      const actSupplierId = actContract?.supplierId ?? null;
      if (actSupplierId !== supplierId) continue;
    }
    for (const item of (act.items || [])) {
      let pid = item.productId ?? null;
      if (!pid) {
        const code = (item.productCode || '').trim().toLowerCase();
        const name = (item.productName || '').trim().toLowerCase();
        const found = code
          ? state.products.find(p => (p.code || '').trim().toLowerCase() === code)
          : null;
        const foundByName = !found && name
          ? state.products.find(p => (p.name || '').trim().toLowerCase() === name)
          : null;
        pid = (found || foundByName)?.id ?? null;
      }
      if (pid === productId) total += Number(item.assembled) || 0;
    }
  }
  return total;
}

/**
 * Возвращает Map<supplierId, assembledQty> — сколько собрано для данного
 * (recipientId, productId) по каждому поставщику.
 * Поставщик определяется через контракт акта сборки.
 *
 * @param {number} recipientId
 * @param {number} productId
 * @param {number|null} [excludeActId]
 * @returns {Map<number|null, number>}  key = supplierId (null = неизвестен)
 */
export function calcAssembledBySupplier(recipientId, productId, excludeActId = null) {
  const result = new Map(); // supplierId -> total

  for (const act of (state.assemblyActs || [])) {
    if (act.recipientId !== recipientId) continue;
    if (excludeActId !== null && act.id === excludeActId) continue;

    const actContract = act.contractId
      ? (state.contracts || []).find(c => c.id === act.contractId)
      : null;
    const actSupplierId = actContract?.supplierId ?? null;

    for (const item of (act.items || [])) {
      let pid = item.productId ?? null;
      if (!pid) {
        const code = (item.productCode || '').trim().toLowerCase();
        const name = (item.productName || '').trim().toLowerCase();
        const found = code
          ? state.products.find(p => (p.code || '').trim().toLowerCase() === code)
          : null;
        const foundByName = !found && name
          ? state.products.find(p => (p.name || '').trim().toLowerCase() === name)
          : null;
        pid = (found || foundByName)?.id ?? null;
      }
      if (pid !== productId) continue;

      const qty = Number(item.assembled) || 0;
      if (qty <= 0) continue;
      result.set(actSupplierId, (result.get(actSupplierId) || 0) + qty);
    }
  }

  return result;
}

/**
 * Распределяет суммарно собранное количество по заявкам FIFO.
 *
 * Логика:
 *  1. Берём историю доставок для (recipientId, productId) — отсортированную по дате.
 *  2. Берём суммарно собранное из актов для (recipientId, productId).
 *  3. Заполняем заявки слева направо (FIFO): сначала ранние, потом поздние.
 *
 * @param {number} recipientId
 * @param {number} productId
 * @param {Array<{orderId, orderNum, date, qty}>} deliveryEntries — история доставок (уже отсортирована)
 * @returns {Array<{orderId, orderNum, date, deliveredQty, assembledQty}>}
 */
export function getAssemblyFifoByOrders(recipientId, productId, deliveryEntries) {
  // Считаем суммарно собранное из всех актов для (recipientId, productId)
  let totalAssembled = 0;
  for (const act of (state.assemblyActs || [])) {
    if (act.recipientId !== recipientId) continue;
    for (const item of (act.items || [])) {
      let pid = item.productId ?? null;
      if (!pid) {
        const code = (item.productCode || '').trim().toLowerCase();
        const name = (item.productName || '').trim().toLowerCase();
        const found = code
          ? state.products.find(p => (p.code || '').trim().toLowerCase() === code)
          : null;
        const foundByName = !found && name
          ? state.products.find(p => (p.name || '').trim().toLowerCase() === name)
          : null;
        pid = (found || foundByName)?.id ?? null;
      }
      if (pid === productId) totalAssembled += Number(item.assembled) || 0;
    }
  }

  // Распределяем по заявкам FIFO
  let remaining = totalAssembled;
  return deliveryEntries.map(entry => {
    const take = Math.min(remaining, entry.qty);
    remaining = Math.max(0, remaining - take);
    return { ...entry, assembledQty: take };
  });
}

