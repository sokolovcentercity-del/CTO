<?php
/**
 * Конфигурация API-ключей
 * ВАЖНО: этот файл не должен быть доступен публично!
 * Защита через api/.htaccess
 */

// ─── ПРОВАЙДЕР ────────────────────────────────────────────────────────────────
// 'yandex'  — Alice AI LLM для анализа + Yandex Vision OCR
// 'claude'  — Anthropic Claude (резервный)
// 'hybrid'  — Yandex Vision OCR + Claude для анализа
define('AI_PROVIDER', 'yandex');

// ─── ЯНДЕКС CLOUD ─────────────────────────────────────────────────────────────
// Получить: console.yandex.cloud → Сервисный аккаунт → API-ключ
define('YANDEX_API_KEY',   'AQVN2DmbzzlMLZWOduaYNk_7I5EZoMP8Lgjxjlf6');
define('YANDEX_FOLDER_ID', 'b1g6ct67k67br081596n');

// Alice AI LLM — основная модель анализа (128K контекст)
define('YANDEX_MODEL_ANALYSIS', 'aliceai-llm/latest');

// Yandex Vision OCR — распознавание сканов (бесплатно до 1000 стр/мес)
define('YANDEX_OCR_ENDPOINT', 'https://ocr.api.cloud.yandex.net/ocr/v1/recognizeText');

// YandexGPT — эндпоинты
define('YANDEX_LLM_ASYNC_ENDPOINT',   'https://llm.api.cloud.yandex.net/foundationModels/v1/completionAsync');
define('YANDEX_OPERATION_ENDPOINT',   'https://operation.api.cloud.yandex.net/operations/');

// Таймаут polling для async-режима (секунды)
define('YANDEX_POLL_TIMEOUT',  180);
define('YANDEX_POLL_INTERVAL', 3);  // интервал опроса в секундах

// ─── ANTHROPIC (РЕЗЕРВНЫЙ) ────────────────────────────────────────────────────
// Получить: console.anthropic.com
define('ANTHROPIC_API_KEY', 'ВСТАВЬТЕ_СВОЙ_КЛЮЧ_ЗДЕСЬ');

// Модели Claude 4.x
define('MODEL_ANALYSIS', 'claude-sonnet-4-5-20250929');
define('MODEL_OCR',      'claude-haiku-4-5-20251001');

// ─── YANDEX OBJECT STORAGE ────────────────────────────────────────────────────
// Бакет: mto-cto (e3ednfsoufdt2m1i4267)
// Сервисный аккаунт: doc-checker-storage (ajerp5361rsrjbf7tj99)
// Роль: storage.editor на каталог b1g6ct67k67br081596n
define('YANDEX_STORAGE_BUCKET',     'mto-cto');
define('YANDEX_STORAGE_ACCESS_KEY', 'YCAJECFgdv8VBynCpojmdqmZV');
define('YANDEX_STORAGE_SECRET_KEY', 'YCMRlNYqf9UL2QWRAkQwl0oYtlIGEl1WPTZpL_9w');
define('YANDEX_STORAGE_REGION',     'ru-central1');
define('YANDEX_STORAGE_ENDPOINT',   'https://storage.yandexcloud.net');
// true — нативное чтение PDF через Storage (Alice AI читает файл по URL)
// false — текст через PDF.js + OCR для сканов
define('YANDEX_STORAGE_ENABLED',    true);

// ─── ОБЩИЕ ЛИМИТЫ ─────────────────────────────────────────────────────────────
define('MAX_FILE_SIZE_MB',       20);
define('MAX_FILES_PER_REQUEST',  50);
define('MAX_TOKENS_ANALYSIS',  8000);
define('MAX_TOKENS_OCR',       2000);
define('MAX_TOKENS_CONCLUSION',10000);
define('REQUEST_TIMEOUT',        240);

// CORS
define('ALLOWED_ORIGIN', '*');
