<?php
/**
 * handler.php — Alice AI LLM (Yandex Cloud) async mode + Yandex Vision OCR
 * POST action=analyze | POST action=ocr | GET ?test=1 | GET ?diag=1
 */
require_once __DIR__ . '/config.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
header('Content-Type: application/json; charset=utf-8');

// ─── Диагностика ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['diag'])) {
    $r = [
        'php'    => PHP_VERSION,
        'curl'   => function_exists('curl_init'),
        'key'    => defined('YANDEX_API_KEY')    && strlen(YANDEX_API_KEY)    > 20,
        'folder' => defined('YANDEX_FOLDER_ID')  && strlen(YANDEX_FOLDER_ID)  > 5,
        'model'  => defined('YANDEX_MODEL_ANALYSIS') ? YANDEX_MODEL_ANALYSIS : 'aliceai-llm/latest',
    ];
    if (function_exists('curl_init')) {
        $ch = curl_init('https://llm.api.cloud.yandex.net/');
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_NOBODY=>true, CURLOPT_TIMEOUT=>10]);
        curl_exec($ch); $e = curl_error($ch); $c = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $r['reach'] = $e ? 'FAILED:' . $e : 'OK(HTTP ' . $c . ')';
    }
    echo json_encode($r, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); exit;
}

// ─── Тест ─────────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['test'])) {
    $key = defined('YANDEX_API_KEY')   ? YANDEX_API_KEY   : '';
    $fid = defined('YANDEX_FOLDER_ID') ? YANDEX_FOLDER_ID : '';
    $mdl = defined('YANDEX_MODEL_ANALYSIS') ? YANDEX_MODEL_ANALYSIS : 'aliceai-llm/latest';
    if (!$key || !$fid) {
        echo json_encode(['status'=>'error','message'=>'API key или folder_id не заданы']); exit;
    }
    $pl = [
        'modelUri'          => 'gpt://' . $fid . '/' . $mdl,
        'completionOptions' => ['stream'=>false, 'temperature'=>0.1, 'maxTokens'=>10],
        'messages'          => [['role'=>'user','text'=>'ping']],
    ];
    $ch = curl_init('https://llm.api.cloud.yandex.net/foundationModels/v1/completion');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_POSTFIELDS     => json_encode($pl),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Api-Key ' . $key,
            'x-folder-id: ' . $fid,
        ],
    ]);
    $resp = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
    if ($err) { echo json_encode(['status'=>'error','message'=>'cURL: '.$err]); exit; }
    $b = json_decode($resp, true);
    if ($code === 200) {
        echo json_encode(['status'=>'ok','message'=>'Alice AI LLM (' . $mdl . ') доступна','provider'=>'alice']); exit;
    }
    echo json_encode(['status'=>'error','message'=>($b['message'] ?? 'HTTP ' . $code)]); exit;
}

// ─── Только POST ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error'=>'Method not allowed']); exit;
}

$raw = file_get_contents('php://input');
if (!$raw) { http_response_code(400); echo json_encode(['error'=>'Empty body']); exit; }
$data = json_decode($raw, true);
if (!is_array($data)) { http_response_code(400); echo json_encode(['error'=>'Invalid JSON']); exit; }

$action = $data['action'] ?? '';

// ════════════════════════════════════════════════════════════════════════════════
// ACTION: storage_status — проверить доступность Object Storage
// ════════════════════════════════════════════════════════════════════════════════
if ($action === 'storage_status') {
    $enabled = defined('YANDEX_STORAGE_ENABLED') && YANDEX_STORAGE_ENABLED;
    $bucket  = defined('YANDEX_STORAGE_BUCKET')  ? YANDEX_STORAGE_BUCKET  : '';
    $accKey  = defined('YANDEX_STORAGE_ACCESS_KEY') ? YANDEX_STORAGE_ACCESS_KEY : '';
    $secKey  = defined('YANDEX_STORAGE_SECRET_KEY') ? YANDEX_STORAGE_SECRET_KEY : '';
    if (!$enabled || !$bucket || !$accKey || !$secKey) {
        echo json_encode(['enabled' => false, 'reason' => 'Не настроен']); exit;
    }
    echo json_encode(['enabled' => true, 'bucket' => $bucket]); exit;
}

// ════════════════════════════════════════════════════════════════════════════════
// ACTION: upload_to_storage — загрузить PDF в Yandex Object Storage (S3)
// Принимает: { action, filename, base64, mediaType }
// Возвращает: { key, url } — key для последующего удаления
// ════════════════════════════════════════════════════════════════════════════════
if ($action === 'upload_to_storage') {
    $enabled = defined('YANDEX_STORAGE_ENABLED') && YANDEX_STORAGE_ENABLED;
    $bucket  = defined('YANDEX_STORAGE_BUCKET')  ? YANDEX_STORAGE_BUCKET  : '';
    $accKey  = defined('YANDEX_STORAGE_ACCESS_KEY') ? YANDEX_STORAGE_ACCESS_KEY : '';
    $secKey  = defined('YANDEX_STORAGE_SECRET_KEY') ? YANDEX_STORAGE_SECRET_KEY : '';
    $region  = defined('YANDEX_STORAGE_REGION')  ? YANDEX_STORAGE_REGION  : 'ru-central1';
    $endpoint = defined('YANDEX_STORAGE_ENDPOINT') ? YANDEX_STORAGE_ENDPOINT : 'https://storage.yandexcloud.net';

    if (!$enabled || !$bucket || !$accKey || !$secKey) {
        http_response_code(503);
        echo json_encode(['error' => 'Object Storage не настроен']); exit;
    }

    $filename  = $data['filename']  ?? ('doc_' . uniqid() . '.pdf');
    $b64       = $data['base64']    ?? '';
    $mediaType = $data['mediaType'] ?? 'application/pdf';
    if (!$b64) { http_response_code(400); echo json_encode(['error' => 'Нет base64']); exit; }

    $fileContent = base64_decode($b64);
    if (!$fileContent) { http_response_code(400); echo json_encode(['error' => 'Ошибка декодирования base64']); exit; }

    // Генерируем уникальный ключ объекта (папка doc-checker-tmp/ + uuid + имя файла)
    $safeFilename = preg_replace('/[^a-zA-Z0-9._\-]/', '_', basename($filename));
    $objectKey = 'doc-checker-tmp/' . uniqid('', true) . '_' . $safeFilename;

    // AWS Signature Version 4 для Yandex Object Storage
    $host        = $bucket . '.storage.yandexcloud.net';
    $uploadUrl   = 'https://' . $host . '/' . $objectKey;
    $contentMd5  = base64_encode(md5($fileContent, true));
    $date        = gmdate('Ymd');
    $datetime    = gmdate('Ymd\THis\Z');
    $payloadHash = hash('sha256', $fileContent);

    $headers = [
        'content-md5'        => $contentMd5,
        'content-type'       => $mediaType,
        'host'               => $host,
        'x-amz-content-sha256' => $payloadHash,
        'x-amz-date'         => $datetime,
    ];
    ksort($headers);

    $canonicalHeaders = '';
    $signedHeadersList = [];
    foreach ($headers as $k => $v) {
        $canonicalHeaders .= $k . ':' . $v . "\n";
        $signedHeadersList[] = $k;
    }
    $signedHeaders = implode(';', $signedHeadersList);

    $canonicalRequest = implode("\n", [
        'PUT',
        '/' . $objectKey,
        '',
        $canonicalHeaders,
        $signedHeaders,
        $payloadHash,
    ]);

    $scope       = $date . '/' . $region . '/s3/aws4_request';
    $stringToSign = implode("\n", [
        'AWS4-HMAC-SHA256',
        $datetime,
        $scope,
        hash('sha256', $canonicalRequest),
    ]);

    $signingKey = hash_hmac('sha256', 'aws4_request',
        hash_hmac('sha256', 's3',
            hash_hmac('sha256', $region,
                hash_hmac('sha256', $date, 'AWS4' . $secKey, true),
            true),
        true),
    true);
    $signature = hash_hmac('sha256', $stringToSign, $signingKey);

    $authHeader = 'AWS4-HMAC-SHA256 Credential=' . $accKey . '/' . $scope .
        ', SignedHeaders=' . $signedHeaders .
        ', Signature=' . $signature;

    $ch = curl_init($uploadUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PUT',
        CURLOPT_POSTFIELDS     => $fileContent,
        CURLOPT_TIMEOUT        => 120,
        CURLOPT_HTTPHEADER     => [
            'Authorization: '    . $authHeader,
            'Content-MD5: '      . $contentMd5,
            'Content-Type: '     . $mediaType,
            'Host: '             . $host,
            'x-amz-content-sha256: ' . $payloadHash,
            'x-amz-date: '      . $datetime,
        ],
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($err) { http_response_code(502); echo json_encode(['error' => 'Storage upload cURL: ' . $err]); exit; }
    if ($code < 200 || $code >= 300) {
        http_response_code(502);
        echo json_encode(['error' => 'Storage upload HTTP ' . $code . ': ' . substr($resp, 0, 300)]); exit;
    }

    echo json_encode([
        'key' => $objectKey,
        'url' => $uploadUrl,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ════════════════════════════════════════════════════════════════════════════════
// ACTION: delete_from_storage — удалить объект из Yandex Object Storage
// Принимает: { action, key }
// ════════════════════════════════════════════════════════════════════════════════
if ($action === 'delete_from_storage') {
    $bucket  = defined('YANDEX_STORAGE_BUCKET')      ? YANDEX_STORAGE_BUCKET      : '';
    $accKey  = defined('YANDEX_STORAGE_ACCESS_KEY')   ? YANDEX_STORAGE_ACCESS_KEY  : '';
    $secKey  = defined('YANDEX_STORAGE_SECRET_KEY')   ? YANDEX_STORAGE_SECRET_KEY  : '';
    $region  = defined('YANDEX_STORAGE_REGION')       ? YANDEX_STORAGE_REGION      : 'ru-central1';

    $objectKey = $data['key'] ?? '';
    if (!$bucket || !$accKey || !$secKey || !$objectKey) {
        echo json_encode(['deleted' => false, 'reason' => 'Параметры не заданы']); exit;
    }

    // Только объекты в папке doc-checker-tmp/ (защита от удаления чужих объектов)
    if (strpos($objectKey, 'doc-checker-tmp/') !== 0) {
        http_response_code(403);
        echo json_encode(['error' => 'Запрещено удалять объекты вне doc-checker-tmp/']); exit;
    }

    $host     = $bucket . '.storage.yandexcloud.net';
    $deleteUrl = 'https://' . $host . '/' . $objectKey;
    $date     = gmdate('Ymd');
    $datetime = gmdate('Ymd\THis\Z');
    $emptyHash = hash('sha256', '');

    $headers = [
        'host'               => $host,
        'x-amz-content-sha256' => $emptyHash,
        'x-amz-date'         => $datetime,
    ];
    ksort($headers);
    $canonicalHeaders = '';
    $signedHeadersList = [];
    foreach ($headers as $k => $v) {
        $canonicalHeaders .= $k . ':' . $v . "\n";
        $signedHeadersList[] = $k;
    }
    $signedHeaders = implode(';', $signedHeadersList);

    $canonicalRequest = implode("\n", [
        'DELETE',
        '/' . $objectKey,
        '',
        $canonicalHeaders,
        $signedHeaders,
        $emptyHash,
    ]);

    $scope = $date . '/' . $region . '/s3/aws4_request';
    $stringToSign = implode("\n", [
        'AWS4-HMAC-SHA256',
        $datetime,
        $scope,
        hash('sha256', $canonicalRequest),
    ]);

    $signingKey = hash_hmac('sha256', 'aws4_request',
        hash_hmac('sha256', 's3',
            hash_hmac('sha256', $region,
                hash_hmac('sha256', $date, 'AWS4' . $secKey, true),
            true),
        true),
    true);
    $signature = hash_hmac('sha256', $stringToSign, $signingKey);

    $authHeader = 'AWS4-HMAC-SHA256 Credential=' . $accKey . '/' . $scope .
        ', SignedHeaders=' . $signedHeaders . ', Signature=' . $signature;

    $ch = curl_init($deleteUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'DELETE',
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => [
            'Authorization: '        . $authHeader,
            'Host: '                 . $host,
            'x-amz-content-sha256: ' . $emptyHash,
            'x-amz-date: '          . $datetime,
        ],
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($err) { echo json_encode(['deleted' => false, 'error' => $err]); exit; }
    echo json_encode(['deleted' => ($code >= 200 && $code < 300), 'httpCode' => $code]);
    exit;
}

// ════════════════════════════════════════════════════════════════════════════════
// ACTION: ocr — Yandex Vision OCR для одной страницы (PNG base64)
// ════════════════════════════════════════════════════════════════════════════════
if ($action === 'ocr') {
    $apiKey   = defined('YANDEX_API_KEY')   ? YANDEX_API_KEY   : '';
    $folderId = defined('YANDEX_FOLDER_ID') ? YANDEX_FOLDER_ID : '';
    if (!$apiKey || !$folderId) {
        http_response_code(500); echo json_encode(['error'=>'Ключи не заданы']); exit;
    }

    $b64       = $data['base64']    ?? '';
    $mediaType = $data['mediaType'] ?? 'image/png';
    if (!$b64) { http_response_code(400); echo json_encode(['error'=>'Нет base64']); exit; }

    // Если передан PDF (не изображение) — извлекаем текст через PHP-парсер
    if (strpos($mediaType, 'application/pdf') !== false || strpos($mediaType, 'pdf') !== false) {
        $bin  = base64_decode($b64);
        $text = extractPdfText($bin);
        echo json_encode(['text' => $text]); exit;
    }

    // Изображение → Yandex Vision OCR (модель 'table' — лучше для таблиц)
    $payload = [
        'mimeType'   => $mediaType,
        'languageCodes' => ['ru', 'en'],
        'model'      => 'table',
        'content'    => $b64,
    ];

    $ch = curl_init('https://ocr.api.cloud.yandex.net/ocr/v1/recognizeText');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Api-Key ' . $apiKey,
            'x-folder-id: ' . $folderId,
            'x-data-logging-enabled: false',
        ],
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($err) { http_response_code(502); echo json_encode(['error'=>'OCR cURL: '.$err]); exit; }

    $ocrResult = json_decode($resp, true);
    if ($code !== 200 || !$ocrResult) {
        http_response_code($code ?: 502);
        echo json_encode(['error'=>'OCR ошибка: '.substr($resp, 0, 300)]); exit;
    }

    // Извлекаем текст из ответа Yandex Vision OCR
    $text = reconstructTableText($ocrResult);
    echo json_encode(['text' => $text]); exit;
}

// ════════════════════════════════════════════════════════════════════════════════
// ACTION: analyze — Alice AI LLM async
// ════════════════════════════════════════════════════════════════════════════════
if ($action !== 'analyze') {
    http_response_code(400); echo json_encode(['error'=>'Unknown action: ' . $action]); exit;
}

$apiKey   = defined('YANDEX_API_KEY')   ? YANDEX_API_KEY   : '';
$folderId = defined('YANDEX_FOLDER_ID') ? YANDEX_FOLDER_ID : '';
if (!$apiKey || !$folderId) {
    http_response_code(500); echo json_encode(['error'=>'Ключи не заданы в config.php']); exit;
}

$messages  = $data['messages']  ?? [];
$system    = $data['system']    ?? null;
$maxTokens = isset($data['max_tokens']) ? min((int)$data['max_tokens'], 32000) : 24000;
$model     = defined('YANDEX_MODEL_ANALYSIS') ? YANDEX_MODEL_ANALYSIS : 'aliceai-llm/latest';
$modelUri  = 'gpt://' . $folderId . '/' . $model;

// ─── Конвертация сообщений для Яндекс ────────────────────────────────────────
$yMsg = [];
if ($system) $yMsg[] = ['role'=>'system','text'=>$system];

foreach ($messages as $msg) {
    $role    = $msg['role']    ?? 'user';
    $content = $msg['content'] ?? '';

    if (is_string($content)) {
        $yMsg[] = ['role'=>$role, 'text'=>$content];
        continue;
    }
    if (!is_array($content)) continue;

    $parts = [];
    foreach ($content as $block) {
        $type = $block['type'] ?? '';
        if ($type === 'text') {
            $parts[] = $block['text'] ?? '';
        } elseif ($type === 'document') {
            $src        = $block['source']     ?? [];
            $title      = $block['title']      ?? 'Документ';
            $storageUrl = $block['storageUrl'] ?? null;

            // Если файл загружен в Object Storage — передаём URL напрямую (нативное чтение)
            if ($storageUrl) {
                // Alice AI поддерживает url-source в document-блоках (YandexGPT API v1)
                // Передаём как текстовую ссылку с пометкой для модели
                $parts[] = "=== Документ: $title (URL: $storageUrl) ===\n[Файл доступен по URL выше. Прочитай его содержимое для анализа.]";
            } elseif (($src['type'] ?? '') === 'text') {
                $parts[] = "=== Документ: $title ===\n" . ($src['data'] ?? '') . "\n=== Конец документа ===";
            } elseif (($src['type'] ?? '') === 'base64') {
                $extracted = extractTextFromBase64($src['data'] ?? '', $src['media_type'] ?? 'application/pdf');
                if ($extracted) {
                    $parts[] = "=== Документ: $title ===\n" . $extracted . "\n=== Конец документа ===";
                } else {
                    $parts[] = "[Документ $title: не удалось извлечь текст]";
                }
            }
        }
    }
    if ($parts) $yMsg[] = ['role'=>$role, 'text'=>implode("\n\n", $parts)];
}

// ─── Проверка контента ───────────────────────────────────────────────────────
$totalLen = 0;
foreach ($yMsg as $m) $totalLen += strlen($m['text'] ?? '');
if ($totalLen < 20) {
    http_response_code(422); echo json_encode(['error'=>'Нет текста для анализа']); exit;
}

// ─── Обрезка до лимита Alice AI (400K символов) ──────────────────────────────
foreach ($yMsg as &$m) {
    if (isset($m['text']) && strlen($m['text']) > 400000) {
        $m['text'] = mb_substr($m['text'], 0, 400000) . "\n\n[...обрезано до лимита...]";
    }
}
unset($m);

$payload = [
    'modelUri'          => $modelUri,
    'completionOptions' => ['stream'=>false, 'temperature'=>0.1, 'maxTokens'=>$maxTokens],
    'messages'          => $yMsg,
];

$headers = [
    'Content-Type: application/json',
    'Authorization: Api-Key ' . $apiKey,
    'x-folder-id: ' . $folderId,
];

// ─── Async запрос: /completionAsync → получаем operation_id ──────────────────
$ch = curl_init('https://llm.api.cloud.yandex.net/foundationModels/v1/completionAsync');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_CONNECTTIMEOUT => 15,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_HTTPHEADER     => $headers,
]);
$asyncResp = curl_exec($ch);
$asyncCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$asyncErr  = curl_error($ch);
curl_close($ch);

if ($asyncErr) {
    http_response_code(502);
    echo json_encode(['error'=>'cURL (async): ' . $asyncErr]); exit;
}

$asyncResult = json_decode($asyncResp, true);
if (!$asyncResult || $asyncCode >= 400) {
    http_response_code($asyncCode ?: 502);
    $errMsg = is_array($asyncResult) ? ($asyncResult['message'] ?? json_encode($asyncResult)) : substr($asyncResp, 0, 300);
    echo json_encode(['error'=>'Alice AI async error: ' . $errMsg]); exit;
}

$operationId = $asyncResult['id'] ?? null;
if (!$operationId) {
    http_response_code(502);
    echo json_encode(['error'=>'Нет operation_id в ответе', 'raw'=>substr($asyncResp, 0, 300)]); exit;
}

// ─── Polling: ждём завершения операции ───────────────────────────────────────
$pollUrl   = 'https://operation.api.cloud.yandex.net/operations/' . urlencode($operationId);
$maxWait   = 300;
$pollStart = time();
$pollDelay = 3;
$text      = null;

while (true) {
    sleep($pollDelay);
    if ($pollDelay < 10) $pollDelay++;

    if (time() - $pollStart > $maxWait) {
        http_response_code(504);
        echo json_encode(['error'=>'Таймаут ожидания ответа Alice AI (' . $maxWait . ' сек)']); exit;
    }

    $ch = curl_init($pollUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Api-Key ' . $apiKey,
            'x-folder-id: ' . $folderId,
        ],
    ]);
    $pollResp = curl_exec($ch);
    $pollCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $pollErr  = curl_error($ch);
    curl_close($ch);

    if ($pollErr) continue;

    $op = json_decode($pollResp, true);
    if (!is_array($op)) continue;
    if (!($op['done'] ?? false)) continue;

    if (isset($op['error'])) {
        http_response_code(502);
        echo json_encode(['error'=>'Alice AI operation error: ' . ($op['error']['message'] ?? json_encode($op['error']))]); exit;
    }

    $response = $op['response'] ?? $op;
    $text = $response['alternatives'][0]['message']['text']
         ?? $response['result']['alternatives'][0]['message']['text']
         ?? null;

    if ($text !== null) break;

    http_response_code(502);
    echo json_encode(['error'=>'Нет текста в ответе операции','raw'=>substr($pollResp, 0, 500)]); exit;
}

if ($text === null || $text === '') {
    http_response_code(502);
    echo json_encode(['error'=>'Модель вернула пустой ответ']); exit;
}

echo json_encode(
    ['content'=>[['type'=>'text','text'=>$text]], 'provider'=>'alice'],
    JSON_UNESCAPED_UNICODE
);
exit;

// ─── Вспомогательные функции ─────────────────────────────────────────────────

/**
 * Реконструирует табличный текст из ответа Yandex Vision OCR
 * Группирует слова по строкам (Y-координата), сортирует по X
 */
function reconstructTableText($ocrResult) {
    $blocks = $ocrResult['result']['textAnnotation']['blocks'] ?? [];
    if (empty($blocks)) {
        // Fallback: просто вытащим fullText
        return $ocrResult['result']['textAnnotation']['fullText'] ?? '';
    }

    // Собираем все слова с координатами
    $words = [];
    foreach ($blocks as $block) {
        foreach ($block['lines'] ?? [] as $line) {
            $lineY = getBlockY($line['boundingBox'] ?? []);
            foreach ($line['words'] ?? [] as $word) {
                $wordX = getBlockX($word['boundingBox'] ?? []);
                $words[] = [
                    'text' => $word['text'] ?? '',
                    'x'    => $wordX,
                    'y'    => $lineY,
                ];
            }
        }
    }

    if (empty($words)) {
        return $ocrResult['result']['textAnnotation']['fullText'] ?? '';
    }

    // Группируем по строкам (Y с допуском ±15px)
    usort($words, fn($a, $b) => $a['y'] <=> $b['y']);
    $lines = [];
    $currentLineY = null;
    $currentLine  = [];
    foreach ($words as $w) {
        if ($currentLineY === null || abs($w['y'] - $currentLineY) > 15) {
            if ($currentLine) {
                usort($currentLine, fn($a, $b) => $a['x'] <=> $b['x']);
                $lines[] = $currentLine;
            }
            $currentLine  = [$w];
            $currentLineY = $w['y'];
        } else {
            $currentLine[] = $w;
        }
    }
    if ($currentLine) {
        usort($currentLine, fn($a, $b) => $a['x'] <=> $b['x']);
        $lines[] = $currentLine;
    }

    // Формируем текст: слова в строке через табуляцию
    $text = '';
    foreach ($lines as $line) {
        $text .= implode("\t", array_column($line, 'text')) . "\n";
    }
    return trim($text);
}

function getBlockY($bbox) {
    $verts = $bbox['vertices'] ?? [];
    if (empty($verts)) return 0;
    return (int)(($verts[0]['y'] ?? 0) + ($verts[3]['y'] ?? 0)) / 2;
}

function getBlockX($bbox) {
    $verts = $bbox['vertices'] ?? [];
    if (empty($verts)) return 0;
    return (int)($verts[0]['x'] ?? 0);
}

function extractTextFromBase64($base64, $mediaType) {
    $bin = base64_decode($base64);
    if (!$bin) return '';
    if ($mediaType === 'application/pdf' || substr($bin, 0, 4) === '%PDF') return extractPdfText($bin);
    if (strpos($mediaType, 'application/vnd.openxmlformats') === 0 || $mediaType === 'application/msword') return extractDocxText($bin);
    if (strpos($mediaType, 'text/') === 0) return mb_convert_encoding($bin, 'UTF-8', 'auto');
    return '';
}

function extractPdfText($pdf) {
    $text = '';
    preg_match_all('/stream\r?\n(.*?)\r?\nendstream/s', $pdf, $m);
    foreach ($m[1] as $stream) {
        $d = @gzuncompress($stream);
        if ($d === false) $d = @gzinflate(substr($stream, 2));
        if ($d === false) $d = $stream;
        preg_match_all('/BT(.*?)ET/s', $d, $bt);
        foreach ($bt[1] as $b) {
            preg_match_all('/\(((?:[^()\\\\]|\\\\.)*)\)\s*Tj/', $b, $tj);
            foreach ($tj[1] as $s) { $s = str_replace(['\\n','\\r'], "\n", $s); $text .= $s . ' '; }
            preg_match_all('/\[((?:[^\[\]]|\[[^\[\]]*\])*)\]\s*TJ/', $b, $ta);
            foreach ($ta[1] as $a) { preg_match_all('/\(((?:[^()\\\\]|\\\\.)*)\)/', $a, $sa); foreach ($sa[1] as $s) { $text .= $s; } $text .= ' '; }
        }
    }
    $text = preg_replace('/[ \t]{3,}/', '  ', $text);
    return trim($text);
}

function extractDocxText($bin) {
    $tmp = tempnam(sys_get_temp_dir(), 'docx_');
    file_put_contents($tmp, $bin);
    $text = '';
    if (class_exists('ZipArchive')) {
        $z = new ZipArchive();
        if ($z->open($tmp) === true) {
            $xml = $z->getFromName('word/document.xml'); $z->close();
            if ($xml) { $xml = preg_replace('/<w:p[ >]/', "\n", $xml); $text = strip_tags($xml); }
        }
    }
    @unlink($tmp);
    return trim($text);
}
