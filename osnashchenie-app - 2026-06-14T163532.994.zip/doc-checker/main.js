/**
 * doc-checker/main.js v4 — ЕДИНЫЙ файл без ES-импортов
 * Режим: Alice AI через handler.php
 * PDF.js постранично; сканы → Yandex Vision OCR через handler.php (action=ocr)
 * Все модули (core, ui, pdf-processor) встроены в один файл.
 * Экспорт: HTML (скачать), Excel (SheetJS), PDF (window.print)
 */

// ════════════════════════════════════════════════════════════════════════
// ЧАСТЬ 1: PDF-PROCESSOR
// ════════════════════════════════════════════════════════════════════════

const PDFJS_URLS = [
  './libs/pdf.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',
  'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js',
  'https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.min.js',
];
const PDFJS_WORKER_URLS = [
  './libs/pdf.worker.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',
  'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js',
  'https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js',
];

let _pdfjsLoaded = false;

async function loadPDFJS() {
  if (_pdfjsLoaded && window.pdfjsLib) return window.pdfjsLib;
  if (window.pdfjsLib) { _pdfjsLoaded = true; return window.pdfjsLib; }

  for (const url of PDFJS_URLS) {
    try {
      await loadScript(url);
      if (window.pdfjsLib) break;
    } catch { /* try next */ }
  }

  if (!window.pdfjsLib) throw new Error('PDF.js не удалось загрузить');

  for (const wurl of PDFJS_WORKER_URLS) {
    try {
      const resp = await fetch(wurl, { method: 'HEAD', cache: 'no-store' });
      if (resp.ok) { window.pdfjsLib.GlobalWorkerOptions.workerSrc = wurl; break; }
    } catch { /* try next */ }
  }
  if (!window.pdfjsLib.GlobalWorkerOptions.workerSrc) {
    window.pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER_URLS[1];
  }

  _pdfjsLoaded = true;
  return window.pdfjsLib;
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector('script[src="' + src + '"]')) { resolve(); return; }
    const s = document.createElement('script');
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error('Не удалось загрузить: ' + src));
    document.head.appendChild(s);
  });
}

async function extractPdfPages(file) {
  const pdfjsLib = await loadPDFJS();
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;

  const result = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const pageText = textContent.items.map(item => item.str).join(' ').replace(/\s{3,}/g, '  ').trim();
    const hasText = pageText.replace(/\s/g, '').length > 30;

    let canvasData = null;
    if (!hasText) {
      const viewport = page.getViewport({ scale: 2.0 });
      canvasData = {
        width: viewport.width,
        height: viewport.height,
        render: async (canvas) => {
          canvas.width  = viewport.width;
          canvas.height = viewport.height;
          await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
        },
      };
    }
    result.push({ text: pageText, canvasData });
  }
  return result;
}

async function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      resolve({ base64: dataUrl.split(',')[1], mediaType: file.type || guessMimeType(file.name) });
    };
    reader.onerror = () => reject(new Error('Ошибка чтения: ' + file.name));
    reader.readAsDataURL(file);
  });
}

function guessMimeType(filename) {
  const ext = filename.toLowerCase().split('.').pop();
  return ({ pdf:'application/pdf', docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    doc:'application/msword', xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    xls:'application/vnd.ms-excel', txt:'text/plain', csv:'text/csv', md:'text/markdown',
    png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg' })[ext] || 'application/octet-stream';
}

function getFileType(filename) {
  const realExt = filename.toLowerCase().split('.').pop();
  return ({ pdf:'pdf', docx:'docx', doc:'docx', xlsx:'xlsx', xls:'xlsx',
    txt:'txt', md:'txt', csv:'txt', png:'image', jpg:'image', jpeg:'image' })[realExt] || 'unknown';
}

async function extractExcelAsText(file) {
  if (!window.XLSX) {
    for (const url of [
      'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js',
      'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js',
      'https://unpkg.com/xlsx@0.18.5/dist/xlsx.full.min.js',
    ]) {
      try { await loadScript(url); if (window.XLSX) break; } catch { /* */ }
    }
  }
  const data = await file.arrayBuffer();
  const wb   = window.XLSX.read(data, { type: 'array' });
  const lines = [];
  wb.SheetNames.forEach(name => {
    lines.push('\n=== Лист: ' + name + ' ===\n');
    lines.push(window.XLSX.utils.sheet_to_csv(wb.Sheets[name], { blankrows: false }));
  });
  return lines.join('\n');
}

// ════════════════════════════════════════════════════════════════════════
// ЧАСТЬ 2: CORE
// ════════════════════════════════════════════════════════════════════════

function getProxyUrl() {
  const loc = window.location;
  if (loc.protocol === 'file:') return 'https://mto-cto.falcon28.ru/doc-checker/api/handler.php';
  const dir = loc.origin + loc.pathname.replace(/\/[^/]*$/, '/');
  return dir + 'api/handler.php';
}

// ── Yandex Object Storage helpers ──────────────────────────────────────────────

let _storageEnabled = null; // null=не проверяли, true=доступен, false=нет

async function checkStorageEnabled() {
  if (_storageEnabled !== null) return _storageEnabled;
  try {
    const resp = await fetch(getProxyUrl(), {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'storage_status' }),
    });
    if (!resp.ok) { _storageEnabled = false; return false; }
    const data = await resp.json();
    _storageEnabled = !!(data.enabled);
    console.log('[Storage]', _storageEnabled ? '✅ Включён, бакет: ' + data.bucket : '⬜ Отключён (' + (data.reason || '') + ')');
  } catch {
    _storageEnabled = false;
  }
  updateStorageBadge();
  return _storageEnabled;
}

function updateStorageBadge() {
  const el = document.getElementById('storageBadge');
  if (!el) return;
  if (_storageEnabled === true) {
    el.innerHTML = '☁️ <span style="color:#34d399">Object Storage</span> — нативное чтение PDF';
    el.title = 'PDF файлы временно загружаются в Yandex Object Storage и удаляются после анализа';
  } else if (_storageEnabled === false) {
    el.innerHTML = '📄 PDF.js + Yandex Vision OCR';
    el.title = 'Object Storage не настроен. PDF читается через PDF.js. Сканы — через Yandex Vision OCR.';
  } else {
    el.innerHTML = '⏳ Проверка Storage...';
  }
}

/**
 * Загружает PDF-файл в Yandex Object Storage через handler.php.
 * Возвращает { key, url } или null при ошибке.
 */
async function uploadFileToStorage(f, onProgress) {
  try {
    onProgress?.('☁️ Загрузка в Storage: ' + f.name);
    const { base64, mediaType } = await fileToBase64(f.file);
    const resp = await fetch(getProxyUrl(), {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'upload_to_storage', filename: f.name, base64, mediaType }),
    });
    const data = await resp.json();
    if (!resp.ok || data.error) {
      console.warn('[Storage] Ошибка загрузки', f.name, data.error || resp.status);
      return null;
    }
    console.log('[Storage] Загружен:', f.name, '→', data.key);
    return { key: data.key, url: data.url };
  } catch (err) {
    console.warn('[Storage] Исключение при загрузке', f.name, err);
    return null;
  }
}

/**
 * Удаляет объект из Object Storage (вызывается после анализа).
 */
async function deleteFromStorage(key) {
  if (!key) return;
  try {
    await fetch(getProxyUrl(), {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'delete_from_storage', key }),
    });
    console.log('[Storage] Удалён:', key);
  } catch (err) {
    console.warn('[Storage] Ошибка удаления', key, err);
  }
}

const DOC_TYPES = {
  upd:               { label: 'УПД',                       icon: '📄', zone: 1 },
  invoice:           { label: 'Счёт',                      icon: '💰', zone: 1 },
  contract:          { label: 'Договор',                   icon: '📋', zone: 2 },
  specification:     { label: 'Спецификация / ТЗ',         icon: '📐', zone: 2 },
  waybill:           { label: 'Накладная (ТОРГ-12)',        icon: '🚚', zone: 3 },
  act_commissioning: { label: 'Акт приёмки / комиссии',    icon: '✅', zone: 3 },
  registry:          { label: 'Сводный реестр',            icon: '📊', zone: 3 },
  advance_invoice:   { label: 'Авансовый счёт',            icon: '💳', zone: 3 },
  inspection_act:    { label: 'Акт проверки',              icon: '🔍', zone: 4 },
  claim:             { label: 'Претензия',                 icon: '⚠️', zone: 4 },
  rename_act:        { label: 'Акт переименования',        icon: '🏷️', zone: 4 },
  certificate:       { label: 'Сертификат',                icon: '🏆', zone: 4 },
  declaration:       { label: 'Декларация соответствия',   icon: '🔖', zone: 4 },
  warranty:          { label: 'Гарантийный талон',         icon: '🛡️', zone: 4 },
  memo:              { label: 'Служебная записка',         icon: '📝', zone: 4 },
  other:             { label: 'Иной документ',             icon: '📎', zone: 4 },
};

function getTypeLabel(type) { return DOC_TYPES[type]?.label || type || 'Документ'; }
function getTypeIcon(type)  { return DOC_TYPES[type]?.icon  || '📎'; }

function detectDocType(filename, text) {
  const cleanName = (filename || '').replace(/(\.\w{2,5})+$/i, '').toLowerCase();
  const n = (cleanName + ' ' + (text || '')).toLowerCase();
  if (/упд|универсальный передаточный/.test(n))                         return 'upd';
  if (/счёт-фактура|счет-фактура/.test(n))                              return 'upd';
  if (/авансов/.test(n))                                                return 'advance_invoice';
  if (/\bсчёт\b|\bсчет\b/.test(n) && !/фактур/.test(n))                return 'invoice';
  if (/договор|контракт/.test(n))                                       return 'contract';
  if (/техническое задание|тех\.?\s*задание|\bтз\b|спецификац/.test(n)) return 'specification';
  if (/торг-?12|накладная|товарная/.test(n))                            return 'waybill';
  if (/акт ввода|ввод в эксплуатацию|акт приёма|акт приема/.test(n))   return 'act_commissioning';
  if (/акт комиссии|комиссионн|приёмочн|приемочн|акт приёмки|акт приемки/.test(n)) return 'act_commissioning';
  if (/реестр/.test(n))                                                 return 'registry';
  if (/акт проверк|проверочн/.test(n))                                  return 'inspection_act';
  if (/претензи/.test(n))                                               return 'claim';
  if (/переименован/.test(n))                                           return 'rename_act';
  if (/сертификат/.test(n))                                             return 'certificate';
  if (/деклараци/.test(n))                                              return 'declaration';
  if (/гарантийн|гарантийный талон|гарант\.?\s*талон/.test(n))         return 'warranty';
  if (/служебная записка|служ\.?\s*записк/.test(n))                     return 'memo';
  return 'other';
}

async function callAI({ messages, system, maxTokens, onProgress }) {
  const MAX_RETRIES = 2;
  let lastErr;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const payload = { action: 'analyze', max_tokens: maxTokens || 12000, messages };
      if (system) payload.system = system;
      const resp = await fetch(getProxyUrl(), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const text = await resp.text();
      let data;
      try { data = JSON.parse(text); } catch { throw new Error('Сервер вернул не JSON: ' + text.slice(0, 200)); }
      if (!resp.ok) {
        const errMsg = typeof data?.error === 'string' ? data.error : data?.error?.message || JSON.stringify(data);
        if (resp.status === 429 || resp.status === 529) {
          const wait = attempt * 20;
          onProgress?.('Лимит API, пауза ' + wait + ' сек...');
          await sleep(wait * 1000);
          lastErr = new Error(errMsg); continue;
        }
        throw new Error('API ошибка ' + resp.status + ': ' + errMsg);
      }
      const content = data.content?.[0]?.text;
      if (content === undefined) throw new Error('Пустой ответ от модели');
      if (content === '') throw new Error('Модель вернула пустой текст');
      return content;
    } catch (err) {
      lastErr = err;
      if (attempt < MAX_RETRIES) {
        onProgress?.('Ошибка, повтор ' + (attempt + 1) + '/' + MAX_RETRIES + ': ' + err.message.slice(0, 80));
        await sleep(5000 * attempt);
      }
    }
  }
  throw lastErr || new Error('Все попытки исчерпаны');
}

function buildContentBlock(fileObj) {
  const { base64, mediaType, textContent, filename, storageUrl } = fileObj;
  // Если файл загружен в Object Storage — передаём storageUrl для нативного чтения
  if (storageUrl) {
    return { type: 'document', storageUrl, title: filename };
  }
  if (textContent !== undefined && textContent !== null) {
    return { type: 'document', source: { type: 'text', data: textContent }, title: filename };
  }
  if (mediaType && mediaType.startsWith('image/')) {
    return { type: 'image', source: { type: 'base64', media_type: mediaType, data: base64 } };
  }
  return { type: 'document', source: { type: 'base64', media_type: mediaType || 'application/octet-stream', data: base64 }, title: filename };
}

const SYSTEM_PROMPT = 'Ты — опытный специалист по проверке первичной бухгалтерской документации и документов в сфере государственных закупок.\n\nТебе передают пакет документов для проверки перед оплатой поставщику. Документы распределены по зонам:\n- ЗОНА 1: документ на оплату (УПД, счёт, счёт-фактура или аналог)\n- ЗОНА 2: договор и техническое задание (эталон для сверки реквизитов, наименований, цен)\n- ЗОНА 3: первичная документация (товарные накладные, акты ввода в эксплуатацию, ТОРГ-12, ТТН, сводный реестр накладных)\n- ЗОНА 4: дополнительные документы (акты проверок, акты комиссии по приёмке, претензии, сертификаты, декларации, гарантийные талоны, служебные записки, акты переименования, авансовый счёт)\n\nДокумент считается тем, чем он является по зоне — вне зависимости от его названия или типа.\nАкт комиссии по приёмке — это первичный документ (зона 3 или 4), подтверждающий приёмку товара.\nГарантийный талон — это дополнительный документ (зона 4), подтверждающий гарантийные обязательства.\n\nОБЯЗАТЕЛЬНЫЙ ФОРМАТ ОТВЕТА: верни ТОЛЬКО валидный JSON без markdown-блоков, без пояснений до и после.\n\nСТРУКТУРА JSON:\n{\n  "paymentDoc": {\n    "docType": "тип документа (УПД / Счёт / Счёт-фактура / Акт КС-2 и т.д.)",\n    "name": "наименование и номер документа",\n    "date": "дата документа ДД.ММ.ГГГГ",\n    "inn_supplier": "ИНН поставщика",\n    "name_supplier": "наименование поставщика",\n    "inn_buyer": "ИНН покупателя",\n    "name_buyer": "наименование покупателя",\n    "contract_ref": "ссылка на договор (номер, дата) если указана",\n    "items": [\n      {\n        "num": 1,\n        "name": "наименование товара/работы/услуги",\n        "unit": "ед.изм",\n        "qty": 0,\n        "price": 0,\n        "amountNoVat": 0,\n        "vatRate": "ставка НДС строкой: 20%, 10%, 0%, без НДС",\n        "vat": 0,\n        "amountWithVat": 0\n      }\n    ],\n    "total": { "qty": 0, "amountNoVat": 0, "vat": 0, "amountWithVat": 0 },\n    "issues": ["список замечаний по самому документу"]\n  },\n\n  "contract": {\n    "found": true,\n    "number": "номер договора",\n    "date": "дата договора",\n    "inn_supplier": "ИНН поставщика по договору",\n    "inn_buyer": "ИНН покупателя по договору",\n    "totalAmount": null,\n    "advancePct": null,\n    "deliveryDeadline": "срок поставки",\n    "items": [\n      { "name": "наименование по договору/ТЗ", "qty": null, "price": null }\n    ]\n  },\n\n  "primaryDocs": [\n    {\n      "docType": "тип документа (ТОРГ-12 / Акт ввода в эксплуатацию / ТТН / Реестр и т.д.)",\n      "name": "наименование и номер документа",\n      "date": "дата ДД.ММ.ГГГГ",\n      "recipient": "наименование и адрес получателя если указан",\n      "items": [\n        {\n          "num": 1,\n          "name": "наименование товара",\n          "unit": "ед.изм",\n          "qty": null,\n          "price": null,\n          "amountNoVat": null,\n          "vatRate": "ставка НДС",\n          "vat": null,\n          "amountWithVat": null\n        }\n      ],\n      "total": { "qty": null, "amountNoVat": 0, "vat": 0, "amountWithVat": 0 },\n      "issues": ["список замечаний по документу"]\n    }\n  ],\n\n  "aggregate": {\n    "items": [\n      {\n        "name": "наименование товара (как в документе на оплату)",\n        "unit": "ед.изм",\n        "qty": 0,\n        "amountNoVat": 0,\n        "vat": 0,\n        "amountWithVat": 0\n      }\n    ],\n    "total": { "qty": 0, "amountNoVat": 0, "vat": 0, "amountWithVat": 0 }\n  },\n\n  "comparison": {\n    "qtyMatch": true,\n    "amountNoVatMatch": true,\n    "vatMatch": true,\n    "amountWithVatMatch": true,\n    "diff_qty": 0,\n    "diff_amountNoVat": 0,\n    "diff_vat": 0,\n    "diff_amountWithVat": 0,\n    "problematicDocs": ["список первичных документов с расхождениями"],\n    "recommendation": "рекомендация: какой документ скорректировать и как"\n  },\n\n  "extraDocs": [\n    {\n      "docType": "тип документа (Сертификат / Декларация / Гарантийный талон / Служебная записка / Акт проверки / Акт комиссии по приёмке / Претензия / Акт переименования / Авансовый счёт и т.д.)",\n      "name": "наименование документа",\n      "date": "дата или null",\n      "expiryDate": "срок действия или null",\n      "productName": "наименование товара в документе или null",\n      "qty": "количество товара в документе или null",\n      "hasStamp": null,\n      "hasSignature": null,\n      "matchesContract": null,\n      "items": [],\n      "total": { "qty": null },\n      "issues": ["список замечаний"]\n    }\n  ],\n\n  "chronology": [\n    {\n      "date": "ДД.ММ.ГГГГ",\n      "docName": "наименование документа",\n      "event": "краткое описание события"\n    }\n  ],\n\n  "rekvizity": {\n    "supplierInnConsistent": true,\n    "buyerInnConsistent": true,\n    "supplierNameConsistent": true,\n    "inconsistencies": ["описание расхождений реквизитов"]\n  },\n\n  "unreadableData": [\n    {\n      "docName": "наименование документа",\n      "location": "место в документе (строка, колонка, страница)",\n      "description": "что именно нечитаемо"\n    }\n  ],\n\n  "violations": [\n    {\n      "severity": "critical|significant|minor",\n      "category": "суммы|реквизиты|хронология|наименования|подписи|сертификаты|претензии|прочее",\n      "docName": "документ, в котором обнаружено нарушение",\n      "text": "подробное описание нарушения с конкретными числами, датами, полями"\n    }\n  ],\n\n  "conclusion": "итоговое заключение: можно ли направить пакет на оплату, что мешает",\n  "actionRequired": ["конкретное действие 1", "конкретное действие 2"]\n}\n\nПРАВИЛА РАБОТЫ С ЧИСЛАМИ:\n- Все числа записывай ТОЧНО как в документе, без округления и без потери знаков\n- Цена может быть длинной дробью: например 238352.3105269930 — записывай именно так\n- Коды ОКПД2 (формат X.XX.XX.XXX, например 32.99.53.139) — это код товара, НИКОГДА не цена и не часть числа\n- PDF-парсер может разбивать числа на части через пробел или перенос строки:\n  «238 352,310» + «52699367» на следующей строке = одно число 238352.31052699367\n  Всегда верифицируй: qty × price = amountNoVat (с точностью до копейки)\n- Длинные последовательности цифр после запятой (>4 знаков) — продолжение числа, не отдельное значение\n- Пробелы в числах (1 000 000) — разделители разрядов\n- Запятая в числах — десятичный разделитель (российский формат)\n\nПРАВИЛА АНАЛИЗА:\n1. РЕКВИЗИТЫ — ИНН поставщика и покупателя должны совпадать во всех документах; наименования сторон должны совпадать с договором; банковские реквизиты (р/с, БИК, банк, к/с) в УПД должны совпадать с реквизитами в договоре\n2. СУММЫ — арифметика внутри каждого документа: qty × price = amountNoVat; сумма всех первичных = сумме документа на оплату\n3. ХРОНОЛОГИЯ — первичные документы не могут быть датированы позже УПД; сертификаты не должны быть просрочены; нормальная последовательность: договор → первичные документы → УПД (первичные раньше УПД — это норма); НЕ считать нарушением если первичные датированы раньше УПД\n4. НАИМЕНОВАНИЯ — все варианты наименования товара во всех документах должны совпадать с договором; если в акте комиссии несколько вариантов наименования — это нарушение; учитывай регистр и транслитерацию (UNIMAT = Unimat)\n5. ПОЛЕ 8 (идентификатор госконтракта) — в УПД обязательно должен быть заполнен идентификатор государственного контракта (поле 8); отсутствие или незаполненность — существенное замечание\n6. СТРАНА ПРОИСХОЖДЕНИЯ — в первичных документах и акте комиссии должна быть указана страна происхождения товара; если указано несколько стран (например, Австрия и Китай) — это нарушение, требующее уточнения\n7. ВНУТРЕННЯЯ СОГЛАСОВАННОСТЬ — все даты, номера, суммы и наименования внутри каждого документа должны быть согласованы между собой; несоответствие данных в разных частях одного документа — нарушение\n8. ДОПОЛНИТЕЛЬНЫЕ ДОКУМЕНТЫ — акт комиссии: сравни количество и наименования с документом на оплату; гарантийный талон: сравни количество, проверь срок гарантии; все позиции акта комиссии должны быть проверены\n9. НДС — ставка НДС 22% является базовой ставкой с 2025 года и НЕ является нарушением; ставки 20%, 10%, 0% также допустимы в зависимости от категории товара\n10. СТЕПЕНИ НАРУШЕНИЙ — critical: блокирует оплату; significant: требует исправления; minor: рекомендуется исправить\n\nОтвечай ТОЛЬКО JSON, никакого текста вокруг.';

async function analyzePackage(files, onProgress, extraInstructions, userPatternsPrompt) {
  onProgress?.('Alice AI LLM: читает все документы пакета...');

  const ZONE_LABELS = {
    1: 'ЗОНА 1 — Документ на оплату (УПД, счёт-фактура)',
    2: 'ЗОНА 2 — Договор и техническое задание',
    3: 'ЗОНА 3 — Первичные документы (накладные, акты)',
    4: 'ЗОНА 4 — Дополнительные документы (сертификаты, акты комиссии, гарантии)',
  };

  const zoneGroups = { 1: [], 2: [], 3: [], 4: [] };
  files.forEach(f => (zoneGroups[f.zone] = zoneGroups[f.zone] || []).push(f));

  let intro = 'Проверь весь пакет документов и верни JSON по указанной структуре.\n\nСостав пакета:\n';
  for (const z of [1, 2, 3, 4]) {
    const grp = zoneGroups[z] || [];
    if (!grp.length) continue;
    intro += '\n' + ZONE_LABELS[z] + ':\n';
    grp.forEach((f, i) => { intro += '  ' + (i + 1) + '. ' + f.name + '\n'; });
  }
  if (extraInstructions) intro += '\nДОПОЛНИТЕЛЬНЫЕ ИНСТРУКЦИИ:\n' + extraInstructions + '\n';
  intro += '\nОтвечай ТОЛЬКО JSON, никакого текста вокруг.';

  const content = [{ type: 'text', text: intro }];
  for (const z of [1, 2, 3, 4]) {
    for (const f of (zoneGroups[z] || [])) {
      content.push(buildContentBlock(f));
    }
  }

  const systemPrompt = SYSTEM_PROMPT + (userPatternsPrompt ? '\n\nПАТТЕРНЫ ПОЛЬЗОВАТЕЛЯ:\n' + userPatternsPrompt : '');

  const raw = await callAI({
    messages: [{ role: 'user', content }],
    system: systemPrompt,
    maxTokens: 12000,
    onProgress,
  });

  const data = extractJSON(raw);
  if (!data) console.warn('[core] Alice AI вернул не-JSON:', raw.slice(0, 400));

  const issues = data ? programmaticCheck(data, files) : [];
  return { data, issues, rawText: raw };
}

function programmaticCheck(data, files) {
  const issues = [...(data.violations || [])];
  const push = (category, severity, text) => {
    const dup = issues.some(i => i.text && i.text.includes(text.slice(0, 40)));
    if (!dup) issues.push({ category, severity, text });
  };

  const pd        = data.paymentDoc;
  const primaries = data.primaryDocs || [];
  const extras    = data.extraDocs   || [];
  const contract  = data.contract    || {};

  if (pd?.items?.length) {
    pd.items.forEach((item, i) => {
      if (!item.qty || !item.price) return;
      const expected = round2(item.qty * item.price);
      const actual   = round2(item.amountNoVat || 0);
      if (actual > 0 && Math.abs(expected - actual) > 0.02) {
        push('Арифметика', 'critical',
          'Документ на оплату, строка ' + (i + 1) + ' «' + (item.name || '') + '»: ' +
          fmtNum(item.qty) + ' × ' + fmtNum(item.price) + ' = ' + fmtNum(expected) +
          ', указано ' + fmtNum(actual));
      }
    });
  }

  primaries.forEach(doc => {
    (doc.items || []).forEach((item, i) => {
      if (!item.qty || !item.price) return;
      const expected = round2(item.qty * item.price);
      const actual   = round2(item.amountNoVat || 0);
      if (actual > 0 && Math.abs(expected - actual) > 0.02) {
        push('Арифметика', 'critical',
          '«' + (doc.name || '') + '», строка ' + (i + 1) + ': ' +
          fmtNum(item.qty) + ' × ' + fmtNum(item.price) + ' = ' + fmtNum(expected) +
          ', указано ' + fmtNum(actual));
      }
    });
  });

  if (pd?.total && primaries.length > 0) {
    const primQty = round2(primaries.reduce((s, p) => s + (Number(p.total?.qty) || 0), 0));
    const pdQty   = round2(pd.total.qty || 0);
    const qtyDiff = round2(Math.abs(pdQty - primQty));
    if (pdQty > 0 && primQty > 0 && qtyDiff > 0.01) {
      push('Количество', 'critical',
        'Суммарное количество в первичных документах (' + fmtNum(primQty) + ' шт. по ' + primaries.length + ' документам) \u2260 документу на оплату (' +
        fmtNum(pdQty) + ' шт.). Не подтверждено первичными: ' + fmtNum(qtyDiff) + ' шт.');
    }
    if (qtyDiff <= 0.01) {
      const primTotal = round2(primaries.reduce((s, p) => s + (Number(p.total?.amountWithVat) || 0), 0));
      const pdTotal   = round2(pd.total.amountWithVat || 0);
      if (pdTotal > 0 && primTotal > 0) {
        const diff = round2(Math.abs(pdTotal - primTotal));
        if (diff > 0.02) {
          push('Сверка с УПД', 'critical',
            'Итоговая сумма первичных документов с НДС (' + fmtNum(primTotal) + ' руб.) \u2260 документу на оплату (' +
            fmtNum(pdTotal) + ' руб.). Расхождение: ' + fmtNum(diff) + ' руб.');
        }
      }
    }
  }

  if (pd?.inn_supplier && contract?.inn_supplier) {
    const a = normalizeINN(pd.inn_supplier), b = normalizeINN(contract.inn_supplier);
    if (a && b && a !== b) push('Реквизиты', 'critical', 'ИНН поставщика в документе на оплату (' + a + ') ≠ договору (' + b + ')');
  }

  if (pd?.date) {
    const updDate = parseRuDate(pd.date);
    primaries.forEach(p => {
      const pDate = parseRuDate(p.date);
      if (pDate && updDate && pDate > updDate) {
        push('хронология', 'critical', 'Дата «' + (p.name || '') + '» (' + p.date + ') позже даты документа на оплату (' + pd.date + ')');
      }
    });
  }

  extras.filter(e => {
    const dt = (e.docType || '').toLowerCase();
    return dt.includes('сертификат') || dt.includes('деклараци');
  }).forEach(cert => {
    const validUntil = parseRuDate(cert.expiryDate || cert.valid_until);
    if (validUntil && validUntil < new Date()) {
      push('сертификаты', 'critical', 'Срок действия «' + (cert.name || '') + '» истёк ' + (cert.expiryDate || cert.valid_until));
    }
  });

  const commissionActs = [...primaries, ...extras].filter(e => {
    const dt = (e.docType || '').toLowerCase();
    const nm = (e.name || '').toLowerCase();
    return dt.includes('commissioning') || /акт комиссии|акт приёмки|акт приемки|комиссионн/.test(nm);
  });
  commissionActs.forEach(act => {
    const actQty = Number(act.total?.qty || act.qty || (act.items?.reduce((s, it) => s + (Number(it.qty) || 0), 0)) || 0);
    const pdQty  = Number(pd?.total?.qty || 0);
    if (actQty > 0 && pdQty > 0 && Math.abs(actQty - pdQty) > 0.01) {
      push('Акт комиссии', actQty < pdQty ? 'significant' : 'minor',
        'Акт комиссии «' + (act.name || '') + '» подтверждает приёмку ' + fmtNum(actQty) +
        ' шт., тогда как документ на оплату — ' + fmtNum(pdQty) + ' шт. Расхождение: ' + fmtNum(Math.abs(pdQty - actQty)) + ' шт.');
    }
  });

  const warrantyDocs = extras.filter(e => {
    const dt = (e.docType || '').toLowerCase();
    return dt.includes('warranty') || /гарантийн/.test((e.name || '').toLowerCase());
  });
  warrantyDocs.forEach(w => {
    const wQty  = Number(w.total?.qty || w.qty || (w.items?.reduce((s, it) => s + (Number(it.qty) || 0), 0)) || 0);
    const pdQty = Number(pd?.total?.qty || 0);
    if (wQty > 0 && pdQty > 0 && Math.abs(wQty - pdQty) > 0.01) {
      push('Гарантийный талон', 'significant',
        'Гарантийный талон «' + (w.name || '') + '» выписан на ' + fmtNum(wQty) +
        ' шт., тогда как документ на оплату — на ' + fmtNum(pdQty) + ' шт. Расхождение: ' + fmtNum(Math.abs(wQty - pdQty)) + ' шт.');
    }
  });

  if (data.unreadableData?.length) {
    data.unreadableData.forEach(u => {
      push('прочее', 'minor', 'Нечитаемые данные в «' + (u.docName || '') + '» (' + (u.location || '') + '): ' + (u.description || ''));
    });
  }

  if (data.rekvizity?.inconsistencies?.length) {
    data.rekvizity.inconsistencies.forEach(inc => { push('реквизиты', 'significant', inc); });
  }

  return issues;
}

function buildConclusionText(data, issues) {
  const critCount = issues.filter(i => i.severity === 'critical').length;
  const sigCount  = issues.filter(i => i.severity === 'significant').length;
  let text = '';
  if (data?.conclusion) text += '## Заключение\n\n' + data.conclusion + '\n\n';
  if (critCount > 0) {
    text += '## Критические нарушения (' + critCount + ')\n\n';
    issues.filter(i => i.severity === 'critical').forEach(v => { text += '- 🔴 ' + v.text + '\n'; });
  }
  if (sigCount > 0) {
    text += '\n## Существенные замечания (' + sigCount + ')\n\n';
    issues.filter(i => i.severity === 'significant').forEach(v => { text += '- 🟠 ' + v.text + '\n'; });
  }
  if (data?.actionRequired?.length) {
    text += '\n## Необходимые действия\n\n';
    data.actionRequired.forEach((a, i) => { text += (i + 1) + '. ' + a + '\n'; });
  }
  return text || 'Анализ завершён. Нарушений не выявлено.';
}

async function generateConclusion(data, issues) {
  return buildConclusionText(data, issues);
}

function buildSummaryTableData(data) {
  if (!data) return [];
  const sections = [];
  if (data.paymentDoc) {
    const pd = data.paymentDoc;
    sections.push({
      kind: 'payment', label: 'Документ на оплату: ' + (pd.name || ''),
      docType: pd.docType, docDate: pd.date,
      seller: { name: pd.name_supplier, inn: pd.inn_supplier },
      buyer:  { name: pd.name_buyer,    inn: pd.inn_buyer },
      contractRef: pd.contract_ref,
      items: (pd.items || []).map(it => ({ name: it.name, unit: it.unit, qty: it.qty, price: it.price, amount: it.amountNoVat, vatRate: it.vatRate, vat_amount: it.vat, total: it.amountWithVat })),
      totals: { amount_no_vat: pd.total?.amountNoVat, vat_amount: pd.total?.vat, amount_with_vat: pd.total?.amountWithVat, qty_total: pd.total?.qty },
      docIssues: pd.issues || [],
    });
  }
  (data.primaryDocs || []).forEach((p, i) => {
    sections.push({
      kind: 'primary', label: 'Первичный документ ' + (i + 1) + ': ' + (p.name || ''),
      docType: p.docType, docDate: p.date, recipient: p.recipient,
      seller: {}, buyer: {},
      items: (p.items || []).map(it => ({ name: it.name, unit: it.unit, qty: it.qty, price: it.price, amount: it.amountNoVat, vatRate: it.vatRate, vat_amount: it.vat, total: it.amountWithVat })),
      totals: { amount_no_vat: p.total?.amountNoVat, vat_amount: p.total?.vat, amount_with_vat: p.total?.amountWithVat, qty_total: p.total?.qty },
      docIssues: p.issues || [],
    });
  });
  if (data.aggregate) {
    const agg = data.aggregate;
    sections.push({
      kind: 'aggregate', label: 'По сумме первичных документов',
      items: (agg.items || []).map(it => ({ name: it.name, unit: it.unit, qty: it.qty, amount: it.amountNoVat, vat_amount: it.vat, total: it.amountWithVat })),
      totals: { amount_no_vat: agg.total?.amountNoVat, vat_amount: agg.total?.vat, amount_with_vat: agg.total?.amountWithVat, qty_total: agg.total?.qty },
      compareWith: data.paymentDoc?.total ? { amount_no_vat: data.paymentDoc.total.amountNoVat, vat_amount: data.paymentDoc.total.vat, amount_with_vat: data.paymentDoc.total.amountWithVat } : null,
    });
  }
  (data.extraDocs || []).forEach(e => {
    sections.push({
      kind: 'extra', label: (e.name || e.docType || 'Доп. документ'),
      docType: e.docType || 'other', docDate: e.date, validUntil: e.expiryDate,
      productName: e.productName, hasStamp: e.hasStamp, hasSignature: e.hasSignature,
      matchesContract: e.matchesContract, docIssues: e.issues || [], items: [], totals: {},
    });
  });
  return sections;
}

// Утилиты
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function xmlEsc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function colLetter(n) {
  let s = '';
  n++;
  while (n > 0) { n--; s = String.fromCharCode(65 + (n % 26)) + s; n = Math.floor(n / 26); }
  return s;
}

function parseNum(v) {
  if (v == null || v === '') return null;
  const n = parseFloat(String(v).replace(/\s/g,'').replace(',','.'));
  return isNaN(n) ? null : n;
}

async function ensureJSZip() {
  if (window.JSZip) return window.JSZip;
  const urls = [
    './libs/jszip.min.js',
    'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',
    'https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js',
    'https://unpkg.com/jszip@3.10.1/dist/jszip.min.js',
  ];
  for (const url of urls) {
    try { await loadScript(url); if (window.JSZip) return window.JSZip; } catch { /* */ }
  }
  throw new Error('JSZip не удалось загрузить');
}

function extractJSON(text) {
  if (!text) return null;

  // 1. Прямой парсинг
  try { return JSON.parse(text.trim()); } catch { /* */ }

  // 2. Убрать markdown-блок (``` или ```json), с закрывающим или без
  const stripped = text
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```\s*$/, '')
    .trim();
  try { return JSON.parse(stripped); } catch { /* */ }

  // 3. Найти первый { и последний }
  const start = text.indexOf('{');
  if (start === -1) return null;
  const end = text.lastIndexOf('}');
  if (end > start) {
    try { return JSON.parse(text.slice(start, end + 1)); } catch { /* */ }
  }

  // 4. JSON обрезан — пытаемся починить
  const raw = (end > start ? text.slice(start, end + 1) : text.slice(start));
  try { return JSON.parse(repairTruncatedJSON(raw)); } catch { /* */ }

  return null;
}

function repairTruncatedJSON(raw) {
  let s = raw.trimEnd();
  // Ищем последнюю полностью закрытую структуру
  let depth = 0, inStr = false, escape = false, lastSafe = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (escape) { escape = false; continue; }
    if (c === '\\' && inStr) { escape = true; continue; }
    if (c === '"') { inStr = !inStr; continue; }
    if (inStr) continue;
    if (c === '{' || c === '[') depth++;
    if (c === '}' || c === ']') { depth--; if (depth === 0) lastSafe = i + 1; }
  }
  if (lastSafe > 1) { try { JSON.parse(s.slice(0, lastSafe)); return s.slice(0, lastSafe); } catch { /* */ } }
  // Принудительно закрываем незакрытые скобки
  const lastComma = s.lastIndexOf(',');
  if (lastComma > 0) s = s.slice(0, lastComma);
  const stack = [];
  inStr = false; escape = false;
  for (const c of s) {
    if (escape) { escape = false; continue; }
    if (c === '\\' && inStr) { escape = true; continue; }
    if (c === '"') { inStr = !inStr; continue; }
    if (inStr) continue;
    if (c === '{') stack.push('}');
    if (c === '[') stack.push(']');
    if (c === '}' || c === ']') stack.pop();
  }
  return s + stack.reverse().join('');
}

function normalizeINN(inn) {
  if (!inn) return null;
  return String(inn).replace(/[\s\-]/g, '').trim();
}

function round2(v) { return Math.round((Number(v) || 0) * 100) / 100; }

function parseRuDate(str) {
  if (!str) return null;
  const m = String(str).match(/(\d{1,2})[.\-\/](\d{1,2})[.\-\/](\d{2,4})/);
  if (!m) return null;
  const y = m[3].length === 2 ? '20' + m[3] : m[3];
  return new Date(y + '-' + m[2].padStart(2, '0') + '-' + m[1].padStart(2, '0'));
}

function fmtNum(n) {
  const num = Number(n);
  if (!isFinite(num)) return '0';
  const str = String(n), dotIdx = str.indexOf('.');
  const srcDecimals = dotIdx >= 0 ? str.length - dotIdx - 1 : 0;
  const decimals = Math.max(2, Math.min(srcDecimals, 10));
  return num.toLocaleString('ru-RU', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

// ════════════════════════════════════════════════════════════════════════
// ЧАСТЬ 3: UI
// ════════════════════════════════════════════════════════════════════════

function escHtml(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function markdownToHtml(md) {
  if (!md) return '';
  return md
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/^### (.+)$/gm,'<h3 class="text-sm font-bold text-cyan-300 mt-5 mb-2 uppercase tracking-wide">$1</h3>')
    .replace(/^## (.+)$/gm,'<h2 class="text-base font-bold text-white mt-6 mb-3 border-b border-white/10 pb-2">$1</h2>')
    .replace(/^# (.+)$/gm,'<h1 class="text-lg font-bold text-cyan-400 mb-4">$1</h1>')
    .replace(/\*\*([^*]+)\*\*/g,'<strong class="text-white font-semibold">$1</strong>')
    .replace(/^(\|.+\|)$/gm, line => {
      const cells = line.split('|').slice(1,-1).map(c=>c.trim());
      if (cells.every(c=>/^[-: ]+$/.test(c))) return '';
      return '<tr>' + cells.map(c=>'<td class="px-3 py-1.5 text-xs border-b border-white/10 text-slate-200">' + c + '</td>').join('') + '</tr>';
    })
    .replace(/((<tr>.*?<\/tr>\n?)+)/gs,'<div class="overflow-x-auto my-3"><table class="w-full border-collapse"><tbody>$1</tbody></table></div>')
    .replace(/^- (.+)$/gm,'<li class="ml-4 text-sm text-slate-300 mb-1">• $1</li>')
    .replace(/^(\d+)\. (.+)$/gm,'<li class="ml-4 text-sm text-slate-300 mb-1">$1. $2</li>')
    .replace(/\n\n/g,'</p><p class="text-sm text-slate-300 mb-2">')
    .replace(/\n/g,'<br>');
}

function showToastMsg(msg, type) {
  type = type || 'info';
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const el = document.createElement('div');
  el.className = 'toast';
  el.style.cssText = 'pointer-events:auto;background:rgba(30,42,58,0.97);border:1px solid ' +
    (type === 'error' ? 'rgba(248,113,113,0.3)' : type === 'success' ? 'rgba(74,222,128,0.3)' : 'rgba(255,255,255,0.1)') +
    ';border-radius:0.75rem;padding:0.6rem 1rem;font-size:0.8rem;color:#e2e8f0;max-width:320px;';
  el.textContent = msg;
  container.appendChild(el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, 3500);
}

function setProgress(pct, stage, detail) {
  const bar = document.getElementById('progressBar');
  const stageEl = document.getElementById('progressStageLabel');
  const detailEl = document.getElementById('progressText');
  if (bar && pct !== null) {
    bar.style.width = pct + '%';
    bar.setAttribute('aria-valuenow', pct);
  }
  if (stageEl && stage) stageEl.textContent = stage;
  if (detailEl && detail !== undefined) detailEl.textContent = detail;
}

function renderDocCards(documents) {
  const wrap = document.getElementById('docCardsWrap');
  if (!wrap) return;
  wrap.innerHTML = documents.map(doc => {
    const icon = getTypeIcon(doc.type);
    const label = getTypeLabel(doc.type);
    const zoneLabel = { 1:'Зона 1', 2:'Зона 2', 3:'Зона 3', 4:'Зона 4' }[doc.zone] || '';
    return '<div class="rounded-xl border border-white/10 bg-white/[0.03] p-3">' +
      '<div class="flex items-center gap-2 mb-1">' +
      '<span class="text-base">' + icon + '</span>' +
      '<span class="text-xs font-semibold text-white truncate">' + escHtml(doc.filename) + '</span>' +
      '<span class="ml-auto shrink-0 text-[10px] px-2 py-0.5 rounded-full bg-cyan-400/10 text-cyan-300">' + label + '</span>' +
      '</div>' +
      '<p class="text-[10px] text-slate-500">' + zoneLabel + '</p>' +
      '</div>';
  }).join('');
}

function renderSummaryTable(summaryData) {
  const wrap = document.getElementById('summaryTableWrap');
  if (!wrap || !summaryData) return;

  const COL_HEADERS = ['Наименование', 'Ед.', 'Кол-во', 'Цена', 'Без НДС', 'НДС', 'С НДС'];

  function fmtCell(v) {
    if (v == null || v === '') return '—';
    const n = parseFloat(String(v).replace(/\s/g,'').replace(',','.'));
    if (isNaN(n)) return escHtml(String(v));
    return n.toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 10 });
  }

  function itemRows(items) {
    return (items || []).map(it => '<tr class="border-b border-white/5">' +
      '<td class="px-2 py-1.5 text-xs text-slate-200 min-w-[160px]">' + escHtml(it.name || '') + '</td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-400 text-center">' + escHtml(it.unit || '') + '</td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-200 text-right">' + fmtCell(it.qty) + '</td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-200 text-right">' + fmtCell(it.price) + '</td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-200 text-right">' + fmtCell(it.amount) + '</td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-400 text-right">' + fmtCell(it.vat_amount) + '</td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-200 text-right">' + fmtCell(it.total) + '</td>' +
      '</tr>').join('');
  }

  function totalRow(totals, highlight) {
    if (!totals) return '';
    const cls = highlight ? 'bg-white/[0.06] font-semibold' : 'bg-white/[0.03]';
    return '<tr class="' + cls + '">' +
      '<td class="px-2 py-1.5 text-xs text-slate-300 font-semibold" colspan="2">Итого</td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-200 text-right font-semibold">' + fmtCell(totals.qty_total) + '</td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-400"></td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-200 text-right font-semibold">' + fmtCell(totals.amount_no_vat) + '</td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-400 text-right">' + fmtCell(totals.vat_amount) + '</td>' +
      '<td class="px-2 py-1.5 text-xs text-slate-200 text-right font-semibold">' + fmtCell(totals.amount_with_vat) + '</td>' +
      '</tr>';
  }

  const SECTION_COLORS = {
    payment:   'rgba(59,130,246,0.18)',
    primary:   'rgba(139,92,246,0.12)',
    aggregate: 'rgba(16,185,129,0.15)',
    extra:     'rgba(245,158,11,0.1)',
  };

  let html = '<div class="overflow-x-auto rounded-xl border border-white/10"><table class="w-full border-collapse text-xs" style="min-width:700px">';
  html += '<thead><tr class="bg-slate-900">' + COL_HEADERS.map(h => '<th class="px-2 py-2 text-left text-[10px] font-semibold uppercase tracking-wide text-slate-500">' + h + '</th>').join('') + '</tr></thead><tbody>';

  summaryData.forEach(section => {
    const bg = SECTION_COLORS[section.kind] || 'rgba(255,255,255,0.03)';
    const label = escHtml(section.label || '');
    const meta = [section.docDate, section.seller?.inn ? 'ИНН пост.: ' + section.seller.inn : '',
      section.buyer?.inn ? 'ИНН пок.: ' + section.buyer.inn : ''].filter(Boolean).join(' · ');

    html += '<tr style="background:' + bg + '"><td colspan="7" class="px-2 py-2 text-xs font-bold text-white border-t border-white/10">' +
      label + (meta ? '<span class="font-normal text-slate-500 ml-2 text-[10px]">' + escHtml(meta) + '</span>' : '') + '</td></tr>';

    if (section.items?.length) {
      html += itemRows(section.items);
      html += totalRow(section.totals, section.kind === 'aggregate');
    }

    if (section.kind === 'extra') {
      const extraInfo = [
        section.productName ? '📦 ' + section.productName : '',
        section.validUntil ? '⏳ До: ' + section.validUntil : '',
        section.hasStamp === false ? '⚠ Нет печати' : '',
        section.hasSignature === false ? '⚠ Нет подписи' : '',
      ].filter(Boolean).join(' · ');
      if (extraInfo) {
        html += '<tr><td colspan="7" class="px-2 py-1 text-[10px] text-slate-500">' + escHtml(extraInfo) + '</td></tr>';
      }
    }

    if (section.compareWith && section.kind === 'aggregate') {
      const pdTotal = section.compareWith.amount_with_vat;
      const aggTotal = section.totals?.amount_with_vat;
      const diff = pdTotal && aggTotal ? Math.abs(Number(pdTotal) - Number(aggTotal)) : null;
      const match = diff !== null && diff < 0.02;
      html += '<tr style="background:' + (match ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)') + '">' +
        '<td colspan="7" class="px-2 py-1.5 text-xs ' + (match ? 'text-green-400' : 'text-red-400') + '">' +
        (match ? '✅ Суммы совпадают с документом на оплату' :
          '❌ Расхождение с документом на оплату: ' + fmtCell(diff) + ' руб.') +
        '</td></tr>';
    }

    if (section.docIssues?.length) {
      section.docIssues.forEach(issue => {
        html += '<tr><td colspan="7" class="px-2 py-1 text-[10px] text-amber-400 bg-amber-500/5">⚠ ' + escHtml(issue) + '</td></tr>';
      });
    }
    // Убрано: не показываем "нет замечаний" когда список пуст
  });

  html += '</tbody></table></div>';
  wrap.innerHTML = html;
}

function renderIssues(issues, onFeedback) {
  const listEl = document.getElementById('issuesList');
  const badgesEl = document.getElementById('issueCountBadges');
  if (!listEl) return;

  const critical    = issues.filter(i => i.severity === 'critical');
  const significant = issues.filter(i => i.severity === 'significant');
  const minor       = issues.filter(i => i.severity === 'minor');

  if (badgesEl) {
    badgesEl.innerHTML = [
      critical.length    ? '<span class="text-[10px] px-2 py-0.5 rounded-full bg-red-500/20 text-red-400">' + critical.length + ' крит.</span>' : '',
      significant.length ? '<span class="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400">' + significant.length + ' сущ.</span>' : '',
      minor.length       ? '<span class="text-[10px] px-2 py-0.5 rounded-full bg-slate-500/20 text-slate-400">' + minor.length + ' мин.</span>' : '',
      !issues.length     ? '<span class="text-[10px] px-2 py-0.5 rounded-full bg-green-500/20 text-green-400">✓ Нарушений нет</span>' : '',
    ].join('');
  }

  if (!issues.length) {
    listEl.innerHTML = '<p class="text-xs text-green-400 py-2">✅ Программных нарушений не выявлено</p>';
    return;
  }

  function issueBlock(list, borderColor, icon, bgColor) {
    return list.map(issue => '<div class="flex gap-2 rounded-lg border ' + borderColor + ' ' + bgColor + ' px-3 py-2 mb-2 text-xs">' +
      '<span class="shrink-0 mt-0.5">' + icon + '</span>' +
      '<div class="min-w-0 flex-1"><p class="text-slate-200 break-words">' + escHtml(issue.text || '') + '</p>' +
      (issue.docName ? '<p class="text-slate-500 text-[10px] mt-0.5">' + escHtml(issue.docName) + (issue.category ? ' · ' + escHtml(issue.category) : '') + '</p>' : '') +
      (onFeedback ? '<button class="issue-feedback-btn mt-1.5 text-[10px] px-2 py-0.5 rounded border border-white/10 bg-white/5 text-slate-400 hover:text-white hover:border-white/20 hover:bg-white/10 transition" data-msg="' + escHtml(issue.text || '') + '">🐛 Сообщить об ошибке</button>' : '') +
      '</div></div>').join('');
  }

  listEl.innerHTML =
    issueBlock(critical,    'border-red-500/20',   '🔴', 'bg-red-500/[0.05]') +
    issueBlock(significant, 'border-amber-500/20', '🟠', 'bg-amber-500/[0.05]') +
    issueBlock(minor,       'border-slate-500/20', '🟡', 'bg-slate-500/[0.05]');

  if (onFeedback) {
    listEl.querySelectorAll('.issue-feedback-btn').forEach(btn => {
      btn.addEventListener('click', () => onFeedback(btn.dataset.msg || ''));
    });
  }
}

// ════════════════════════════════════════════════════════════════════════
// ЭКСПОРТ ОТЧЁТОВ
// ════════════════════════════════════════════════════════════════════════

// ── Строит светлую HTML-таблицу из summaryData ───────────────────
function buildReportTableHtml(summaryData) {
  if (!summaryData || !summaryData.length) return '';
  const COL_HEADERS = ['Наименование','Ед.','Кол-во','Цена','Без НДС','НДС','С НДС'];
  function fc(v) {
    if (v == null || v === '' || v === '—') return '';
    const n = parseFloat(String(v).replace(/\s/g,'').replace(',','.'));
    if (isNaN(n)) return xmlEsc(String(v));
    const str = String(v), dot = str.indexOf('.');
    const dec = Math.max(2, Math.min(dot >= 0 ? str.length-dot-1 : 0, 10));
    return n.toLocaleString('ru-RU', { minimumFractionDigits:dec, maximumFractionDigits:dec });
  }
  const SBGC = { payment:'#DBEAFE', primary:'#EDE9FE', aggregate:'#D1FAE5', extra:'#FEF3C7' };
  let h = '<table style="width:100%;border-collapse:collapse;font-size:0.78rem;margin:0.75rem 0">';
  h += '<thead><tr style="background:#f1f5f9">'+COL_HEADERS.map(c=>'<th style="border:1px solid #e2e8f0;padding:0.35rem 0.5rem;text-align:left;font-weight:600">'+c+'</th>').join('')+'</tr></thead><tbody>';
  summaryData.forEach(section => {
    const bg = SBGC[section.kind]||'#f8fafc';
    const meta = [section.docDate, section.seller?.inn?'ИНН пост.: '+section.seller.inn:'', section.buyer?.inn?'ИНН пок.: '+section.buyer.inn:''].filter(Boolean).join(' · ');
    h += '<tr style="background:'+bg+'"><td colspan="7" style="border:1px solid #e2e8f0;padding:0.4rem 0.5rem;font-weight:700">'+xmlEsc(section.label||'')+(meta?' <span style="font-weight:400;color:#64748b;font-size:0.72rem">'+xmlEsc(meta)+'</span>':'')+'</td></tr>';
    (section.items||[]).forEach(it => {
      h += '<tr><td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem">'+xmlEsc(it.name||'')+'</td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;text-align:center">'+xmlEsc(it.unit||'')+'</td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;text-align:right">'+fc(it.qty)+'</td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;text-align:right">'+fc(it.price)+'</td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;text-align:right">'+fc(it.amount)+'</td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;text-align:right">'+fc(it.vat_amount)+'</td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;text-align:right">'+fc(it.total)+'</td></tr>';
    });
    const t = section.totals;
    if (t && (t.qty_total != null || t.amount_no_vat != null)) {
      h += '<tr style="background:#f1f5f9;font-weight:600">'+
        '<td colspan="2" style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem">Итого</td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;text-align:right">'+fc(t.qty_total)+'</td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem"></td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;text-align:right">'+fc(t.amount_no_vat)+'</td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;text-align:right">'+fc(t.vat_amount)+'</td>'+
        '<td style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;text-align:right">'+fc(t.amount_with_vat)+'</td></tr>';
    }
    if (section.kind === 'aggregate' && section.compareWith) {
      const diff = section.compareWith.amount_with_vat && section.totals?.amount_with_vat
        ? Math.abs(Number(section.compareWith.amount_with_vat)-Number(section.totals.amount_with_vat)) : null;
      const match = diff !== null && diff < 0.02;
      h += '<tr style="background:'+(match?'#D1FAE5':'#FEE2E2')+'"><td colspan="7" style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;color:'+(match?'#065F46':'#B91C1C')+'">'+
        (match?'✅ Суммы совпадают с документом на оплату':'❌ Расхождение с документом на оплату: '+fc(diff)+' руб.')+'</td></tr>';
    }
    if (section.kind === 'extra') {
      const info = [section.productName?'Товар: '+section.productName:'', section.validUntil?'Действует до: '+section.validUntil:''].filter(Boolean).join(' · ');
      if (info) h += '<tr><td colspan="7" style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;color:#64748b;font-size:0.72rem">'+xmlEsc(info)+'</td></tr>';
    }
    (section.docIssues||[]).forEach(issue => {
      h += '<tr><td colspan="7" style="border:1px solid #e2e8f0;padding:0.3rem 0.5rem;color:#92400E;background:#FEF3C7;font-size:0.72rem">⚠ '+xmlEsc(issue)+'</td></tr>';
    });
  });
  h += '</tbody></table>';
  return h;
}

function buildIssuesHtml(issues) {
  if (!issues || !issues.length) return '<p style="color:#16a34a">✅ Программных нарушений не выявлено</p>';
  const groups = { critical:[], significant:[], minor:[] };
  issues.forEach(v => (groups[v.severity]||groups.minor).push(v));
  return [
    { key:'critical',    label:'🔴 Критические нарушения',    bg:'#FEE2E2', border:'#FCA5A5', color:'#B91C1C' },
    { key:'significant', label:'🟠 Существенные замечания',    bg:'#FEF3C7', border:'#FCD34D', color:'#92400E' },
    { key:'minor',       label:'🟡 Незначительные замечания',  bg:'#F9FAFB', border:'#E5E7EB', color:'#374151' },
  ].filter(s => groups[s.key].length).map(s =>
    '<div style="margin-bottom:1rem;background:'+s.bg+';border:1px solid '+s.border+';border-radius:6px;padding:0.75rem 1rem">'+
    '<div style="font-weight:700;margin-bottom:0.4rem;color:'+s.color+'">'+s.label+'</div>'+
    '<ul style="margin:0;padding-left:1.25rem">'+
    groups[s.key].map(v=>'<li style="margin-bottom:0.2rem;color:'+s.color+'">'+xmlEsc(v.text||'')+'</li>').join('')+
    '</ul></div>'
  ).join('');
}

function buildConclusionHtml(conclusion) {
  if (!conclusion) return '';
  return '<div style="background:#EDE9FE;border:1px solid #C4B5FD;border-radius:6px;padding:0.75rem 1rem">'+
    conclusion
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/^## (.+)$/gm,'<h3 style="font-size:0.9rem;font-weight:700;margin:0.75rem 0 0.3rem;color:#1e293b">$1</h3>')
      .replace(/^- (.+)$/gm,'<li style="margin-bottom:0.2rem;color:#374151">$1</li>')
      .replace(/^(\d+)\. (.+)$/gm,'<li style="margin-bottom:0.2rem;color:#374151">$1. $2</li>')
      .replace(/[🔴🟠🟡] /g,'')
      .replace(/\n\n/g,'</p><p style="margin:0.3rem 0;color:#374151">')
      .replace(/\n/g,'<br>')+
    '</div>';
}

function buildReportHtml(dateStr, summaryData, issues, conclusion, modelName) {
  const modelLine = modelName ? '<p style="color:#64748b;font-size:0.8rem;margin:0 0 1.5rem">🤖 Модель: <strong>' + modelName + '</strong></p>' : '';
  return '<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8">'+
    '<title>Отчёт проверки — '+dateStr+'</title>'+
    '<style>body{font-family:Arial,sans-serif;max-width:1300px;margin:0 auto;padding:2rem;color:#1e293b;font-size:13px;background:#fff}'+
    'h1{font-size:1.2rem;font-weight:700;border-bottom:2px solid #e2e8f0;padding-bottom:0.5rem;margin-bottom:1.5rem;color:#0f172a}'+
    'h2{font-size:1rem;font-weight:700;margin:1.5rem 0 0.5rem;color:#0f172a}'+
    'p{margin:0.4rem 0;line-height:1.6}ul,ol{margin:0.3rem 0 0.3rem 1.5rem}'+
    '.btn-print{background:#0f172a;color:#fff;border:none;border-radius:6px;padding:0.5rem 1.5rem;font-size:0.85rem;cursor:pointer;margin-bottom:1rem}'+
    '@media print{.btn-print{display:none}body{padding:0.5rem}}</style></head><body>'+
    '<button class="btn-print" onclick="window.print()">🖨 Печать / Сохранить как PDF</button>'+
    '<h1>Отчёт проверки документов на оплату — '+new Date().toLocaleString('ru-RU')+'</h1>'+
    modelLine+
    '<h2>Сводная таблица сверки</h2>'+buildReportTableHtml(summaryData)+
    '<h2>Программные проверки</h2>'+buildIssuesHtml(issues)+
    '<h2>Заключение AI</h2>'+buildConclusionHtml(conclusion)+
    '<hr style="margin-top:2rem;border:none;border-top:1px solid #e2e8f0">'+
    '<p style="color:#94a3b8;font-size:0.72rem">Сформировано: '+new Date().toLocaleString('ru-RU')+(modelName?' · '+modelName:'')+' · mto-cto.falcon28.ru</p>'+
    '</body></html>';
}

// Скачать HTML-отчёт
async function downloadHtmlReport() {
  const btn     = document.getElementById('downloadArchiveBtn');
  const labelEl = document.getElementById('downloadArchiveBtnLabel');
  if (btn) btn.disabled = true;
  if (labelEl) labelEl.textContent = 'Подготовка...';
  try {
    const dateStr = new Date().toISOString().slice(0, 10);
    const html = buildReportHtml(dateStr, results?.summaryData||[], results?.issues||[], results?.conclusion||'', results?.modelName||'');
    const blob  = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url   = URL.createObjectURL(blob);
    const a     = document.createElement('a');
    a.href = url;
    a.download = 'Отчёт проверки — ' + dateStr + '.html';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    if (labelEl) labelEl.textContent = '✅ Скачано!';
    setTimeout(() => { if (labelEl) labelEl.textContent = '📄 HTML'; }, 2000);
  } catch (err) {
    showToastMsg('Ошибка: ' + err.message, 'error');
    if (labelEl) labelEl.textContent = '📄 HTML';
  } finally {
    if (btn) btn.disabled = false;
  }
}

// Открыть в новом окне → Ctrl+P → PDF (берём из results, не из DOM — кнопки не попадают)
function openPdfPrint() {
  const dateStr = new Date().toISOString().slice(0, 10);
  const html = buildReportHtml(dateStr, results?.summaryData||[], results?.issues||[], results?.conclusion||'', results?.modelName||'');
  const win  = window.open('', '_blank');
  if (win) {
    win.document.write(html);
    win.document.close();
    setTimeout(() => { try { win.print(); } catch(e) { /* ignore */ } }, 800);
    showToastMsg('Нажмите Ctrl+P (или кнопку в новом окне) для сохранения в PDF', 'info');
  } else {
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = 'Отчёт — ' + dateStr + '.html';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    showToastMsg('Откройте скачанный файл и нажмите Ctrl+P для PDF', 'info');
  }
}

// Скачать Excel — нативный XML+JSZip (без SheetJS, как в экспертной проверке)
async function downloadExcel(res) {
  const btn = document.getElementById('downloadExcelBtn');
  if (btn) btn.disabled = true;
  try {
    const JSZip = await ensureJSZip();
    const summaryData = res?.summaryData || [];
    const issues      = res?.issues      || [];
    const reportDate  = new Date().toLocaleString('ru-RU');

    const _sst = [], _sstMap = new Map();
    function si(str) {
      const s = str == null ? '' : String(str);
      if (_sstMap.has(s)) return _sstMap.get(s);
      const idx = _sst.length; _sst.push(s); _sstMap.set(s, idx); return idx;
    }
    function sc(v, styleId) { return { v: String(v??''), t:'s', s:styleId, _si:si(String(v??'')) }; }
    function nc(v, styleId) { const n = parseNum(v); return n != null ? { v:n, t:'n', s:styleId } : sc(v, styleId); }

    const STYLES_XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
      '<fonts count="7"><font><sz val="11"/><name val="Calibri"/></font>' +
      '<font><sz val="13"/><b/><name val="Calibri"/><color rgb="FF0F172A"/></font>' +
      '<font><sz val="10"/><b/><name val="Calibri"/><color rgb="FF1E293B"/></font>' +
      '<font><sz val="10"/><name val="Calibri"/><color rgb="FF1E293B"/></font>' +
      '<font><sz val="10"/><b/><name val="Calibri"/><color rgb="FFB91C1C"/></font>' +
      '<font><sz val="10"/><name val="Calibri"/><color rgb="FF92400E"/></font>' +
      '<font><sz val="10"/><b/><name val="Calibri"/><color rgb="FF065F46"/></font></fonts>' +
      '<fills count="11"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFDBEAFE"/></patternFill></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFD1FAE5"/></patternFill></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFFEE2E2"/></patternFill></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFFEF3C7"/></patternFill></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFF1F5F9"/></patternFill></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFEDE9FE"/></patternFill></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFECFDF5"/></patternFill></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF7ED"/></patternFill></fill>' +
      '<fill><patternFill patternType="solid"><fgColor rgb="FFE8F4F8"/></patternFill></fill></fills>' +
      '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>' +
      '<border><left style="thin"><color rgb="FFE2E8F0"/></left><right style="thin"><color rgb="FFE2E8F0"/></right>' +
      '<top style="thin"><color rgb="FFE2E8F0"/></top><bottom style="thin"><color rgb="FFE2E8F0"/></bottom><diagonal/></border></borders>' +
      '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
      '<cellXfs count="15">' +
      '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
      '<xf numFmtId="0" fontId="1" fillId="10" borderId="1" xfId="0"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>' +
      '<xf numFmtId="0" fontId="2" fillId="6" borderId="1" xfId="0"><alignment horizontal="left" vertical="center"/></xf>' +
      '<xf numFmtId="0" fontId="3" fillId="0" borderId="1" xfId="0"><alignment horizontal="left" vertical="top" wrapText="1"/></xf>' +
      '<xf numFmtId="4" fontId="3" fillId="0" borderId="1" xfId="0"><alignment horizontal="right" vertical="center"/></xf>' +
      '<xf numFmtId="4" fontId="2" fillId="6" borderId="1" xfId="0"><alignment horizontal="right" vertical="center"/></xf>' +
      '<xf numFmtId="0" fontId="4" fillId="4" borderId="1" xfId="0"><alignment horizontal="left" vertical="top" wrapText="1"/></xf>' +
      '<xf numFmtId="0" fontId="5" fillId="5" borderId="1" xfId="0"><alignment horizontal="left" vertical="top" wrapText="1"/></xf>' +
      '<xf numFmtId="0" fontId="3" fillId="6" borderId="1" xfId="0"><alignment horizontal="left" vertical="top" wrapText="1"/></xf>' +
      '<xf numFmtId="0" fontId="3" fillId="7" borderId="1" xfId="0"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>' +
      '<xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0"><alignment horizontal="left" vertical="center"/></xf>' +
      '<xf numFmtId="0" fontId="6" fillId="3" borderId="1" xfId="0"><alignment horizontal="left" vertical="center"/></xf>' +
      '<xf numFmtId="0" fontId="2" fillId="7" borderId="1" xfId="0"><alignment horizontal="left" vertical="center"/></xf>' +
      '<xf numFmtId="0" fontId="2" fillId="9" borderId="1" xfId="0"><alignment horizontal="left" vertical="center"/></xf>' +
      '<xf numFmtId="0" fontId="3" fillId="6" borderId="1" xfId="0"><alignment horizontal="center" vertical="center"/></xf>' +
      '</cellXfs></styleSheet>';

    const NUM_COLS = 7;
    const COL_NAMES = ['Наименование','Ед.','Кол-во','Цена','Без НДС','НДС','С НДС'];
    const rows1 = [], merges1 = [];
    let r1 = 0;
    function addRow1(cells) { rows1.push({ r:r1, cells:cells.map((c,i)=>({...c,c:i})) }); r1++; }
    function emptyRow1() { rows1.push({ r:r1, cells:[] }); r1++; }
    function merge1(r,c1,c2) { merges1.push([r,c1,r,c2]); }

    const titleR = r1;
    addRow1([sc('Сводная таблица сверки документов  ·  ' + reportDate + (res?.modelName ? '  ·  ' + res.modelName : ''), 1)]);
    merge1(titleR, 0, NUM_COLS-1);
    emptyRow1();

    const SSTYLE = { payment:10, aggregate:11, primary:12, extra:13 };
    summaryData.forEach(section => {
      const sStyle = SSTYLE[section.kind] || 2;
      const meta = [section.docDate, section.seller?.inn?'ИНН пост.: '+section.seller.inn:''].filter(Boolean).join(' · ');
      const hR = r1;
      addRow1([sc((section.label||'')+(meta?'  '+meta:''), sStyle)]);
      merge1(hR, 0, NUM_COLS-1);
      if (section.items?.length) {
        addRow1(COL_NAMES.map(h=>sc(h,2)));
        section.items.forEach(it => {
          addRow1([sc(it.name||'',3), sc(it.unit||'',14), nc(it.qty,4), nc(it.price,4), nc(it.amount,4), nc(it.vat_amount,4), nc(it.total,4)]);
        });
        const t = section.totals;
        if (t && (t.qty_total != null || t.amount_no_vat != null)) {
          addRow1([sc('Итого',5), sc('',5), nc(t.qty_total,5), sc('',5), nc(t.amount_no_vat,5), nc(t.vat_amount,5), nc(t.amount_with_vat,5)]);
        }
      }
      if (section.kind === 'aggregate' && section.compareWith) {
        const diff = section.compareWith.amount_with_vat && section.totals?.amount_with_vat
          ? Math.abs(Number(section.compareWith.amount_with_vat)-Number(section.totals.amount_with_vat)) : null;
        const match = diff !== null && diff < 0.02;
        const cR = r1;
        addRow1([sc(match ? '✅ Суммы совпадают' : '❌ Расхождение: '+(diff?diff.toLocaleString('ru-RU',{minimumFractionDigits:2}):'')+' руб.', match?11:6)]);
        merge1(cR, 0, NUM_COLS-1);
      }
      (section.docIssues||[]).forEach(issue => { const iR=r1; addRow1([sc('⚠ '+issue,7)]); merge1(iR,0,NUM_COLS-1); });
      emptyRow1();
    });

    if (issues.length) {
      const vTR = r1; addRow1([sc('Нарушения и замечания',2)]); merge1(vTR,0,NUM_COLS-1);
      issues.forEach(v => {
        const sev = v.severity==='critical'?6:v.severity==='significant'?7:8;
        const prefix = v.severity==='critical'?'🔴 ':v.severity==='significant'?'🟠 ':'🟡 ';
        const vR = r1; addRow1([sc(prefix+v.text,sev)]); merge1(vR,0,NUM_COLS-1);
      });
      emptyRow1();
    }

    const rawConclusion = res?.conclusion || '';
    if (rawConclusion) {
      const cR = r1; addRow1([sc('Заключение AI',11)]); merge1(cR,0,NUM_COLS-1);
      const clean = rawConclusion.replace(/^##? .+$/gm,m=>m.replace(/^#+\s*/,'')).replace(/[🔴🟠🟡]\s*/g,'');
      const ctR = r1; addRow1([sc(clean,9)]); merge1(ctR,0,NUM_COLS-1);
    }

    const sstXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="'+_sst.length+'" uniqueCount="'+_sst.length+'">'+
      _sst.map(s=>'<si><t xml:space="preserve">'+xmlEsc(s)+'</t></si>').join('')+'</sst>';

    function sheetXml(sheetRows, sheetMerges, colWidths) {
      const colsXml = colWidths.length?'<cols>'+colWidths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join('')+'</cols>':'';
      const mergesXml = sheetMerges.length?'<mergeCells count="'+sheetMerges.length+'">'+sheetMerges.map(([r1,c1,r2,c2])=>'<mergeCell ref="'+colLetter(c1)+(r1+1)+':'+colLetter(c2)+(r2+1)+'"/>').join('')+'</mergeCells>':'';
      const rowsXml = sheetRows.map(row => {
        if (!row.cells.length) return '<row r="'+(row.r+1)+'"></row>';
        return '<row r="'+(row.r+1)+'">'+row.cells.map(cell=>{
          const addr = colLetter(cell.c)+(row.r+1);
          if (cell.t==='n') return '<c r="'+addr+'" s="'+cell.s+'"><v>'+cell.v+'</v></c>';
          return '<c r="'+addr+'" s="'+cell.s+'" t="s"><v>'+cell._si+'</v></c>';
        }).join('')+'</row>';
      }).join('');
      return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'+colsXml+'<sheetData>'+rowsXml+'</sheetData>'+mergesXml+'</worksheet>';
    }

    const wbXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Сводная таблица" sheetId="1" r:id="rId1"/></sheets></workbook>';
    const wbRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>';
    const rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    const contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>';

    const zip = new JSZip();
    zip.file('[Content_Types].xml', contentTypes);
    zip.file('_rels/.rels', rootRels);
    zip.file('xl/workbook.xml', wbXml);
    zip.file('xl/_rels/workbook.xml.rels', wbRels);
    zip.file('xl/styles.xml', STYLES_XML);
    zip.file('xl/sharedStrings.xml', sstXml);
    zip.file('xl/worksheets/sheet1.xml', sheetXml(rows1, merges1, [42,8,12,20,20,14,20]));
    const blob = await zip.generateAsync({ type:'blob', compression:'DEFLATE', compressionOptions:{ level:6 } });
    const dateStr = new Date().toISOString().slice(0, 10);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'Проверка — ' + dateStr + '.xlsx';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    showToastMsg('✅ Excel скачан', 'success');
  } catch (err) {
    showToastMsg('Ошибка Excel: ' + err.message, 'error');
  } finally {
    if (btn) btn.disabled = false;
  }
}

// Паттерны
const PATTERNS_LS_KEY = 'dc_user_patterns_v2';
let _userPatterns = [];

function loadUserPatterns() {
  try {
    const raw = sessionStorage.getItem(PATTERNS_LS_KEY);
    if (raw) _userPatterns = JSON.parse(raw);
  } catch { _userPatterns = []; }
  updatePatternsBadge();
}

function getUserPatternsPrompt() {
  if (!_userPatterns.length) return '';
  return _userPatterns.map((p, i) =>
    (i + 1) + '. Поле: ' + p.field + '. Было: «' + p.wrong + '». Должно быть: «' + p.correct + '».' +
    (p.context ? ' Контекст: ' + p.context : '')
  ).join('\n');
}

function updatePatternsBadge() {
  const el = document.getElementById('patternsBadge');
  if (el) el.textContent = _userPatterns.length > 0 ? String(_userPatterns.length) : '';
}

function openFeedback(issueMsg, docFiles) {
  const overlay = document.getElementById('feedbackOverlay');
  const docFileEl = document.getElementById('fbDocFile');
  if (docFileEl) docFileEl.value = docFiles || '';
  const wrongEl = document.getElementById('fbWrong');
  if (wrongEl) wrongEl.value = issueMsg.slice(0, 80);
  if (overlay) overlay.classList.remove('hidden');
}

function closeFeedback() {
  const overlay = document.getElementById('feedbackOverlay');
  if (overlay) overlay.classList.add('hidden');
}

function updatePatternPreview() {
  const wrong = document.getElementById('fbWrong')?.value.trim();
  const correct = document.getElementById('fbCorrect')?.value.trim();
  const field = document.getElementById('fbField')?.value;
  const preview = document.getElementById('fbPatternPreview');
  const jsonEl = document.getElementById('fbPatternJson');
  if (!wrong || !correct) { preview?.classList.add('hidden'); return; }
  const pattern = { field, wrong, correct, context: document.getElementById('fbContext')?.value.trim() || undefined };
  if (jsonEl) jsonEl.textContent = JSON.stringify(pattern, null, 2);
  preview?.classList.remove('hidden');
}

function saveFeedbackPattern() {
  const wrong = document.getElementById('fbWrong')?.value.trim();
  const correct = document.getElementById('fbCorrect')?.value.trim();
  const field = document.getElementById('fbField')?.value;
  const context = document.getElementById('fbContext')?.value.trim();
  if (!wrong || !correct) { showToastMsg('Заполните поля «Было» и «Должно быть»', 'error'); return; }
  const pattern = { field, wrong, correct, context: context || undefined, ts: Date.now() };
  _userPatterns.push(pattern);
  try { sessionStorage.setItem(PATTERNS_LS_KEY, JSON.stringify(_userPatterns)); } catch { /* */ }
  updatePatternsBadge();
  closeFeedback();
  showToastMsg('✅ Паттерн сохранён. Будет учтён при следующем анализе.', 'success');
}

function openPatternsModal() {
  const overlay = document.getElementById('patternsOverlay');
  const wrap = document.getElementById('patternsListWrap');
  if (wrap) {
    if (!_userPatterns.length) {
      wrap.innerHTML = '<p class="text-xs text-slate-500 text-center py-4">Паттернов пока нет. Нажмите «🐛 Сообщить об ошибке» под любым нарушением.</p>';
    } else {
      wrap.innerHTML = _userPatterns.map((p, i) =>
        '<div class="flex gap-2 items-start border border-white/10 rounded-lg px-3 py-2 mb-2 text-xs">' +
        '<div class="flex-1"><span class="text-slate-500">' + p.field + '</span> · ' +
        '<span class="text-red-400">«' + escHtml(p.wrong) + '»</span> → ' +
        '<span class="text-green-400">«' + escHtml(p.correct) + '»</span>' +
        (p.context ? '<p class="text-slate-600 mt-0.5">' + escHtml(p.context) + '</p>' : '') +
        '</div>' +
        '<button class="pattern-del-btn text-slate-600 hover:text-red-400 text-sm" data-idx="' + i + '">✕</button>' +
        '</div>'
      ).join('');
      wrap.querySelectorAll('.pattern-del-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          _userPatterns.splice(parseInt(btn.dataset.idx), 1);
          try { sessionStorage.setItem(PATTERNS_LS_KEY, JSON.stringify(_userPatterns)); } catch { /* */ }
          updatePatternsBadge();
          openPatternsModal();
        });
      });
    }
  }
  if (overlay) overlay.classList.remove('hidden');
}

function clearUserPatterns() {
  _userPatterns = [];
  try { sessionStorage.removeItem(PATTERNS_LS_KEY); } catch { /* */ }
  updatePatternsBadge();
  showToastMsg('Паттерны очищены', 'success');
  openPatternsModal();
}

// ════════════════════════════════════════════════════════════════════════
// ЧАСТЬ 4: ГЛАВНАЯ ЛОГИКА
// ════════════════════════════════════════════════════════════════════════

const zones = {
  1: { files: [], multiple: false },
  2: { files: [], multiple: true  },
  3: { files: [], multiple: true  },
  4: { files: [], multiple: true  },
};

let analyzing     = false;
let results       = null;
let fileIdCounter = 0;

const MAX_MB       = 50;
const ALLOWED_EXTS = ['pdf', 'docx', 'doc', 'xlsx', 'xls', 'txt', 'csv', 'md', 'png', 'jpg', 'jpeg'];

const $el = id => document.getElementById(id);

document.addEventListener('DOMContentLoaded', () => {
  showModeIndicator();
  // Проверяем Storage при загрузке страницы (асинхронно, не блокирует UI)
  checkStorageEnabled().then(updateStorageBadge);
  [1, 2, 3, 4].forEach(z => initZone(z));
  $el('analyzeBtn').addEventListener('click', showConfirmDialog);
  loadUserPatterns();
  [1, 2, 3, 4].forEach(z => $el('fileChips' + z).addEventListener('click', onChipRemoveClick));
  $el('clearBtn').addEventListener('click', clearAll);

  // Кнопки экспорта
  $el('downloadArchiveBtn')?.addEventListener('click', () => downloadHtmlReport());
  $el('downloadPdfBtn')?.addEventListener('click', () => openPdfPrint());
  $el('downloadExcelBtn')?.addEventListener('click', () => downloadExcel(results));

  $el('reanalyzeBtn')?.addEventListener('click', () => {
    $el('resultsBlock').classList.add('hidden');
    [1, 2, 3, 4].forEach(z => {
      zones[z].files.forEach(f => { f.status = 'pending'; f.error = null; });
      renderZoneChips(z);
    });
    results = null;
    updateAnalyzeBtn();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
  $el('confirmStartBtn').addEventListener('click', () => {
    $el('confirmOverlay').classList.add('hidden');
    runAnalysis();
  });
  $el('confirmCancelBtn').addEventListener('click', () => $el('confirmOverlay').classList.add('hidden'));
  $el('confirmOverlay').addEventListener('click', e => { if (e.target === $el('confirmOverlay')) $el('confirmOverlay').classList.add('hidden'); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      $el('confirmOverlay').classList.add('hidden');
      $el('feedbackOverlay')?.classList.add('hidden');
      $el('patternsOverlay')?.classList.add('hidden');
    }
  });
  $el('feedbackCloseBtn').addEventListener('click', closeFeedback);
  $el('feedbackCancelBtn').addEventListener('click', closeFeedback);
  $el('feedbackOverlay').addEventListener('click', e => { if (e.target === $el('feedbackOverlay')) closeFeedback(); });
  $el('feedbackSaveBtn').addEventListener('click', saveFeedbackPattern);
  [$el('fbWrong'), $el('fbCorrect'), $el('fbContext'), $el('fbField')].forEach(el => el?.addEventListener('input', updatePatternPreview));
  $el('patternsCloseBtn').addEventListener('click', () => $el('patternsOverlay').classList.add('hidden'));
  $el('patternsCloseBtnBottom').addEventListener('click', () => $el('patternsOverlay').classList.add('hidden'));
  $el('patternsOverlay').addEventListener('click', e => { if (e.target === $el('patternsOverlay')) $el('patternsOverlay').classList.add('hidden'); });
  $el('patternsClearBtn').addEventListener('click', clearUserPatterns);
  $el('showPatternsBtn')?.addEventListener('click', openPatternsModal);
});

function showModeIndicator() {
  const el = $el('modeIndicator');
  if (!el) return;
  el.innerHTML = '<span style="color:#a78bfa">🤖 Alice AI LLM</span> · Яндекс · 128K · PDF.js + Yandex Vision OCR';
  el.style.display = 'flex';
}

function initZone(z) {
  const dropArea  = $el('dropZone' + z);
  const fileInput = $el('fileInput' + z);
  dropArea.addEventListener('click', () => fileInput.click());
  dropArea.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } });
  dropArea.addEventListener('dragover', e => { e.preventDefault(); dropArea.classList.add('drag-over'); });
  dropArea.addEventListener('dragleave', () => dropArea.classList.remove('drag-over'));
  dropArea.addEventListener('drop', e => { e.preventDefault(); dropArea.classList.remove('drag-over'); addFiles(z, Array.from(e.dataTransfer.files)); });
  fileInput.addEventListener('change', () => { addFiles(z, Array.from(fileInput.files)); fileInput.value = ''; });
}

function addFiles(zone, files) {
  const zoneData = zones[zone];
  for (const file of files) {
    const realExt = file.name.split('.').pop().toLowerCase();
    if (!ALLOWED_EXTS.includes(realExt)) { showToastMsg('Формат не поддерживается: ' + file.name, 'error'); continue; }
    if (file.size > MAX_MB * 1024 * 1024) { showToastMsg('Файл слишком большой (>' + MAX_MB + 'МБ): ' + file.name, 'error'); continue; }
    if (zone === 1 && zoneData.files.length >= 1) zoneData.files = [];
    const type = detectDocType(file.name, '');
    const id   = ++fileIdCounter;
    zoneData.files.push({ id, file, name: file.name, size: file.size, type, textContent: null, base64: null, mediaType: null, status: 'pending', error: null, zone, ocrApplied: false });
  }
  renderZoneChips(zone);
  updateAnalyzeBtn();
}

function removeFile(zone, id) {
  zones[zone].files = zones[zone].files.filter(f => f.id !== id);
  renderZoneChips(zone);
  updateAnalyzeBtn();
}

function clearAll() {
  [1, 2, 3, 4].forEach(z => { zones[z].files = []; renderZoneChips(z); });
  results = null;
  $el('resultsBlock').classList.add('hidden');
  $el('progressBlock').classList.add('hidden');
  updateAnalyzeBtn();
}

const STATUS_LABELS = {
  pending:   { label: 'Ожидает',   cls: 'pending'    },
  reading:   { label: 'Чтение...', cls: 'extracting' },
  ocr:       { label: '🔍 OCR...', cls: 'analyzing'  },
  analyzing: { label: 'Анализ...',  cls: 'analyzing'  },
  done:      { label: '✓ Готово',  cls: 'done'       },
  error:     { label: '✕ Ошибка', cls: 'error'      },
};

function renderZoneChips(zone) {
  const container = $el('fileChips' + zone);
  const badge     = $el('zone' + zone + 'Badge');
  const files     = zones[zone].files;
  if (!files.length) { container.innerHTML = ''; if (badge) badge.innerHTML = ''; return; }
  if (badge) badge.innerHTML = '<span class="zone-count-badge">' + files.length + ' ' + pluralFiles(files.length) + '</span>';
  container.innerHTML = files.map(f => {
    const st = STATUS_LABELS[f.status] || STATUS_LABELS.pending;
    const icon = getTypeIcon(f.type);
    const ocrBadge = f.ocrApplied ? ' <span style="font-size:0.65rem;color:#a78bfa;margin-left:4px;">OCR</span>' : '';
    return '<div class="file-chip">' +
      '<span>' + icon + '</span>' +
      '<span class="file-chip-name" title="' + escHtml(f.name) + '">' + escHtml(f.name) + ocrBadge + '</span>' +
      '<span class="file-chip-status ' + st.cls + '">' + st.label + '</span>' +
      '<button class="file-chip-remove" data-file-id="' + f.id + '" data-file-zone="' + zone +
        '" aria-label="Удалить"' + (analyzing ? ' disabled' : '') + '>✕</button>' +
      '</div>';
  }).join('');
}

function onChipRemoveClick(e) {
  const btn = e.target.closest('.file-chip-remove');
  if (!btn) return;
  removeFile(+btn.dataset.fileZone, +btn.dataset.fileId);
}

function updateAnalyzeBtn() {
  const total = allFiles().length;
  const btn = $el('analyzeBtn');
  btn.disabled = total === 0 || analyzing;
  $el('clearBtn').disabled = analyzing;
  // Кнопки экспорта: активны только если есть results
  const hasResults = !!results;
  if ($el('downloadArchiveBtn')) $el('downloadArchiveBtn').disabled = !hasResults;
  if ($el('downloadPdfBtn'))     $el('downloadPdfBtn').disabled     = !hasResults;
  if ($el('downloadExcelBtn'))   $el('downloadExcelBtn').disabled   = !hasResults;
}

function allFiles() { return [1, 2, 3, 4].flatMap(z => zones[z].files); }

function pluralFiles(n) {
  if (n % 10 === 1 && n % 100 !== 11) return 'файл';
  if ([2, 3, 4].includes(n % 10) && ![12, 13, 14].includes(n % 100)) return 'файла';
  return 'файлов';
}

function showConfirmDialog() {
  if (analyzing) return;
  const zoneLabels = { 1:'Окно 1: Документ на оплату', 2:'Окно 2: Договор/ТЗ', 3:'Окно 3: Первичка', 4:'Окно 4: Доп. документы' };
  const summaryEl = $el('confirmFilesSummary');
  summaryEl.innerHTML = [1, 2, 3, 4].map(z => {
    const files = zones[z].files;
    if (!files.length) return '';
    return '<div style="margin-bottom:0.5rem;"><span style="font-size:0.75rem;font-weight:700;color:#94a3b8;">' + zoneLabels[z] + '</span>' +
      files.map(f => '<div class="confirm-file-row"><span>' + getTypeIcon(f.type) + '</span><span>' + escHtml(f.name) + '</span></div>').join('') + '</div>';
  }).join('');
  const missing = [];
  if (!zones[1].files.length) missing.push('📄 Документ на оплату (Окно 1) — обязателен');
  if (!zones[2].files.length) missing.push('📋 Договор/ТЗ (Окно 2) — без него реквизиты не проверить');
  const warnEl = $el('confirmWarning');
  if (missing.length) { warnEl.innerHTML = '⚠️ Возможно, не хватает документов:<br>' + missing.join('<br>'); warnEl.classList.remove('hidden'); }
  else { warnEl.classList.add('hidden'); }
  $el('confirmOverlay').classList.remove('hidden');
}

// OCR страницы через Yandex Vision
async function ocrPageViaServer(pngBase64) {
  const resp = await fetch(getProxyUrl(), {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'ocr', base64: pngBase64, mediaType: 'image/png' }),
  });
  const json = await resp.json();
  if (!resp.ok) throw new Error(json.error || 'OCR ошибка ' + resp.status);
  return json.text || '';
}

// Чтение файла: текст или OCR
async function readFileContent(f, onProgress) {
  const ft = getFileType(f.name);

  if (ft === 'xlsx') {
    const text = await extractExcelAsText(f.file);
    return { textContent: text, ocrApplied: false };
  }

  if (ft === 'txt') {
    const text = await f.file.text();
    return { textContent: text, ocrApplied: false };
  }

  if (ft === 'image') {
    const { base64 } = await fileToBase64(f.file);
    onProgress?.('OCR изображения: ' + f.name);
    const text = await ocrPageViaServer(base64);
    return { textContent: text, ocrApplied: true };
  }

  if (ft === 'pdf') {
    try {
      const pages = await extractPdfPages(f.file);
      const textParts = [];
      let ocrApplied = false;

      for (let i = 0; i < pages.length; i++) {
        const page = pages[i];
        const hasText = page.text && page.text.replace(/\s/g, '').length > 30;

        if (hasText) {
          textParts.push(page.text);
        } else {
          ocrApplied = true;
          onProgress?.('OCR стр.' + (i + 1) + '/' + pages.length + ': ' + f.name);
          try {
            const canvas = document.createElement('canvas');
            await page.canvasData.render(canvas);
            const dataUrl = canvas.toDataURL('image/png');
            const pngBase64 = dataUrl.replace(/^data:image\/png;base64,/, '');
            const ocrText = await ocrPageViaServer(pngBase64);
            if (ocrText) textParts.push('[Страница ' + (i + 1) + ' (OCR)]\n' + ocrText);
          } catch (ocrErr) {
            console.warn('[OCR] Страница', i + 1, ocrErr);
            textParts.push('[Страница ' + (i + 1) + ': не удалось распознать]');
          }
        }
      }

      const combined = textParts.join('\n\n');
      if (combined.replace(/\s/g, '').length > 10) {
        return { textContent: combined, ocrApplied };
      }
    } catch (e) {
      console.warn('[PDF.js] Ошибка:', f.name, e);
    }

    // Fallback: base64 → PHP-парсер
    const { base64, mediaType } = await fileToBase64(f.file);
    return { base64, mediaType, ocrApplied: false };
  }

  // DOCX и всё остальное → base64
  const { base64, mediaType } = await fileToBase64(f.file);
  return { base64, mediaType, ocrApplied: false };
}

// Основной анализ
async function runAnalysis() {
  if (analyzing) return;
  analyzing = true;
  results   = null;
  $el('resultsBlock').classList.add('hidden');
  $el('progressBlock').classList.remove('hidden');
  updateAnalyzeBtn();
  allFiles().forEach(f => { f.status = 'pending'; f.error = null; f.ocrApplied = false; });
  [1, 2, 3, 4].forEach(z => renderZoneChips(z));

  try {
    const files = allFiles();
    const total = files.length;

    setProgress(0, 'Шаг 1: Читаю файлы...', '0/' + total);
    let readDone = 0;

    for (const f of files) {
      f.status = 'reading';
      renderZoneChips(f.zone);
      try {
        const result = await readFileContent(f, msg => {
          f.status = 'ocr';
          renderZoneChips(f.zone);
          setProgress(null, 'Шаг 1: ' + msg, '');
        });
        f.textContent = result.textContent ?? null;
        f.base64      = result.base64      ?? null;
        f.mediaType   = result.mediaType   ?? null;
        f.ocrApplied  = result.ocrApplied  ?? false;
        f.type        = detectDocType(f.name, f.textContent || '');
        f.status      = 'analyzing';
      } catch (err) {
        f.status = 'error';
        f.error  = err.message;
        console.error('[doc-checker] Ошибка чтения:', f.name, err);
      }
      readDone++;
      setProgress(Math.round(readDone / total * 30), 'Шаг 1: Читаю файлы...', 'Прочитано ' + readDone + '/' + total + (f.ocrApplied ? ' (с OCR)' : ''));
      renderZoneChips(f.zone);
    }

    const toAnalyze = files.filter(f => f.status !== 'error');
    if (!toAnalyze.length) throw new Error('Все файлы не удалось подготовить');

    // ── Шаг 1.5: Загрузка PDF в Object Storage (если включён) ────────────────
    const storageKeys = []; // для удаления после анализа
    const storageAvailable = await checkStorageEnabled();
    if (storageAvailable) {
      const pdfFiles = toAnalyze.filter(f => getFileType(f.name) === 'pdf' && !f.textContent);
      if (pdfFiles.length > 0) {
        setProgress(32, 'Шаг 1.5: Загрузка в Object Storage...', '0/' + pdfFiles.length);
        let uploadDone = 0;
        for (const f of pdfFiles) {
          const stored = await uploadFileToStorage(f, msg => setProgress(null, 'Storage...', msg));
          if (stored) {
            f.storageUrl = stored.url;
            f.storageKey = stored.key;
            storageKeys.push(stored.key);
          }
          uploadDone++;
          setProgress(32 + Math.round(uploadDone / pdfFiles.length * 3),
            'Шаг 1.5: Object Storage...', 'Загружено ' + uploadDone + '/' + pdfFiles.length);
        }
      }
    }

    const ocrCount = toAnalyze.filter(f => f.ocrApplied).length;
    const storageCount = toAnalyze.filter(f => f.storageUrl).length;
    const ocrNote = [
      ocrCount > 0 ? ocrCount + ' через OCR' : '',
      storageCount > 0 ? storageCount + ' нативно через Storage' : '',
    ].filter(Boolean).join(', ');
    setProgress(35, 'Шаг 2: Alice AI анализирует...', 'Передаю ' + toAnalyze.length + ' файл(ов)' + (ocrNote ? ' (' + ocrNote + ')' : '') + '...');

    const extraInstructions = $el('customPrompt')?.value?.trim() || '';

    const packageResult = await analyzePackage(
      toAnalyze.map(f => ({ name: f.name, base64: f.base64, mediaType: f.mediaType, textContent: f.textContent, storageUrl: f.storageUrl || null, filename: f.name, zone: f.zone })),
      msg => setProgress(null, 'Шаг 2: Alice AI...', msg),
      extraInstructions,
      getUserPatternsPrompt(),
    );

    toAnalyze.forEach(f => { f.status = 'done'; });
    [1, 2, 3, 4].forEach(z => renderZoneChips(z));

    setProgress(92, 'Шаг 3: Формирую заключение...', '');
    let conclusion = '';
    try {
      conclusion = await generateConclusion(packageResult.data, packageResult.issues);
    } catch (err) {
      conclusion = packageResult.rawText || 'Не удалось получить заключение.';
    }

    setProgress(100, 'Готово!', 'Анализ завершён');

    const summaryData = buildSummaryTableData(packageResult.data);

    results = {
      issues: packageResult.issues,
      conclusion,
      rawData: packageResult.data,
      rawText: packageResult.rawText,
      summaryData,
      documents: toAnalyze.map(f => ({ filename: f.name, type: f.type, zone: f.zone, data: null })),
      modelName: 'Alice AI LLM',
      reportDate: new Date().toLocaleString('ru-RU'),
    };

    setTimeout(() => {
      $el('progressBlock').classList.add('hidden');
      renderResults();
      $el('resultsBlock').classList.remove('hidden');
      $el('resultsBlock').scrollIntoView({ behavior: 'smooth' });
      updateAnalyzeBtn(); // разблокировать кнопки экспорта
    }, 500);

  } catch (err) {
    setProgress(null, 'Ошибка: ' + err.message, err.message);
    console.error('[doc-checker] Критическая ошибка:', err);
    showToastMsg('Ошибка анализа: ' + err.message, 'error');
  } finally {
    analyzing = false;
    updateAnalyzeBtn();
    [1, 2, 3, 4].forEach(z => renderZoneChips(z));
    // Удаляем временные файлы из Object Storage
    if (typeof storageKeys !== 'undefined' && storageKeys.length > 0) {
      console.log('[Storage] Удаляем', storageKeys.length, 'временных файлов...');
      Promise.all(storageKeys.map(key => deleteFromStorage(key)))
        .then(() => console.log('[Storage] Все временные файлы удалены'))
        .catch(e => console.warn('[Storage] Ошибка при удалении', e));
    }
  }
}

function renderResults() {
  const { issues, conclusion, documents, summaryData, modelName, reportDate } = results;
  // Показываем мета-строку с моделью и датой
  const metaEl = $el('resultsMeta');
  if (metaEl) {
    metaEl.innerHTML = [
      reportDate ? '📅 ' + reportDate : '',
      modelName  ? '🤖 <span style="color:#a78bfa;font-weight:600">' + escHtml(modelName) + '</span>' : '',
      documents.length ? '📁 ' + documents.length + ' файл(ов)' : '',
    ].filter(Boolean).join(' &nbsp;·&nbsp; ');
    metaEl.style.display = 'flex';
  }
  renderDocCards(documents);
  renderSummaryTable(summaryData);
  renderIssues(issues, issueMsg => openFeedback(issueMsg, allFiles().map(f => f.name).join(', ')));
  $el('conclusionText').innerHTML = markdownToHtml(conclusion);
}
