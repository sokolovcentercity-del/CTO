<?php
/**
 * REST API — хранение данных + запись файлов на сервер
 * GET  ?action=ping
 * GET  ?action=getall
 * POST ?action=setall   body: {data:{...}}
 * GET  ?action=get&key=xxx
 * POST ?action=set      body: {key,value}
 * POST ?action=writefile  body: {path,content,password}
 * POST ?action=writefiles body: {files:[{path,content},...],password}
 */
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
define('DATA_FILE', __DIR__ . '/data/storage.json');
define('DATA_DIR',  __DIR__ . '/data');
define('WRITE_PASSWORD', 'sync2025');
define('SITE_ROOT', dirname(__DIR__));
define('ALLOWED_EXTENSIONS', ['js','css','html','json','php','md','txt','htaccess']);
define('FORBIDDEN_PATHS', ['api/data/storage.json','api/data/','api/index.php']);
function ok($extra=[]) { echo json_encode(array_merge(['ok'=>true],$extra),JSON_UNESCAPED_UNICODE); exit; }
function fail($msg='error',$code=400) { http_response_code($code); echo json_encode(['ok'=>false,'error'=>$msg],JSON_UNESCAPED_UNICODE); exit; }
function loadData() { if(!file_exists(DATA_FILE))return[]; $raw=file_get_contents(DATA_FILE); if($raw===false)return[]; $data=json_decode($raw,true); return is_array($data)?$data:[]; }
function saveData($data) { if(!is_dir(DATA_DIR)){mkdir(DATA_DIR,0755,true);} $json=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT); $tmp=DATA_FILE.'.tmp'; if(file_put_contents($tmp,$json,LOCK_EX)===false)return false; return rename($tmp,DATA_FILE); }
function isPathAllowed($path) { $path=ltrim(str_replace('\\','/',$path),'/'); if(strpos($path,'..')!==false||strpos($path,'./')!==false)return false; foreach(FORBIDDEN_PATHS as $f){if(strpos($path,$f)===0)return false;} $ext=strtolower(pathinfo($path,PATHINFO_EXTENSION)); $base=strtolower(basename($path)); if($base==='.htaccess'||$base==='htaccess')return true; return in_array($ext,ALLOWED_EXTENSIONS); }
function writeFile($path,$content) { $path=ltrim(str_replace('\\','/',$path),'/'); $full=SITE_ROOT.'/'.$path; $dir=dirname($full); if(!is_dir($dir)){if(!mkdir($dir,0755,true))return['ok'=>false,'error'=>'Не удалось создать директорию'];} $tmp=$full.'.tmp_'.uniqid(); if(file_put_contents($tmp,$content,LOCK_EX)===false)return['ok'=>false,'error'=>'Не удалось записать: '.$path]; if(!rename($tmp,$full)){@unlink($tmp);return['ok'=>false,'error'=>'Не удалось сохранить: '.$path];} return['ok'=>true,'path'=>$path,'size'=>strlen($content)]; }
$action=$_GET['action']??''; $method=$_SERVER['REQUEST_METHOD'];
if($action==='ping'){ok(['write_enabled'=>true]);}
if($action==='getall'&&$method==='GET'){ok(['data'=>loadData()]);}
if($action==='setall'&&$method==='POST'){$body=json_decode(file_get_contents('php://input'),true);if(!is_array($body)||!isset($body['data']))fail('Invalid body');if(!saveData($body['data']))fail('Failed to save',500);ok();}
if($action==='get'&&$method==='GET'){$key=$_GET['key']??'';if($key==='')fail('Missing key');$data=loadData();ok(['value'=>$data[$key]??null]);}
if($action==='set'&&$method==='POST'){$body=json_decode(file_get_contents('php://input'),true);if(!is_array($body)||!isset($body['key']))fail('Invalid body');$data=loadData();$data[$body['key']]=$body['value']??null;if(!saveData($data))fail('Failed to save',500);ok();}
if($action==='writefile'&&$method==='POST'){$body=json_decode(file_get_contents('php://input'),true);if(!is_array($body))fail('Invalid JSON');if(($body['password']??'')!==WRITE_PASSWORD)fail('Неверный пароль',403);$path=$body['path']??'';$content=$body['content']??'';if(!$path)fail('Не указан путь');if(!isPathAllowed($path))fail('Путь не разрешён: '.$path,403);$r=writeFile($path,$content);if(!$r['ok'])fail($r['error'],500);ok(['path'=>$r['path'],'size'=>$r['size']]);}
if($action==='writefiles'&&$method==='POST'){$body=json_decode(file_get_contents('php://input'),true);if(!is_array($body))fail('Invalid JSON');if(($body['password']??'')!==WRITE_PASSWORD)fail('Неверный пароль',403);$files=$body['files']??[];if(!is_array($files)||empty($files))fail('Нет файлов');$results=[];$ok_count=0;$fail_count=0;foreach($files as $fi){$path=$fi['path']??'';$content=$fi['content']??'';if(!$path){$results[]=['ok'=>false,'path'=>$path,'error'=>'Пустой путь'];$fail_count++;continue;}if(!isPathAllowed($path)){$results[]=['ok'=>false,'path'=>$path,'error'=>'Путь не разрешён'];$fail_count++;continue;}$r=writeFile($path,$content);$results[]=$r;if($r['ok'])$ok_count++;else $fail_count++;}ok(['ok_count'=>$ok_count,'fail_count'=>$fail_count,'results'=>$results]);}
fail('Unknown action',404);
