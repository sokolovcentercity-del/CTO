# Техническое задание
## Информационная система «Оснащение образовательных организаций»

**Версия:** 1.0  
**Тип системы:** Одностраничное веб-приложение (SPA)  
**Стек:** HTML5 / CSS3 / Vanilla JS ES-modules, PHP REST API, хранилище JSON-on-disk  

---

## 1. Назначение системы

Система предназначена для управления полным жизненным циклом оснащения образовательных организаций: от формирования каталога товаров и сбора потребностей получателей до контроля контрактов, приёмки, складского учёта, отгрузки и сборки/монтажа оборудования.

---

## 2. Архитектура системы

### 2.1 Общая схема

```
Браузер (SPA)
├── index.html         — статическая оболочка, все модальные панели
├── styles.css         — базовые стили, критические классы до Tailwind
├── main.js            — точка входа, инициализация, роутинг событий
├── state.js           — единый источник истины (реактивное состояние)
├── storage.js         — слой хранения (API ↔ localStorage)
├── auth.js            — аутентификация (локальная сессия)
├── ui/*.js            — модули представления (view/feature)
└── locales/ru.json    — словарь локализации

Сервер (PHP)
└── api/index.php      — REST API, хранение data/storage.json
```

### 2.2 Слои системы

| Слой | Файл(ы) | Ответственность |
|------|---------|-----------------|
| Представление | index.html, ui/*.js | HTML-панели, рендеринг, события DOM |
| Бизнес-логика | state.js | Мутации данных, вычисляемые поля, миграции |
| Хранение | storage.js | Сериализация, синхронизация с API/localStorage |
| Транспорт | api/index.php | REST-эндпоинты, запись в data/storage.json |
| Аутентификация | auth.js | Сессия в памяти + sessionStorage/localStorage |
| Локализация | locales/ru.json, ui/i18n-fallback.js | Словарь, fallback при отсутствии платформы |

---

## 3. Модуль аутентификации (auth.js)

### 3.1 Требования
- Локальная проверка логина/пароля без сетевых запросов.
- Сессия хранится в памяти (_memToken, _memUser) с дублированием в sessionStorage и localStorage для восстановления при перезагрузке.
- При блокировке хранилищ браузером (iframe-sandbox) — работа только через память.

### 3.2 Интерфейс

| Функция | Описание |
|---------|----------|
| isLoggedIn() | Проверить наличие активной сессии |
| login(username, password) | Вход: { ok: true } или { ok: false, error } |
| logout() | Очистить сессию из всех хранилищ |
| getCurrentUser() | Имя текущего пользователя или null |
| getToken() | Токен сессии или null |

### 3.3 Поток аутентификации

```
DOMContentLoaded
  → isLoggedIn() ?
      Нет → showLoginScreen() → login() → bootApp()
      Да  → bootApp()
```

---

## 4. Модуль состояния (state.js)

### 4.1 Структура глобального состояния

```javascript
state = {
  // Каталог
  products[],           // { id, number, name, category, color, assembly, specs[] }
  categories[],         // string[]
  nextId,               // счётчик ID товаров
  filters,              // { search, category, color }
  sort,                 // { key, dir }

  // Получатели
  recipients[],         // { id, name, address, targetProgram, readinessStatus, needs{} }
  nextRecipientId,

  // Поставщики
  suppliers[],          // { id, name, inn, address, email, phones[], persons[], contracts[] }

  // Контракты
  contracts[],          // { id, title, number, date, supplierId, totalPrice, programs[], items[] }
  nextContractId,

  // Финансы
  programs[],           // { id, name, code, kbk, limit }
  nextProgramId,

  // Комиссия приёмки
  commission[],         // { id, role, name }
  nextCommissionId,

  // Акты проверки
  acts[],               // { id, ...actData, savedAt }
  nextActId,

  // Заявки
  orders[],             // { id, orderNumber, contractId, supplierId, items[], ... }
  nextOrderId,

  // Склад
  warehouses[],         // { id, name, supplierId, address, phone, isDefault }
  nextWarehouseId,
  activeWarehouseId,
  warehouseEntries[],   // { id, productId, productCode, productName, category, contractId, orderId,
                        //   date, received, shipped, accepted, items[], warehouseId }
  nextWarehouseEntryId,

  // Отгрузки
  shipments[],          // { id, date, note, rows[], totalQty, createdAt }
  nextShipmentId,

  // Акты сборки
  assemblyActs[],       // { id, recipientId, contractId, items[], ... }
  nextAssemblyActId,
}
```

### 4.2 Вычисляемые агрегаты

| Функция | Описание |
|---------|----------|
| recalcAllDelivered() | Пересчёт delivered в recipient.needs по всем отгрузкам |
| recalcAllAssembled() | Пересчёт assembled в recipient.needs по всем актам сборки |
| warehouseBalance(entry) | received − shipped для записи склада |
| calcOrderDelivered(orderId, ...) | Суммарно поставлено по заявке |
| calcOrderAssembled(contractId, ...) | Суммарно собрано по контракту |
| isShippingAllowedByActs(...) | Допущен ли товар к отгрузке по актам приёмки |

### 4.3 Миграции данных (вызываются при загрузке)

| Функция | Что исправляет |
|---------|---------------|
| renumberDuplicateNumbers() | Дублирующиеся номера товаров |
| deduplicateCategories() | Категории с одинаковым написанием в разном регистре |
| migrateShipmentProductIds() | Добавляет productId в строки старых отгрузок |
| migrateShipmentOrderNums() | Восстанавливает orderNum в строках отгрузок |
| ensureDefaultWarehouse() | Создаёт «Основной склад» если складов нет |

---

## 5. Слой хранения (storage.js)

### 5.1 Стратегия хранения

```
При загрузке:
  1. GET /api/?action=getall  (таймаут 5 сек)
     Успех → применить, кэшировать в localStorage
     Ошибка → читать из localStorage

При сохранении:
  1. Записать в localStorage (мгновенно)
  2. POST /api/?action=setall (таймаут 8 сек)

Авто-синхронизация:
  setInterval(15 сек) → GET /api/?action=getall → applyData → UI refresh
```

### 5.2 Ключи хранения

| Ключ | Содержимое |
|------|-----------|
| catalog_products | JSON-массив товаров |
| catalog_categories | JSON-массив категорий |
| catalog_recipients | JSON-массив получателей |
| catalog_suppliers | JSON-массив поставщиков |
| catalog_contracts | JSON-массив контрактов |
| catalog_programs | JSON-массив целевых программ |
| catalog_commission | JSON-массив комиссии |
| catalog_acts | JSON-массив актов проверки |
| catalog_orders | JSON-массив заявок |
| catalog_warehouse_entries | JSON-массив поступлений склада |
| catalog_shipments | JSON-массив отгрузок |
| catalog_assembly_acts | JSON-массив актов сборки |
| catalog_warehouses | JSON-массив складов |
| catalog_next_* | Счётчики ID (строки) |

### 5.3 REST API (api/index.php)

| Метод | URL | Тело | Ответ |
|-------|-----|------|-------|
| GET | ?action=ping | — | { ok: true } |
| GET | ?action=getall | — | { ok, data: {key: value} } |
| POST | ?action=setall | { data: {key: value} } | { ok: true } |
| GET | ?action=get&key=X | — | { ok, value } |
| POST | ?action=set | { key, value } | { ok: true } |

Данные хранятся в api/data/storage.json. Запись атомарная: через временный файл .tmp + rename.

---

## 6. Модули пользовательского интерфейса

### 6.1 Навигационная модель

Приложение использует стековую модель панелей внутри модальных оверлеев. Каждый раздел — это div.modal-overlay с CSS-классом open. Полноэкранные панели используют класс catalog-panel (slide-up анимация). Вложенные подпанели реализованы через hidden/visible переключение внутри одного оверлея.

### 6.2 Каталог товаров

**Файлы:** ui/catalog-view.js, ui/product-form.js, ui/import-panel.js, ui/categories.js, ui/filters.js, ui/specs-import.js

**Потоки:**
```
Главное меню → Каталог (подменю)
  ├── Каталог товаров → таблица с сортировкой и фильтрами
  │     ├── Добавить → product-form (новый)
  │     ├── Редактировать → product-form (существующий)
  │     └── Удалить → confirmDelete → state.deleteProduct → saveToStorage
  ├── Импорт из Excel → import-panel → XLSX.read → addProducts → saveToStorage
  └── Категории → categories → addCategory/removeCategory → saveToStorage
```

**Зависимости state.js:** products, categories, filters, sort  
**Экспортируемые функции:** openCatalog, closeCatalog, renderCatalogTable, updateCatalogBadge

### 6.3 Получатели и потребности

**Файлы:** ui/recipients-view.js, ui/needs-import-view.js, ui/needs-matrix-view.js

**Потоки:**
```
Получатели → список организаций
  └── Карточка получателя → поля: имя, адрес, программа, статус готовности
        └── Потребность (раскрываемая секция) → needs{productId: {qty, delivered, assembled}}

Потребность (матрица) → таблица: строки = товары, столбцы = получатели
  ├── Режим «Все получатели»
  ├── Режим «По программам»
  └── Импорт из Excel → needs-import-view → Формат А (матрица) / Формат Б (список)
```

**Зависимости state.js:** recipients, products, programs  
**Связь с отгрузками:** delivered пересчитывается из shipments через recalcAllDelivered()  
**Связь со сборкой:** assembled пересчитывается из assemblyActs через recalcAllAssembled()

### 6.4 Поставщики

**Файл:** ui/suppliers-view.js

**Структура данных:**
```javascript
supplier = {
  id, name, inn, address, email,
  phones[],           // [{ phone }]
  persons[],          // [{ name, role, phone }]
  contracts[],        // ← только отображение, управляется в «Контракты»
}
```

**Потоки:** Список → Карточка поставщика (просмотр/редактирование). Контракты в карточке поставщика — только для чтения, ссылаются на state.contracts по supplierId.

### 6.5 Контракты

**Файл:** ui/contracts-view.js

**Структура контракта:**
```javascript
contract = {
  id, title, number, date, supplierId, totalPrice, advancePct,
  programs[],   // [{ programName, kbk, amount }]
  items[],      // [{ productId, price, qty, ordered, delivered, paidAdvance, paid50, paid30, receiving{} }]
}
```

**Подпанели карточки контракта:**
- Заявки по контракту → contractOrdersSubPanel → список orders с contractId
- Проверки по контракту → contractActsSubPanel → список acts с contractId

**Финансовый итог:** по каждой программе: лимит, сумма контракта, % освоения.

### 6.6 Финансы

**Файл:** ui/finance-view.js

Управление целевыми программами (state.programs). Каждая программа: name, code, kbk, limit. Из карточки программы — список контрактов, привязанных к ней через contract.programs[].programName.

### 6.7 Приёмка

**Файлы:** ui/receiving-view.js, ui/act-form-view.js, ui/acts-registry-view.js

**Потоки:**
```
Приёмка (список контрактов + вкладки)
  ├── Вкладка «Приёмка»
  │     └── Карточка контракта → таблица items с полями receiving{}
  │           └── [Сформировать акт] → act-form-view
  │                 ├── Контракт, дата, место
  │                 ├── Состав комиссии (из state.commission)
  │                 ├── Представители поставщика
  │                 ├── Проверяемые товары (selectedItems[])
  │                 ├── Результат и предписания
  │                 ├── [Сохранить акт] → state.saveAct → saveToStorage
  │                 └── [Сформировать .docx] → генерация Word-документа
  │
  └── Вкладка «Реестр актов»
        └── acts-registry-view → список актов → просмотр карточки
```

**Комиссия:** управляется прямо из панели «Приёмка», хранится в state.commission — единый список для всех актов.

### 6.8 Заявки

**Файл:** ui/orders-view.js

**Структура заявки:**
```javascript
order = {
  id, orderNumber, contractId, supplierId, programName,
  seqNum,            // порядковый номер в рамках контракта
  items[],           // [{ productId, productName, productCode, qty, price, deliverySchedules[] }]
  deliveryRows[],    // [{ contractItemName, contractItemCode, qty, price }]
  status,            // draft | sent | confirmed | delivered
  createdAt,
}
```

**Номер заявки:** автогенерация по формуле [последние 4 цифры контракта]-[seq]-[код программы].  
**Экспорт:** в Excel (XLSX) — одна заявка или реестр.

### 6.9 Склад

**Файлы:** ui/warehouse-view.js, ui/warehouse-locations-view.js, ui/shipment-view.js

**Навигация склада:**
```
Склад (список складов)
  ├── [Добавить склад] → карточка склада
  ├── [Сводный] → сводный вид по всем складам
  └── Конкретный склад → панель склада
        ├── Наличие → таблица остатков (received − shipped) по товарам
        ├── Новая отгрузка → shipment-view → разнарядка
        ├── Реестр отгрузок → список отгрузок + экспорт всех в Excel
        └── Реестр поступлений → список warehouseEntries
              ├── [Добавить] → карточка поступления
              └── [Импорт из Excel] → warehouseImportPanel
```

**Запись поступления (warehouseEntry):**
```javascript
entry = {
  id, warehouseId, contractId, orderId, date, accepted,
  received, shipped,
  items[],   // [{ productId, productCode, productName, category, qty, price, cost }]
  notes,
}
```

**Отгрузка (shipment):**
```javascript
shipment = {
  id, date, note,
  rows[],    // [{ codeKey, orderKey, productCode, productName, productId, orderId, orderNum,
             //    recipients[{ recipientId, recipientName, qty }] }]
  totalQty, createdAt,
}
```

Разнарядка отгрузки: матрица «товары × получатели». Ограничения ячейки: qty ≤ потребность_получателя и qty ≤ остаток_на_складе.

После сохранения отгрузки вызывается recalcAllDelivered() — пересчёт delivered в recipient.needs.

### 6.10 Сборка и монтаж

**Файлы:** ui/assembly-view.js

**Потоки:**
```
Сборка и монтаж (хаб)
  ├── Форма акта сборки → assemblyActFormModal (z-index: 87)
  │     ├── Основная информация: получатель, контракт, дата, адрес
  │     ├── Товары (из отгруженных по получателю)
  │     │     └── assembled: кол-во собранного/смонтированного
  │     ├── [Сохранить акт] → state.assemblyActs → saveToStorage → recalcAllAssembled()
  │     └── [Сформировать .docx] → Word-документ акта сборки
  │
  └── Реестр актов сборки → assemblyRegistryModal (z-index: 86)
        └── Карточка акта → assemblyActFormModal (z-index: 87)
              ├── Режим просмотра (readonly)
              └── [Редактировать] → режим редактирования
```

После сохранения акта сборки вызывается recalcAllAssembled() — пересчёт assembled в recipient.needs.

---

## 7. Межмодульные связи

### 7.1 Граф зависимостей данных

```
products ←── contracts.items[].productId
products ←── warehouseEntries[].productId
products ←── orders[].items[].productId
products ←── shipments[].rows[].productId (по коду/имени)
products ←── assemblyActs[].items[].productId (по коду/имени)
products ←── recipients[].needs{} (ключ = productId)

recipients[].needs{}.delivered ←── recalcAllDelivered() ← shipments[]
recipients[].needs{}.assembled ←── recalcAllAssembled() ← assemblyActs[]

contracts ←── orders[].contractId
contracts ←── warehouseEntries[].contractId
contracts ←── acts[].contractId
contracts ←── assemblyActs[].contractId

suppliers ←── contracts[].supplierId
suppliers ←── warehouses[].supplierId
suppliers ←── warehouseEntries[].supplierId
suppliers ←── orders[].supplierId

programs ←── contracts[].programs[].programName
programs ←── orders[].programName

orders ←── warehouseEntries[].orderId
orders ←── shipments[].rows[].orderId

warehouses ←── warehouseEntries[].warehouseId

commission ←── acts[].commission[] (копируется при формировании)
```

### 7.2 Поток данных при сохранении

```
UI-событие (клик «Сохранить»)
  → мутация state.js (addX / updateX / deleteX)
  → saveToStorage()
     ├── lsSetAll()          — синхронно, localStorage
     └── apiSetAll()         — асинхронно, POST /api/?action=setall
  → showToast('Сохранено', 'success')
  → refresh() / updateBadge()
```

### 7.3 Поток авто-синхронизации

```
setInterval(15 сек)
  → GET /api/?action=getall
  → applyData() — обновляет state
  → recalcAllDelivered() + recalcAllAssembled()
  → fullRefresh() — перерисовывает все бейджи и видимые таблицы
```

---

## 8. Система локализации

**Провайдер:** window.miniappI18n (инжектируется платформой) или fallback из ui/i18n-fallback.js.  
**Словарь:** locales/ru.json — плоский объект "namespace.key": "Текст".  
**Использование в HTML:** data-i18n="key", data-i18n-placeholder="key".  
**Использование в JS:** const t = (key, vals) => window.miniappI18n?.t(key, vals) ?? key.  
**Плейсхолдеры:** одинарные фигурные скобки {name}.

---

## 9. Экспорт данных

| Функция | Формат | Источник | Файл |
|---------|--------|----------|------|
| Экспорт данных проекта | .json | весь state | main.js → exportDataJson() |
| Импорт данных проекта | .json | файл → applyData() | ui/data-io.js |
| Скачать код приложения | .zip | CDN + встроенный INDEX_HTML | ui/download-archive.js |
| Экспорт каталога | .xlsx | state.products | ui/catalog-view.js |
| Экспорт заявки | .xlsx | state.orders | ui/orders-view.js |
| Экспорт отгрузки | .xlsx | state.shipments | ui/shipment-view.js |
| Экспорт всех отгрузок | .xlsx (многолистовой) | state.shipments[] | ui/shipment-view.js |
| Экспорт остатков склада | .xlsx | warehouseEntries | ui/warehouse-view.js |
| Формирование акта приёмки | .docx | state.acts | ui/act-form-view.js |
| Формирование акта сборки | .docx | state.assemblyActs | ui/assembly-view.js |

Библиотеки: SheetJS (xlsx@0.18.5) для Excel, JSZip (jszip@3.10.1) для архива. Подключаются синхронно (без defer) до main.js.

---

## 10. Требования к развёртыванию

### 10.1 Структура файлов на сервере

```
/
├── index.html
├── main.js, styles.css, state.js, storage.js, auth.js
├── ui/*.js
├── locales/ru.json
├── docs/technical-specification.md
├── .htaccess          (SPA-роутинг: все запросы → index.html)
└── api/
    ├── index.php
    ├── .htaccess      (запрет прямого доступа к data/)
    └── data/          (создать вручную, chmod 755)
        └── storage.json  (создаётся автоматически)
```

### 10.2 Требования к серверу

- PHP 7.4+
- Поддержка .htaccess / mod_rewrite
- Права на запись в api/data/
- CORS: API отдаёт Access-Control-Allow-Origin: *

### 10.3 Проверка работоспособности API

```
GET https://[домен]/api/?action=ping → { "ok": true }
```

---

## 11. Безопасность

| Аспект | Реализация |
|--------|-----------|
| Аутентификация | Локальная проверка логина/пароля, токен в памяти |
| Авторизация | Все данные доступны после единственного входа |
| Хранение пароля | Хардкод в auth.js (для смены — правка исходника) |
| API-доступ | Без токена — любой может читать/писать данные через API |
| XSS | Все динамические данные вставляются через textContent, не innerHTML |
| Sandbox | Приложение работает в iframe с флагами sandbox; обходится через sessionStorage + in-memory |

Рекомендация: для production добавить Bearer-токен или HTTP Basic Auth на уровне .htaccess для защиты api/ от несанкционированного доступа.

---

## 12. Ограничения текущей реализации

| Ограничение | Описание |
|-------------|----------|
| Один пользователь | Нет разграничения прав, один логин на всех |
| Конфликты при одновременной работе | Авто-синхронизация перезаписывает данные целиком (last-write-wins) |
| Отчёты | Раздел «Отчёты» не реализован (заглушка) |
| Размер данных | localStorage ограничен ~5 МБ; api/data/storage.json не ограничен |
| Офлайн-режим | При недоступности API работает с кэшем localStorage, изменения сохраняются локально и синхронизируются при следующем успешном подключении |
